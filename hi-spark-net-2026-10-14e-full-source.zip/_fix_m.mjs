import fs from "node:fs";
const p = "assets/styles.css";
let css = fs.readFileSync(p, "utf8");

// 1) CLS: the slot host has no height until JS adds the classes, so content below
// jumps when the ad paints. Reserve the space from the data attributes instead.
if (!css.includes("Ad slot space reservation")) {
  css += `
/* Ad slot space reservation: the host div exists in the HTML before
   monetization.js runs, so reserve its final height from the data attributes.
   Without this the page shifts when a slot paints (CLS). */
[data-ad-slot]{display:block;margin:22px 0}
[data-ad-slot][data-ad-size="leaderboard"]{min-height:112px}
[data-ad-slot][data-ad-size="billboard"],
[data-ad-slot][data-ad-size="rectangle"],
[data-ad-slot][data-ad-size="infeed"]{min-height:272px}
[data-ad-slot][data-ad-size="halfpage"]{min-height:622px}
.side-card [data-ad-slot]{margin:0}
@media(max-width:760px){
  [data-ad-slot][data-ad-size="leaderboard"],
  [data-ad-slot][data-ad-size="billboard"]{min-height:122px}
  [data-ad-slot][data-ad-size="halfpage"]{min-height:272px}
}
`;
  console.log("1) ad slot space reservation added (fixes CLS)");
} else console.log("1) already present");

// 2) footer links were ~21px tall - the secondary nav on mobile
const oldFooter = ".footer a{display:block;font-size:.82rem;padding:4px 0;color:#bdd0d4}";
if (css.includes(oldFooter) && !css.includes(".footer a{min-height:44px")) {
  css = css.replace(oldFooter, oldFooter + "\n.footer a{min-height:44px;display:flex;align-items:center}/*mobile tap target*/");
  console.log("2) footer link tap targets raised to 44px");
} else console.log("2) footer handled");
