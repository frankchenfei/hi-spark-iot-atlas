import fs from "node:fs";
fs.writeFileSync("assets/entity-urls.js", `/* Canonical URLs for entity pages.
 *
 * tools/prerender_entities.mjs writes one static file per brand, app, platform,
 * protocol, comparison, category and product. Links point at those files so
 * visitors and crawlers land on the indexed version rather than the query-string
 * template, and the language choice is carried across as ?lang=. */
(function () {
  var PREFIX = { brand: "brand", app: "app", cloud: "cloud", protocol: "protocol", compare: "compare", category: "category", product: "product" };
  window.IOT_ENTITY_PATH = function (type, slug, lang) {
    var dir = PREFIX[type];
    if (!dir || !slug) return "/";
    var p = "/" + dir + "/" + encodeURIComponent(slug) + ".html";
    return (lang && lang !== "en") ? p + "?lang=" + encodeURIComponent(lang) : p;
  };
})();
`, "utf8");
console.log("entity-urls.js written");

const patches = [
  ["assets/app.js", 'brandHref=b=>href("brand-detail.html",{brand:b.slug}),cloudHref=c=>href("cloud-detail.html",{provider:c.slug})',
   'brandHref=b=>window.IOT_ENTITY_PATH("brand",b.slug,lang),cloudHref=c=>window.IOT_ENTITY_PATH("cloud",c.slug,lang)'],
  ["assets/apps-ui.js", "app-detail.html?app=", "/app/"],
  ["assets/category-hub.js", "brand-detail.html?brand=", "/brand/"],
  ["assets/category-hub.js", "app-detail.html?app=", "/app/"],
  ["assets/category-hub.js", "protocol-detail.html?protocol=", "/protocol/"],
  ["assets/category-hub.js", "compare-detail.html?pair=", "/compare/"],
  ["assets/category-hub.js", "cloud-detail.html?provider=", "/cloud/"],
  ["assets/category-hub.js", "category-detail.html?category=", "/category/"],
  ["assets/compare-ui.js", "compare-detail.html?pair=", "/compare/"],
  ["assets/knowledge-ui.js", "protocol-detail.html?protocol=", "/protocol/"],
  ["assets/brand-index-ui.js", "brand-detail.html?brand=", "/brand/"]
];
for (const [file, from, to] of patches) {
  let t = fs.readFileSync(file, "utf8");
  if (!t.includes(from)) { console.log("MISS  " + file); continue; }
  t = t.split(from).join(to);
  fs.writeFileSync(file, t, "utf8");
  console.log("ok    " + file + "  " + from);
}
