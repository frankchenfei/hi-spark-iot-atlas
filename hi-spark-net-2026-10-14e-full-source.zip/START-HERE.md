# START HERE - deployment handoff

**IoT Atlas** - independent IoT decision platform.
Static site (English / Spanish / French) + Supabase community + SEO/GEO assets.

Full instructions: **`DEPLOYMENT.md`** | Audit must pass: **`npm run audit`**

---

## What you are deploying

| | |
|---|---|
| Files | 1,938 |
| Pages | **1,505** on disk = 26 hub pages + 1,469 entity pages + `sitemap.html` |
| Languages | English (canonical) + Spanish + French |
| Asset version | `?v=20261008s` |
| Build | plain static files, no server runtime required |

### Content inventory

| Records | |
|---|---|
| Apps | 998 (868 with a verified direct App Store link) |
| Brands | 290 |
| Cloud / IoT platforms | 29 |
| Protocols | 61 |
| Standards / Guides / Concepts | 47 / 42 / 33 |
| Comparisons | 49 |
| Categories | 30 |
| Amazon ranking rows | 96 (**placeholder data** - see below) |
| Community seed | 40 discussions, 96 replies |

---

## Three things to do before it goes live

### 1. Deploy at the domain root

Entity pages reference assets root-relative (`/assets/...`). A sub-path deploy
(`example.com/site/`) needs the prefix rewritten in `tools/prerender_entities.mjs`.

### 2. Fill four config files

| File | Ships as | Change to |
|---|---|---|
| `assets/supabase-config.js` | empty | your Supabase URL + anon key |
| `assets/analytics-config.js` | `provider: "none"` | GA4 / Plausible / Umami + ID |
| `assets/monetization-config.js` | `mode: "placeholder"` | `adsense` + client/slot IDs |
| `assets/subscribe-config.js` | `mode: "preview"` | `live` + your form endpoint |

`assets/outbound-config.js` already works (UTM tagging); add affiliate IDs when you have them.

### 3. Turn on compression

The heaviest page is 1.5 MB of JS uncompressed and **~290 KB with gzip**. This is the
single biggest mobile-speed lever. Netlify and Cloudflare Pages read the shipped
`_headers` file automatically; nginx config is in `DEPLOYMENT.md`.

---

## Supabase (community + member login)

1. Create a project (EU region if your audience is European).
2. SQL Editor → run `supabase/schema.sql` (tables, RLS, triggers, views).
3. SQL Editor → run `supabase/seed.sql` (40 discussions, 96 replies).
4. Project Settings → API → copy the **Project URL** and **anon** key into
   `assets/supabase-config.js`.
5. **Never ship the `service_role` key** - it must not appear in any front-end file.

---

## Rebuilding after a content change

```bash
SITE_URL="https://your-domain.com" npm run build
npm run audit          # must exit 0
```

`npm run build` runs, in order: SEO head pass → structured data → FAQ schema →
script profiles → translation compile → entity pre-render. Re-run it after any data
edit; the 1,469 entity pages are generated, never hand-edited.

---

## Before you promote it to production

- [ ] `npm run audit` exits 0
- [ ] `npm run gate` exits 0
- [ ] Compression is active (`content-encoding: gzip`)
- [ ] `/sitemap.xml` and `/sitemap-entities.xml` load on the production domain
- [ ] `/llms.txt` loads (GEO)
- [ ] A detail link resolves with `.html`, e.g. `/app/tuya-smart.html`
- [ ] Mobile check on a **real 360 px device** - see `DEPLOYMENT.md` §4

The full 35-item checklist is in `DEPLOYMENT.md` §4.

---

## Known limitations - read before launch

| Item | Status |
|---|---|
| **Amazon ranking data** | **Placeholder.** ASINs are `B0DEMO00xx`; ranks and prices are invented and labelled as such sitewide. Connect the Amazon Product Advertising API or another licensed source before promoting the rankings. |
| **Google Play links** | Store-search links, not direct package IDs. Run `node tools/verify_app_stores.mjs --android` from a network that can reach Google Play. |
| **47 app links flagged** | `content-templates/app-link-review.csv` - mostly the same app under a different store title; a few need a human check. |
| **Translation** | Machine-assisted, not native-reviewed. `content-templates/translation-worklist.csv` is the hand-off sheet (1,507 rows). |
| **Legal pages** | Drafts. Jurisdiction-specific review required before launch. |
| **hreflang** | Query-parameter based (`?lang=es`). Path locales (`/es/`) would be stronger for SEO. |
| **Community moderation** | RLS restricts authorship, not content. Add moderation tooling before opening signups. |

---

## Local preview

```bash
python -m http.server 8765 --bind 127.0.0.1
# then open http://127.0.0.1:8765/
```
