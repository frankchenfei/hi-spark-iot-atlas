#!/usr/bin/env node
/** Assigns each page the smallest script profile that still renders it.
 *
 *  ORDER MATTERS. app.js reads window.IOT_* at IIFE time, so every data file
 *  must be present before it runs. The emission order below is:
 *    data -> catalogues -> app directory -> i18n -> UI -> helpers -> app.js last
 */
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { APP_FILES } from "./app-batches.mjs";
import { VERSIONED as VER } from "./asset-version.mjs";
const PROTO = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");

const DATA = ["data.js"];
const CATALOG = ["brands.js","brand-site-verified.js","brand-scores.js","category-hub.js","clouds.js","knowledge.js","knowledge-extra.js","knowledge-extra2.js","logo-map.js","product-directory.js","compare-data.js","brand-index.js","compatibility-data.js","model-data.js","troubleshooting-data.js","certification-data.js"];
const APPS = APP_FILES;
const AMAZON = ["amazon-rankings.js"];
const SEED = ["community-seed.js","community-seed-extra.js","community-seed-extra2.js","supabase-config.js"];
const HELPERS = ["lazy-render.js","virtual-scroll.js","expanded-content-ui.js"];
// Consent must load before analytics, which waits on the stored choice.
const SITEWIDE = ["consent.js","analytics-config.js","analytics.js","outbound-config.js","outbound-tagging.js","subscribe-config.js","subscribe.js"];
const MONETIZE = ["monetization-config.js","monetization.js"];
// Catalogue prose translations (staged subset). Loaded only where the prose shows.
const CONTENT_I18N = {
  brands: "content-i18n-brands.js", apps: "content-i18n-apps.js",
  knowledge: "content-i18n-knowledge.js", cloud: "content-i18n-cloud.js",
  compare: "content-i18n-compare.js"
};
const CONTENT_APPLY = "content-i18n-apply.js";
// ES/FR store for the compatibility, model, troubleshooting and certification centres.
const CORE_I18N = "content-i18n-core.js";
const CENTRE_UI_I18N = "i18n-centres.js";
// Share bar + call-to-action block.
const SHARE_CTA = "share-cta.js";
const EXTRAS = ["cloud-map.js","home-stats.js"];
const APPJS = ["app.js"];

const PROFILE = {
  // The homepage paints from assets/home-pack.js (trimmed catalogue) instead of the
  // full data files, which keeps roughly 1.5 MB of JavaScript off the first load.
  "index.html":            { share:1, data:1, homePack:1, ui:["knowledge-ui.js","apps-ui.js","brand-scorecard-ui.js","ai-signals-ui.js"], homeStats:1, contentApply:1 },
  "compatibility.html":    { share:1, core:1, data:1, catalog:1, extras:1 },
  "compatibility-detail.html": { share:1, core:1, data:1, catalog:1, ui:["entity-seo.js"], extras:1 },
  "models.html":           { share:1, core:1, data:1, catalog:1, extras:1 },
  "model-detail.html":     { share:1, core:1, data:1, catalog:1, ui:["entity-seo.js"], extras:1 },
  "troubleshooting.html":  { share:1, core:1, data:1, catalog:1, extras:1 },
  "troubleshooting-detail.html": { share:1, core:1, data:1, catalog:1, ui:["entity-seo.js"], extras:1 },
  "certifications.html":   { share:1, core:1, data:1, catalog:1, extras:1 },
  "markets.html":          { share:1, data:1, catalog:1, extras:1 },
  "certification-detail.html": { share:1, core:1, data:1, catalog:1, ui:["entity-seo.js"], extras:1 },
  "search.html":           { data:1, catalog:1, apps:1, amazon:1, ui:["knowledge-ui.js","apps-ui.js","compare-ui.js"], extras:1 , content:["brands","apps"] },
  "apps.html":             { share:1, data:1, catalog:1, apps:1, ui:["knowledge-ui.js","apps-ui.js","app-sort.js"], extras:1 , content:["apps"] },
  "app-detail.html":       { share:1, data:1, catalog:1, apps:1, ui:["knowledge-ui.js","apps-ui.js","ai-signals-ui.js","brand-scorecard-ui.js","entity-seo.js"], seed:1, community:1, extras:1 , content:["apps"] },
  "brand.html":            { share:1, data:1, catalog:1, ui:["knowledge-ui.js","brand-index-ui.js"], extras:1 , content:["brands"] },
  "brand-detail.html":     { share:1, data:1, catalog:1, ui:["knowledge-ui.js","brand-index-ui.js","brand-scorecard-ui.js","entity-seo.js"], seed:1, community:1, extras:1 , content:["brands"] },
  "brand-insights.html":   { share:1, data:1, catalog:1, ui:["brand-index-ui.js"], extras:1 , content:["brands"] },
  "products.html":         { share:1, data:1, catalog:1, ui:["knowledge-ui.js"], extras:1 },
  "product.html":          { share:1, data:1, catalog:1, ui:["knowledge-ui.js","compare-ui.js","ai-signals-ui.js","brand-scorecard-ui.js","entity-seo.js"], seed:1, community:1, extras:1 },
  "categories.html":       { share:1, data:1, catalog:1, apps:1, ui:["knowledge-ui.js"], extras:1 , content:["apps"] },
  "category.html":         { share:1, data:1, catalog:1, apps:1, ui:["knowledge-ui.js"], extras:1 , content:["apps"] },
  "category-detail.html":  { share:1, data:1, catalog:1, apps:1, amazon:1, ui:["knowledge-ui.js","compare-ui.js","compare-visuals.js","entity-seo.js"], seed:1, community:1, extras:1 , content:["apps"] },
  "compare.html":          { share:1, data:1, catalog:1, ui:["knowledge-ui.js","compare-ui.js","compare-visuals.js"], extras:1, content:["compare"]  },
  "compare-detail.html":   { share:1, data:1, catalog:1, ui:["knowledge-ui.js","compare-ui.js","compare-visuals.js","brand-index-ui.js","entity-seo.js"], extras:1, content:["compare"]  },
  "cloud.html":            { share:1, data:1, catalog:1, ui:["knowledge-ui.js"], extras:1, content:["cloud"]  },
  "cloud-detail.html":     { share:1, data:1, catalog:1, ui:["knowledge-ui.js","entity-seo.js"], seed:1, community:1, extras:1, content:["cloud"]  },
  "knowledge.html":        { share:1, data:1, catalog:1, ui:["knowledge-ui.js"], extras:1, content:["knowledge"]  },
  "protocol-detail.html":  { share:1, data:1, catalog:1, ui:["knowledge-ui.js","entity-seo.js"], extras:1, content:["knowledge"]  },
  "amazon-brands.html":    { share:1, data:1, catalog:1, amazon:1, ui:["knowledge-ui.js","amazon-brands-ui.js"], extras:1 },
  "amazon-best-sellers.html": { share:1, data:1, catalog:1, amazon:1, ui:["knowledge-ui.js","amazon-bestsellers-ui.js","ai-signals-ui.js"], extras:1 },
  "ai-signals.html":       { share:1, data:1, catalog:1, ui:["knowledge-ui.js","ai-signals-ui.js"], extras:1 },
  "community.html":        { share:1, data:1, seed:1, community:1, extras:1 },
  "perf-demo.html":        { data:1, catalog:1, apps:1, ui:["perf-demo.js","apps-ui.js","knowledge-ui.js"] },
  "dataset.html":            { share:1, data:1, extras:1 },
  "methodology.html":      { share:1, data:1, extras:1 }, "manual.html": { share:1, data:1, extras:1 },
  "legal.html": { share:1, data:1 }, "privacy.html": { share:1, data:1 }, "terms.html": { share:1, data:1 }, "cookies.html": { share:1, data:1 },
  "affiliate-disclosure.html": { share:1, data:1 }, "ai-disclosure.html": { share:1, data:1 },
  "editorial-policy.html": { share:1, data:1 }, "corrections-policy.html": { share:1, data:1 },
  "styleguide.html": { data:1 }, "logo-gallery.html": { data:1, catalog:1 }
};
const build = (pr) => []
  .concat(pr.data ? DATA : [])
  .concat(pr.core ? [CORE_I18N] : [])
  .concat(pr.core ? [CENTRE_UI_I18N] : [])
  .concat(pr.share ? [SHARE_CTA] : [])
  .concat(pr.homePack ? ["home-pack.js"] : [])
  .concat(pr.catalog ? CATALOG : [])
  .concat(pr.apps ? APPS : [])
  .concat(pr.amazon ? AMAZON : [])
  .concat(pr.seed ? SEED : [])
  .concat(["i18n.js"])
  .concat(["entity-urls.js"])
  .concat(pr.ui || [])
  .concat(HELPERS)
  .concat(SITEWIDE)
  .concat(MONETIZE)
  .concat(pr.community ? ["community.js"] : [])
  .concat(pr.extras ? EXTRAS : [])
  .concat(pr.homeStats ? ["home-stats.js"] : [])
  .concat(pr.content ? pr.content.map((k) => CONTENT_I18N[k]).filter(Boolean) : [])
  .concat((pr.content || pr.contentApply) ? [CONTENT_APPLY] : [])
  .concat(APPJS)
  .filter((v, i, a) => a.indexOf(v) === i);

let before = 0, after = 0, pages = 0;
for (const f of fs.readdirSync(PROTO).filter((x) => x.endsWith(".html"))) {
  const p = path.join(PROTO, f);
  let html = fs.readFileSync(p, "utf8");
  before += (html.match(/<script src="assets\//g) || []).length;
  const list = build(PROFILE[f] || { data: 1 });
  const tags = list.map((n) => '<script src="assets/' + n + VER + '"></script>').join("");
  html = html.replace(/<script src="assets\/[^"]+"><\/script>/g, "");
  html = html.replace(/<link rel="stylesheet" href="assets\/styles\.css\?v=[^"]*">/g, '<link rel="stylesheet" href="assets/styles.css' + VER + '">');
  html = html.includes("</body>") ? html.replace("</body>", tags + "</body>") : html + tags;
  fs.writeFileSync(p, html, "utf8");
  pages++; after += list.length;
}
console.log("pages: " + pages + " | scripts before: " + before + " after: " + after);
console.log("app.js is emitted last on every page where it is present.");



