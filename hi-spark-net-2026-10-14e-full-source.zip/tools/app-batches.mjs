/**
 * Single source of truth for the ordered script lists.
 *
 * The catalogue is split across many batch files and every batch appends to the
 * array the previous one left on window, so the order matters. Eight tools used to
 * keep their own hard-coded copy of that order; adding a batch meant editing eight
 * places, and missing one silently produced wrong counts (llms.txt reported 984
 * apps while the site shipped 998). Import from here instead.
 */

/** Raw directory batches, in load order. Add new batches here only. */
export const APP_DIRECTORY = [
  "app-directory.js", "app-directory-extra.js", "app-directory-extra2.js",
  "app-directory-camera.js", "app-directory-healthhome.js", "app-directory-health.js",
  "app-directory-wearables.js", "app-directory-more.js", "app-directory-extra4.js",
  "app-directory-extra5.js", "app-directory-extra6.js", "app-directory-extra7.js",
  "app-directory-extra8.js", "app-directory-extra9.js", "app-directory-extra10.js",
  "app-directory-extra11.js", "app-directory-extra12.js", "app-directory-extra13.js",
  "app-directory-extra14.js"
];

/** Normalisation, quality filtering, scope rules and source attribution. */
export const APP_PIPELINE = [
  "app-directory-normalize.js", "app-directory-quality.js", "app-scope-filter.js",
  "app-sources.js", "app-brand-basis.js"
];

/** Store verification and editorial summaries, applied on top of the pipeline. */
export const APP_ENRICHMENT = [
  "app-verified.js", "app-summaries.js", "app-summary-variants.js"
];

/** Directory + pipeline. This is the array the verifiers and SEO tools should load. */
export const APP_LOAD_ORDER = [...APP_DIRECTORY, ...APP_PIPELINE];

/** Everything: what a browser page loads to render the full app directory. */
export const APP_FILES = [...APP_LOAD_ORDER, ...APP_ENRICHMENT];

/** Non-app catalogue files, in load order. */
export const CATALOG_FILES = [
  "brands.js", "brand-site-verified.js", "brand-scores.js", "category-hub.js",
  "clouds.js", "knowledge.js", "knowledge-extra.js", "knowledge-extra2.js",
  "logo-map.js", "product-directory.js", "compare-data.js", "brand-index.js", "compatibility-data.js", "model-data.js", "troubleshooting-data.js", "certification-data.js"
];

/** ES/FR translations for the four reference centres (policy: all new content is trilingual). */
export const CORE_I18N_FILES = ["content-i18n-core.js"];
