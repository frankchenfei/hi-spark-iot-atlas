#!/usr/bin/env node
/**
 * Pre-renders one static HTML file per entity.
 *
 * The detail templates read their subject from a query parameter and paint it
 * with JavaScript, so a crawler that does not run JS - or that only indexes the
 * template URL - sees one page instead of 1,400. This tool writes a real file per
 * entity with its own head block, its own canonical and its subject already in
 * the markup. The page still loads the same scripts, so the interactive layer
 * (related items, scorecards, community) behaves exactly as before.
 *
 * Output: brand/, app/, cloud/, protocol/, compare/, category/, product/
 * Usage:  node tools/prerender_entities.mjs
 */
import fs from "node:fs";
import path from "node:path";
import vm from "node:vm";
import { fileURLToPath } from "node:url";
import { APP_FILES as APP_FILES_BASE } from "./app-batches.mjs";
import { VERSIONED } from "./asset-version.mjs";
import { injectShare } from "./share-cta-markup.mjs";
import { entityFaqs, entityFaqsLocalized, faqNode, faqMarkup, faqI18nScript } from "./entity-faq.mjs";
import { entityRelated, relatedCards, relatedCompact, relatedMarkup } from "./entity-related.mjs";

const PROTO = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const ASSETS = path.join(PROTO, "assets");
const SITE = process.env.SITE_URL || "https://hi-spark.net";
const TODAY = new Date().toISOString().slice(0, 10);

/* ---------- load the catalogue ---------- */
// the split translation stores so inlineEntityTranslation can read them
const APP_FILES = [...APP_FILES_BASE,
  "content-i18n-brands.js", "content-i18n-apps.js", "content-i18n-knowledge.js",
  "content-i18n-cloud.js", "content-i18n-compare.js", "content-i18n-core.js"];
const CATALOG = ["brands.js","brand-site-verified.js","brand-scores.js","category-hub.js","clouds.js",
  "knowledge.js","knowledge-extra.js","knowledge-extra2.js","logo-map.js","product-directory.js","compare-data.js","compatibility-data.js","model-data.js","troubleshooting-data.js","certification-data.js"];
const ctx = { window: {} };
vm.createContext(ctx);
for (const f of CATALOG.concat(APP_FILES)) {
  const p = path.join(ASSETS, f);
  if (fs.existsSync(p)) vm.runInContext(fs.readFileSync(p, "utf8"), ctx, { filename: f });
}
const W = ctx.window;
const K = W.IOT_KNOWLEDGE || {};

/* ---------- helpers ---------- */
const esc = (v) => String(v == null ? "" : v)
  .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
  .replace(/"/g, "&quot;").replace(/'/g, "&#39;");
const attr = (v) => esc(v).replace(/&#39;/g, "'");
const isUrl = (v) => /^https?:\/\//i.test(String(v || ""));
const list = (v) => Array.isArray(v) ? v : (v == null || v === "" ? [] : [v]);
// Search engines truncate around 60-65 characters, so drop the middle qualifier
// first and only then shorten the entity name.
function pageTitle(name, qualifier) {
  var full = name + " | " + qualifier + " | IoT Atlas";
  if (full.length <= 64) return full;
  var short = name + " | IoT Atlas";
  if (short.length <= 64) return short;
  var budget = 64 - " | IoT Atlas".length - 1;
  return name.slice(0, budget).replace(/[\s,\-]+$/, "") + "\u2026 | IoT Atlas";
}
// Meta descriptions must stand on their own, so pad the record text with the
// concrete facts already held on the record until it reaches a useful length.
function describe(parts, n) {
  const seen = [];
  for (const v of parts) {
    const s = String(v == null ? "" : v).replace(/\s+/g, " ").trim();
    if (s && seen.indexOf(s) === -1) seen.push(s);
  }
  let out = "";
  for (const s of seen) {
    out = out ? out.replace(/[.\s]+$/, "") + ". " + s : s;
    if (out.length >= 110) break;
  }
  return clamp(out, n);
}
const clamp = (s, n) => {
  s = String(s || "").replace(/\s+/g, " ").trim();
  if (s.length <= n) return s;
  return s.slice(0, n - 3).replace(/[\s,;:.\-]+$/, "") + "...";
};

// Replace the inner markup of the first element carrying this id.
function setInner(html, id, value) {
  const at = html.indexOf('id="' + id + '"');
  if (at < 0) return { html, ok: false };
  const open = html.lastIndexOf("<", at);
  if (open < 0) return { html, ok: false };
  const tagEnd = html.indexOf(">", at);
  if (tagEnd < 0) return { html, ok: false };
  const tag = (html.slice(open + 1, tagEnd).match(/^[a-zA-Z0-9]+/) || [""])[0];
  if (!tag) return { html, ok: false };
  const closeTag = "</" + tag + ">";
  let depth = 1, i = tagEnd + 1;
  while (i < html.length) {
    const nOpen = html.indexOf("<" + tag, i), nClose = html.indexOf(closeTag, i);
    if (nClose < 0) return { html, ok: false };
    if (nOpen > -1 && nOpen < nClose) { depth++; i = nOpen + tag.length + 1; }
    else { depth--; i = nClose + closeTag.length; if (depth === 0) {
      return { html: html.slice(0, tagEnd + 1) + value + html.slice(nClose), ok: true };
    } }
  }
  return { html, ok: false };
}
function setHref(html, id, value) {
  const re = new RegExp('(id="' + id + '"[^>]*?href=")([^"]*)(")');
  if (!re.test(html)) return { html, ok: false };
  return { html: html.replace(re, "$1" + attr(value) + "$3"), ok: true };
}

/* ---------- output scaffolding ---------- */
const dirs = ["brand","app","cloud","protocol","compare","category","product","compatibility","model","troubleshooting","certification"];
for (const d of dirs) {
  const abs = path.join(PROTO, d);
  // Wipe first: a record removed from the catalogue must not leave its page
  // behind, or the host keeps serving a URL for something we no longer cover.
  fs.rmSync(abs, { recursive: true, force: true });
  fs.mkdirSync(abs, { recursive: true });
}

// Entity pages live one level down, so every internal reference becomes root-relative.
function rebase(html) {
  /* Entity pages sit one directory down. Prefixing with "../" keeps every link
     working when the site is opened straight from disk (file://), served over
     http, or deployed into a sub-directory. A root-relative "/assets/..." breaks
     the file:// case, which is exactly how a reviewer opens the build locally. */
  const B = "../";
  return html
    .replace(/(href|src)="assets\//g, "$1=\"" + B + "assets/")
    .replace(/(href|src)="(?!https?:|\/|\.\.\/|#|mailto:)([a-z0-9-]+\.html)([^"]*)"/g, "$1=\"" + B + "$2$3\"")
    .replace(/href="\/brand-detail\.html\?brand=([^"]+)"/g, 'href="' + B + 'brand/$1.html"')
    .replace(/href="\/app-detail\.html\?app=([^"]+)"/g, 'href="' + B + 'app/$1.html"')
    .replace(/href="\/cloud-detail\.html\?provider=([^"]+)"/g, 'href="' + B + 'cloud/$1.html"')
    .replace(/href="\/protocol-detail\.html\?protocol=([^"]+)"/g, 'href="' + B + 'protocol/$1.html"')
    .replace(/href="\/compare-detail\.html\?pair=([^"]+)"/g, 'href="' + B + 'compare/$1.html"')
    .replace(/href="\/category-detail\.html\?category=([^"]+)"/g, 'href="' + B + 'category/$1.html"')
    .replace(/href="\/product\.html\?product=([^"]+)"/g, 'href="' + B + 'product/$1.html"')
    .replace(/href="\/compatibility-detail\.html\?compat=([^"]+)"/g, 'href="' + B + 'compatibility/$1.html"')
    .replace(/href="\/model-detail\.html\?model=([^"]+)"/g, 'href="' + B + 'model/$1.html"')
    .replace(/href="\/troubleshooting-detail\.html\?issue=([^"]+)"/g, 'href="' + B + 'troubleshooting/$1.html"')
    .replace(/href="\/certification-detail\.html\?certification=([^"]+)"/g, 'href="' + B + 'certification/$1.html"')
    .replace(/href="\/((?:brand|app|cloud|protocol|compare|category|product|compatibility|model|troubleshooting|certification)\/[^"]+)"/g, 'href="' + B + '$1"');
}

function headBlock(o) {
  const langs = o.enOnly ? [] : ["en","es","fr"];
  const alts = langs.map(l =>
    '  <link rel="alternate" hreflang="' + l + '" href="' + o.canonical + (l === "en" ? "" : "?lang=" + l) + '">').join("\n");
  const ld = JSON.stringify(o.ld);
  return [
    "<!--seo:start-->",
    "<title>" + esc(o.title) + "</title>",
    '<meta name="description" content="' + attr(o.description) + '">',
    '<link rel="canonical" href="' + o.canonical + '">',
    alts,
    o.enOnly ? "" : '  <link rel="alternate" hreflang="x-default" href="' + o.canonical + '">',
    '<meta name="robots" content="index,follow,max-image-preview:large">',
    '<link rel="alternate" type="application/atom+xml" href="../feed.xml" title="IoT Atlas - recently verified records">',
    '<link rel="icon" href="../favicon.ico" sizes="any">',
    '<link rel="icon" type="image/png" sizes="32x32" href="../favicon-32.png">',
    '<link rel="icon" type="image/png" sizes="192x192" href="../icon-192.png">',
    '<link rel="apple-touch-icon" href="../apple-touch-icon.png">',
    '<link rel="manifest" href="../manifest.webmanifest">',
    '<meta name="theme-color" content="#0c7475">',
    '<meta property="og:type" content="website">',
    '<meta property="og:site_name" content="IoT Atlas">',
    '<meta property="og:title" content="' + attr(o.title) + '">',
    '<meta property="og:description" content="' + attr(o.description) + '">',
    '<meta property="og:url" content="' + o.canonical + '">',
    '<meta property="og:image" content="' + SITE + '/assets/og-default.png">',
    '<meta property="og:image:width" content="1200">',
    '<meta property="og:image:height" content="630">',
    '<meta property="og:image:alt" content="' + attr(o.title) + '">',
    '<meta property="og:locale" content="en_US">',
    ...(o.enOnly ? [] : ['<meta property="og:locale:alternate" content="es_ES">', '<meta property="og:locale:alternate" content="fr_FR">']),
    '<meta name="twitter:card" content="summary_large_image">',
    '<meta name="twitter:image" content="' + SITE + '/assets/og-default.png">',
    '<meta name="twitter:image:alt" content="' + attr(o.title) + '">',
    '<meta name="twitter:title" content="' + attr(o.title) + '">',
    '<meta name="twitter:description" content="' + attr(o.description) + '">',
    "<!--seo:end-->",
    '<script type="application/ld+json" data-generated="structured-data">' + ld + "</script>"
  ].join("\n");
}

function swapHead(html, block) {
  // The templates carry a placeholder <title>/<meta> set as well as the generated
  // <!--seo--> block, so strip every SEO tag first and emit a single clean block.
  const strip = [
    /<title>[\s\S]*?<\/title>/g,
    /<meta name="description"[^>]*>/g,
    /<meta name="robots"[^>]*>/g,
    /<meta property="og:[^"]*"[^>]*>/g,
    /<meta name="twitter:[^"]*"[^>]*>/g,
    /<link rel="canonical"[^>]*>/g,
    /<link rel="alternate"[^>]*>/g,
    /<script type="application\/ld\+json"[^>]*>[\s\S]*?<\/script>/g,
    /<!--seo:start-->[\s\S]*?<!--seo:end-->/g
  ];
  for (const re of strip) html = html.replace(re, "");
  const h = html.indexOf("<head>");
  if (h < 0) return html;
  const at = h + "<head>".length;
  return html.slice(0, at) + "\n" + block + "\n" + html.slice(at);
}

const written = [];
/* Each entity page needs exactly one translated string, so inline it and drop the
   external store. Loading the 258 KB combined file for a single brand note was the
   single biggest avoidable cost on the SEO surface. */
const STORE = (ctx.window && ctx.window.IOT_CONTENT_I18N) || {};
const STORE_KEY = { brand: "brands", app: "apps", cloud: "clouds", protocol: "protocols", compare: "comparisons" };
/* The four reference centres keep their es/fr text in IOT_CONTENT_I18N_CORE. Inline the
   single entity entry so the page does not need to ship the whole store. */
const CORE_KEY = { compatibility: "compatibility", model: "model", troubleshooting: "troubleshooting", certification: "certification" };
const CORE_STORE = (ctx.window && ctx.window.IOT_CONTENT_I18N_CORE) || {};
/* FAQ localisation for the model and troubleshooting centres reads from the same
   core store, so the generated Q&A is translated wherever the record is. */
const STORE_ALL = Object.assign({}, STORE, CORE_STORE);
function inlineCoreTranslation(type, slug, html) {
  const key = CORE_KEY[type];
  const entry = key && CORE_STORE[key] && CORE_STORE[key][slug];
  if (!entry || !entry.es || !entry.fr) return html;
  html = html.replace(/<script src="\.\.\/assets\/content-i18n-core\.js\?v=[^"]*"><\/script>/, "");
  const payload = JSON.stringify({ [key]: { [slug]: entry } });
  const tag = '<script id="entity-i18n-core">window.IOT_CONTENT_I18N_CORE=Object.assign(window.IOT_CONTENT_I18N_CORE||{},' + payload + ');</script>';
  const first = html.search(/<script /);
  return first < 0 ? html + tag : html.slice(0, first) + tag + html.slice(first);
}
function inlineEntityTranslation(type, slug, html) {
  const key = STORE_KEY[type];
  const entry = key && STORE[key] && STORE[key][slug];
  // nothing to inline: leave the split store reference alone
  if (!entry || !entry.es || !entry.fr) return html;
  // drop both the combined store and the per-collection file for this type
  // only the store files, never content-i18n-apply.js which does the applying
  html = html.replace(/<script src="\/?assets\/content-i18n(?:-(?:brands|apps|knowledge|cloud|compare))?\.js\?v=[^"]*"><\/script>/g, "");
  const payload = JSON.stringify({ [key]: { [slug]: entry } });
  const tag = '<script id="entity-i18n">window.IOT_CONTENT_I18N=Object.assign(window.IOT_CONTENT_I18N||{},' + payload + ');</script>';
  const first = html.search(/<script /);
  return first < 0 ? html + tag : html.slice(0, first) + tag + html.slice(first);
}

function listHtml(items) { return '<ul class="source-list">' + list(items).map((x) => '<li>' + esc(x) + '</li>').join('') + '</ul>'; }
function stepsHtml(items) { return '<div class="feature-list">' + list(items).map((x, i) => '<div class="feature"><div class="feature-icon">' + (i + 1) + '</div><div><p>' + esc(x) + '</p></div></div>').join('') + '</div>'; }
function sourceHtml(items) { return '<ul class="source-list">' + list(items).map((x) => '<li><a href="' + attr(x.url) + '" target="_blank" rel="noopener">' + esc(x.label || x.url) + '</a></li>').join('') + '</ul>'; }
function specHtml(obj) { return '<div class="spec-grid">' + Object.keys(obj || {}).map((k) => '<div class="spec"><small>' + esc(k) + '</small><strong>' + esc(obj[k]) + '</strong></div>').join('') + '</div>'; }

/* The share bar and call-to-action are written into the static HTML so they exist
   without JavaScript. assets/share-cta.js only adds behaviour and swaps the labels. */
function inlineShareCta(html, url) {
  if (!/id="share-(bar|cta)"/.test(html)) return html;
  const h1 = html.match(/<h1[^>]*>([\s\S]*?)<\/h1>/);
  const tt = html.match(/<title>([^<]*)<\/title>/);
  const raw = h1 ? h1[1] : (tt ? tt[1] : "");
  const title = raw.replace(/<[^>]+>/g, " ").replace(/\s+/g, " ").trim();
  return injectShare(html, { url, title, base: "../" });
}
/* ---- FAQ + internal links for catalogue entity pages ---- */
const REC_KEY = { app: "IOT_APP_DIRECTORY", brand: "IOT_BRANDS", cloud: "IOT_CLOUDS",
  compare: "IOT_COMPARISONS", category: "IOT_CATEGORY_HUB", product: "IOT_PRODUCT_DIRECTORY" };
function recordFor(type, slug) {
  if (type === "protocol") return ((W.IOT_KNOWLEDGE || {}).protocols || []).find((x) => x.slug === slug);
  const list = W[REC_KEY[type]];
  return Array.isArray(list) ? list.find((x) => x.slug === slug) : null;
}
function recordDate(type, rec) {
  const d = rec && (rec.lastVerified || rec.verified_at || rec.verifiedAt);
  return /^\d{4}-\d{2}-\d{2}/.test(String(d || "")) ? String(d).slice(0, 10) : TODAY;
}
const RELATED_SLOT = { brand: ["brand-related", relatedCards], compare: ["compare-related", relatedCards],
  app: ["app-related", relatedCompact], protocol: ["protocol-related", relatedCompact] };
function injectRelated(html, type, links) {
  if (!links.length) return html;
  const slot = RELATED_SLOT[type];
  if (slot && html.includes('id="' + slot[0] + '"')) {
    const inner = slot[1](links);
    return html.replace(new RegExp('(<div[^>]*id="' + slot[0] + '"[^>]*>)[\\s\\S]*?(</div>)'), "$1" + inner + "$2");
  }
  return html.replace(/(<section[^>]*id="share-cta")/, relatedMarkup(links, "Related pages") + "$1");
}
function injectFaq(html, faqs, localized) {
  const block = faqMarkup(faqs, "Frequently asked questions") + faqI18nScript(localized);
  return html.replace(/(<section[^>]*id="share-cta")/, block + "$1");
}
function injectFaqSchema(html, faqs) {
  const node = faqNode(faqs);
  if (!node) return html;
  return html.replace(/(<script type="application\/ld\+json" data-generated="structured-data">)([\s\S]*?)(<\/script>)/, (m, a, json, c) => {
    try { const o = JSON.parse(json); (o["@graph"] = o["@graph"] || []).push(node); return a + JSON.stringify(o) + c; } catch (e) { return m; }
  });
}

function emit(type, slug, html, options) {
  html = inlineEntityTranslation(type, slug, html);
  html = inlineShareCta(html, SITE + "/" + type + "/" + slug + ".html");
  const rec = recordFor(type, slug);
  let lastmod = TODAY;
  if (rec && REC_KEY[type] || type === "protocol") {
    // entity pages sit one directory down: prefix every catalogue link
    const links = entityRelated(type, rec, W).map((l) => ({ ...l, href: "../" + l.href }));
    const faqs = entityFaqs(type, rec, W, { site: SITE });
    html = injectRelated(html, type, links);
    if (faqs.length) {
      const localized = entityFaqsLocalized(type, rec, STORE);
      html = injectFaq(html, faqs, localized);
      html = injectFaqSchema(html, faqs);
    }
    lastmod = recordDate(type, rec);
  }
  html = inlineCoreTranslation(type, slug, html);
  html = injectNav(html, "../");
  const file = path.join(PROTO, type, slug + ".html");
  fs.writeFileSync(file, html, "utf8");
  written.push({ type, slug, url: SITE + "/" + type + "/" + slug + ".html", enOnly: !!(options && options.enOnly), lastmod });
}

/* ---------- static navigation ----------
 * The header and footer are rendered by app.js, so a crawler that does not run JS
 * finds no navigation and no path into the catalogue. Inject a small plain-HTML
 * link block into every page so the hub pages and the full index are reachable. */
/* The same block is injected into root pages and into entity pages one level
   down, so the prefix has to be passed in rather than hard-coded. */
const staticNav = (B) => '<nav class="static-index" aria-label="Site sections">' +
  '<div class="container">' +
  '<span class="static-index-label">Site index</span>' +
  '<a href="' + B + 'sitemap.html">All pages</a>' +
  '<a href="' + B + 'categories.html">Categories</a>' +
  '<a href="' + B + 'brand.html">Brands</a>' +
  '<a href="' + B + 'apps.html">Apps</a>' +
  '<a href="' + B + 'cloud.html">Cloud platforms</a>' +
  '<a href="' + B + 'knowledge.html">Knowledge base</a>' +
  '<a href="' + B + 'compare.html">Comparisons</a>' +
  '<a href="' + B + 'products.html">Products</a>' +
  '<a href="' + B + 'compatibility.html">Compatibility</a>' +
  '<a href="' + B + 'models.html">Models & manuals</a>' +
  '<a href="' + B + 'troubleshooting.html">Troubleshooting</a>' +
  '<a href="' + B + 'certifications.html">Certifications</a>' +
  '<a href="' + B + 'markets.html">Markets</a>' +
  '<a href="' + B + 'amazon-best-sellers.html">Best sellers</a>' +
  '<a href="' + B + 'community.html">Community</a>' +
  '<a href="' + B + 'dataset.html">Open data</a>' +
  "</div></nav>";
function injectNav(html, B) {
  B = B || "";
  // replace any nav from a previous build - keeping the stale one would leave the
  // old (root-relative) links in place after the prefix scheme changed
  html = html.replace(/<nav class="static-index"[\s\S]*?<\/nav>/, "");
  const nav = staticNav(B);
  const i = html.lastIndexOf("</body>");
  if (i < 0) return html + nav;
  return html.slice(0, i) + nav + html.slice(i);
}
// hub pages live at the root and are written by build_seo, which runs before this
let navPatched = 0;
for (const f of fs.readdirSync(PROTO).filter((x) => x.endsWith(".html"))) {
  const abs = path.join(PROTO, f);
  const html = fs.readFileSync(abs, "utf8");
  const out = injectNav(html, "");
  if (out !== html) { fs.writeFileSync(abs, out, "utf8"); navPatched++; }
}
console.log("static nav injected into " + navPatched + " root pages");

/* ---------- builders ---------- */
/* Breadcrumb levels must resolve. /app/, /brand/ and friends are real
   directories on disk but nginx answers 403 for them, so the second level points
   at the published hub page instead. The last level carries no URL: Google's
   guidance is to omit `item` for the current page, not to send an empty string. */
const HUB_PAGE = { brand: "brand.html", app: "apps.html", cloud: "cloud.html", protocol: "knowledge.html",
  compare: "compare.html", category: "categories.html", product: "products.html",
  compatibility: "compatibility.html", model: "models.html", troubleshooting: "troubleshooting.html",
  certification: "certifications.html" };
function crumb(name, type, label) {
  return { "@type": "BreadcrumbList", itemListElement: [
    { "@type": "ListItem", position: 1, name: "Home", item: SITE + "/" },
    { "@type": "ListItem", position: 2, name: label, item: SITE + "/" + (HUB_PAGE[type] || type + ".html") },
    { "@type": "ListItem", position: 3, name: name }
  ] };
}

const TPL = {};
for (const [type, file] of Object.entries({
  brand: "brand-detail.html", app: "app-detail.html", cloud: "cloud-detail.html",
  protocol: "protocol-detail.html", compare: "compare-detail.html",
  category: "category-detail.html", product: "product.html",
  compatibility: "compatibility-detail.html", model: "model-detail.html",
  troubleshooting: "troubleshooting-detail.html", certification: "certification-detail.html"
})) TPL[type] = fs.readFileSync(path.join(PROTO, file), "utf8");

/* brand */
for (const b of W.IOT_BRANDS || []) {
  const name = b.name;
  const desc = describe([b.notes, b.app ? "Companion app: " + b.app : "", list(b.protocols).length ? "Protocols: " + list(b.protocols).join(", ") : "", list(b.categories).length ? "Covers " + list(b.categories).join(", ") + "." : ""], 158);
  const canonical = SITE + "/brand/" + b.slug + ".html";
  let h = TPL.brand;
  const s = [
    ["brand-crumb-name", esc(name)], ["brand-name", esc(name)],
    ["brand-summary", esc([name, b.hq].filter(Boolean).join(" \u00b7 "))],
    ["brand-app", esc(b.app || "\u2014")],
    ["brand-protocols", esc(list(b.protocols).join(" \u00b7 ") || "\u2014")],
    ["brand-categories", esc(list(b.categories).join(" \u00b7 ") || "\u2014")],
    ["brand-notes", esc(b.notes || "Research note pending.")]
  ];
  for (const [id, v] of s) h = setInner(h, id, v).html;
  h = setHref(h, "brand-official", b.url || "#").html;
  h = setInner(h, "brand-search-link", "Search brand content").html;
  const ld = { "@context": "https://schema.org", "@graph": [
    { "@type": "Organization", name: name, url: canonical, ...(isUrl(b.url) ? { sameAs: [b.url] } : {}), description: desc },
    crumb(name, "brand", "Brands")
  ]};
  emit("brand", b.slug, rebase(swapHead(h, headBlock({ title: pageTitle(name, "Brand knowledge hub"), description: desc, canonical, ld }))));
}

/* app */
for (const a of W.IOT_APP_DIRECTORY || []) {
  const name = a.name;
  const desc = describe([a.summary, a.category ? "Category: " + a.category + "." : "", a.brand ? "Brand: " + a.brand + "." : "", a.developer ? "Published by " + a.developer + "." : "", a.platforms ? "Available on " + a.platforms + "." : ""], 158);
  const canonical = SITE + "/app/" + a.slug + ".html";
  let h = TPL.app;
  const s = [
    ["app-crumb-name", esc(name)], ["app-name", esc(name)], ["app-summary", esc(a.summary || "")],
    ["app-brand", esc(a.brand || "\u2014")], ["app-platforms", esc(a.platforms || "iOS / Android")],
    ["app-protocols", esc((a.protocols || "").replace(/,\s*/g, " \u00b7 ") || "\u2014")],
    ["app-note", esc("Verify store availability, developer account and regional availability before installing. Listing developed by " + (a.developer || a.brand || "the vendor") + ".")]
  ];
  for (const [id, v] of s) h = setInner(h, id, v).html;
  h = setHref(h, "app-android", a.android_url || "#").html;
  h = setHref(h, "app-ios", a.ios_url || "#").html;
  h = setHref(h, "app-source", (isUrl(a.source) ? a.source : (isUrl(a.url) ? a.url : (isUrl(a.ios_url) ? a.ios_url : (isUrl(a.android_url) ? a.android_url : "apps.html"))))).html;
  const ld = { "@context": "https://schema.org", "@graph": [
    { "@type": "SoftwareApplication", name: name, url: canonical, description: desc,
      applicationCategory: "UtilitiesApplication", operatingSystem: a.platforms || "iOS, Android",
      ...(a.brand ? { author: { "@type": "Organization", name: a.brand } } : {}),
      ...(isUrl(a.source) ? { sameAs: [a.source] } : {}) },
    crumb(name, "app", "Apps")
  ]};
  emit("app", a.slug, rebase(swapHead(h, headBlock({ title: pageTitle(name, "IoT app download and details"), description: desc, canonical, ld }))));
}

/* cloud */
for (const c of W.IOT_CLOUDS || []) {
  const name = c.name;
  const desc = describe([c.notes, c.provider ? "Provider: " + c.provider + "." : "", list(c.protocols).length ? "Protocols: " + list(c.protocols).join(", ") + "." : "", list(c.regions).length ? "Regions: " + list(c.regions).join(", ") + "." : ""], 158);
  const canonical = SITE + "/cloud/" + c.slug + ".html";
  let h = TPL.cloud;
  const s = [
    ["cloud-crumb-name", esc(name)], ["cloud-name", esc(name)], ["cloud-provider", esc(c.provider || "")],
    ["cloud-summary", esc(desc)], ["cloud-protocols", esc(list(c.protocols).join(" \u00b7 ") || "\u2014")],
    ["cloud-regions", esc(list(c.regions).join(" \u00b7 ") || "\u2014")], ["cloud-status", esc(c.status || "\u2014")],
    ["cloud-price", esc(c.price || "\u2014")], ["cloud-notes", esc(c.notes || "")]
  ];
  for (const [id, v] of s) h = setInner(h, id, v).html;
  const logoMap = (W.IOT_LOGO_MAP && W.IOT_LOGO_MAP.clouds) || {};
  const logos = (Array.isArray(c.logos) && c.logos.length) ? c.logos : [{ file: (logoMap[c.slug] || {}).file, alt: name }];
  h = setInner(h, "cloud-logo", logos.map((l) => '<img src="assets/logos/' + esc(l.file) + '" width="96" height="96" decoding="async" alt="' + esc(l.alt || name) + ' logo">').join("")).html;
  if (logos.length > 1) h = h.replace('class="detail-logo dark"', 'class="detail-logo dark is-dual"');
  const providerLinks = (Array.isArray(c.links) ? c.links : []).filter((l) => l && l.url);
  const primary = providerLinks[0] || { label: "Official documentation", url: list(c.docs)[0] || c.url || "cloud.html" };
  h = setHref(h, "cloud-official", primary.url).html;
  h = setInner(h, "cloud-official", esc(primary.label || "Official documentation")).html;
  if (providerLinks[1]) {
    h = setHref(h, "cloud-official-secondary", providerLinks[1].url).html;
    h = setInner(h, "cloud-official-secondary", esc(providerLinks[1].label || "Secondary source")).html;
    h = h.replace(/id="cloud-official-secondary"([^>]*?) hidden/, 'id="cloud-official-secondary"$1');
  }
  const ld = { "@context": "https://schema.org", "@graph": [
    { "@type": "WebPage", name: name + " IoT platform guide", url: canonical, description: desc },
    crumb(name, "cloud", "Cloud platforms")
  ]};
  emit("cloud", c.slug, rebase(swapHead(h, headBlock({ title: pageTitle(name, "IoT platform deployment guide"), description: desc, canonical, ld }))));
}

/* protocol */
for (const p of K.protocols || []) {
  const name = p.name;
  const desc = describe([p.summary, p.category ? "Category: " + p.category + "." : "", p.range ? "Range: " + p.range + "." : "", p.topology ? "Topology: " + p.topology + "." : "", p.power ? "Power: " + p.power + "." : ""], 158);
  const canonical = SITE + "/protocol/" + p.slug + ".html";
  let h = TPL.protocol;
  const s = [
    ["protocol-crumb-name", esc(name)], ["protocol-name", esc(name)], ["protocol-summary", esc(p.summary || "")],
    ["protocol-category", esc(p.category || "\u2014")], ["protocol-range", esc(p.range || "\u2014")],
    ["protocol-power", esc(p.power || "\u2014")], ["protocol-topology", esc(p.topology || "\u2014")],
    ["protocol-use", esc(p.use || "\u2014")]
  ];
  for (const [id, v] of s) h = setInner(h, id, v).html;
  h = setHref(h, "protocol-source", (isUrl(p.source) ? p.source : (isUrl(p.url) ? p.url : "knowledge.html"))).html;
  const ld = { "@context": "https://schema.org", "@graph": [
    { "@type": "TechArticle", headline: name + " protocol guide", url: canonical, description: desc },
    crumb(name, "protocol", "Protocols")
  ]};
  emit("protocol", p.slug, rebase(swapHead(h, headBlock({ title: pageTitle(name, "IoT protocol guide"), description: desc, canonical, ld }))));
}

/* compare */
for (const x of W.IOT_COMPARISONS || []) {
  const title = x.title || x.slug;
  const desc = describe([x.summary, x.bestFor ? "Best for: " + x.bestFor + "." : "", x.a && x.b ? "Compares " + x.a + " with " + x.b + "." : ""], 158);
  const canonical = SITE + "/compare/" + x.slug + ".html";
  let h = TPL.compare;
  const s = [
    ["compare-crumb-title", esc(title)], ["compare-title", esc(title)], ["compare-summary", esc(x.summary || "")],
    ["compare-bestfor", esc(x.bestFor || "")], ["compare-verdict", esc(x.verdict || "")],
    ["compare-a", esc(x.a || "")], ["compare-b", esc(x.b || "")]
  ];
  for (const [id, v] of s) h = setInner(h, id, v).html;
  const ld = { "@context": "https://schema.org", "@graph": [
    { "@type": "WebPage", name: title, url: canonical, description: desc },
    crumb(title, "compare", "Comparisons")
  ]};
  emit("compare", x.slug, rebase(swapHead(h, headBlock({ title: pageTitle(title, "IoT comparison"), description: desc, canonical, ld }))));
}

/* category */
for (const c of W.IOT_CATEGORY_HUB || []) {
  const name = (c.names && (c.names.en || Object.values(c.names)[0])) || c.slug;
  const desc = describe([(c.descriptions && (c.descriptions.en || Object.values(c.descriptions)[0])) || (name + " category."), "Buying factors, shortlists, protocol notes and pricing guidance for " + name + "."], 158);
  const canonical = SITE + "/category/" + c.slug + ".html";
  let h = TPL.category;
  for (const [id, v] of [["category-crumb-name", esc(name)], ["category-name", esc(name)], ["category-summary", esc(desc)]])
    h = setInner(h, id, v).html;
  const ld = { "@context": "https://schema.org", "@graph": [
    { "@type": "CollectionPage", name: name + " IoT category", url: canonical, description: desc },
    crumb(name, "category", "Categories")
  ]};
  emit("category", c.slug, rebase(swapHead(h, headBlock({ title: pageTitle(name, "IoT category guide"), description: desc, canonical, ld }))));
}

/* product */
for (const p of W.IOT_PRODUCT_DIRECTORY || []) {
  const name = p.name;
  const desc = describe([p.summary, p.brand ? "Brand: " + p.brand + "." : "", p.category ? "Category: " + p.category + "." : ""], 158);
  const canonical = SITE + "/product/" + p.slug + ".html";
  let h = TPL.product;
  for (const [id, v] of [
    ["product-name", esc(name)], ["product-visual-name", esc(name)], ["product-summary", esc(p.summary || "")],
    ["product-score", esc(String(p.score == null ? "" : p.score))], ["product-price", esc(p.price || "")]
  ]) h = setInner(h, id, v).html;
  const ld = { "@context": "https://schema.org", "@graph": [
    { "@type": "Product", name: name, url: canonical, description: desc,
      ...(p.brand ? { brand: { "@type": "Brand", name: p.brand } } : {}),
      ...(p.category ? { category: p.category } : {}) },
    crumb(name, "product", "Products")
  ]};
  emit("product", p.slug, rebase(swapHead(h, headBlock({ title: pageTitle(name, "Product knowledge page"), description: desc, canonical, ld }))));

}

/* ---------- answer-first (GEO) block ----------
 * AI answer engines and search snippets reward a page that states the answer
 * first, lists the verifiable facts and shows when the record was checked. The
 * same block is painted by assets/expanded-content-ui.js at runtime, so the
 * static and interactive versions stay identical. */
const GEO_DIR = { compat: "compatibility", model: "model", issue: "troubleshooting", certification: "certification" };
const GEO_LABEL = { compat: "Compatibility", model: "Model and manual", issue: "Troubleshooting", certification: "Certification" };
function geoAnswer(type, x) {
  if (type === "compat") return (x.verdict ? x.verdict + ". " : "") + (x.summary || "");
  if (type === "model") return x.brand + " " + x.model + " is a " + (x.category || "device") + " in the IoT Atlas model directory. " + (x.summary || "") + (x.app ? " It is paired with the " + x.app + " app." : "");
  if (type === "issue") return (x.symptom || "") + (list(x.likelyCauses).length ? " Most common cause to check first: " + list(x.likelyCauses)[0] : "");
  return (x.summary || "") + (x.status ? " Status: " + x.status + "." : "") + (x.issuer ? " Issued or recognised by " + x.issuer + "." : "");
}
function geoFacts(type, x) {
  if (type === "compat") return [["Subject", x.subject], ["Works with", x.target], ["Verdict", x.verdict], ["Category", x.category], ["Last verified", x.lastVerified]];
  if (type === "model") return [["Brand", x.brand], ["Model", x.model], ["Category", x.category], ["Companion app", x.app], ["Protocols", list(x.protocols).join(" · ")], ["Power", x.power], ["Last verified", x.lastVerified]];
  if (type === "issue") return [["Applies to", list(x.appliesTo).slice(0, 3).join(", ")], ["Category", x.category], ["Escalate when", x.escalation], ["Last verified", x.lastVerified]];
  return [["Code", x.code], ["Region", x.region], ["Type", x.status], ["Issued by", x.issuer], ["Group", x.group], ["Last verified", x.lastVerified]];
}
function geoHtml(type, x) {
  const title = x.title || x.name || x.question || ((x.brand || "") + " " + (x.model || ""));
  const url = SITE + "/" + GEO_DIR[type] + "/" + x.slug + ".html";
  const cite = 'IoT Atlas. "' + title + '". ' + url + " Last verified " + (x.lastVerified || "") + ".";
  const facts = geoFacts(type, x).filter((f) => f[1]);
  return '<div class="container"><div class="geo-inner">' +
    '<div class="geo-head"><span class="pill green">Quick answer</span><span class="geo-meta">' + esc(GEO_LABEL[type]) + " · last verified " + esc(x.lastVerified || "") + "</span></div>" +
    '<p class="geo-answer">' + esc(geoAnswer(type, x)) + "</p>" +
    '<div class="geo-facts">' + facts.map((f) => '<div class="geo-fact"><small>' + esc(f[0]) + "</small><strong>" + esc(f[1]) + "</strong></div>").join("") + "</div>" +
    '<div class="geo-cite"><div><strong>How to cite this page</strong><code>' + esc(cite) + '</code></div><button type="button" class="btn" data-copy-cite>Copy citation</button></div>' +
    "</div></div>";
}

/* compatibility */
for (const x of W.IOT_COMPATIBILITY || []) {
  const name = x.title;
  const desc = describe([x.question, x.summary, "Requirements: " + list(x.requirements).join(", ") + "."], 158);
  const canonical = SITE + "/compatibility/" + x.slug + ".html";
  let h = TPL.compatibility;
  for (const [id, v] of [
    ["compat-title", esc(name)], ["compat-question", esc(x.question || name)], ["compat-verdict", esc(x.verdict || "")],
    ["compat-summary", esc(x.summary || "")], ["compat-subject", esc(x.subject || "")], ["compat-target", esc(x.target || "")],
    ["compat-category", esc(x.category || "")], ["compat-verified", esc(x.lastVerified || "")]
  ]) h = setInner(h, id, v).html;
  h = setInner(h, "compat-requirements", listHtml(x.requirements)).html;
  h = setInner(h, "compat-limitations", listHtml(x.limitations)).html;
  h = setInner(h, "compat-steps", stepsHtml(x.steps)).html;
  h = setInner(h, "compat-sources", sourceHtml(x.sources)).html;
  h = setInner(h, "geo-block", geoHtml("compat", x)).html;
  const ld = { "@context": "https://schema.org", "@graph": [
    crumb(name, "compatibility", "Compatibility")
  ]};
  const compatFaqs = entityFaqs("compatibility", x, W, { site: SITE });
  if (compatFaqs.length) {
    ld["@graph"].unshift(faqNode(compatFaqs));
    h = injectFaq(h, compatFaqs, entityFaqsLocalized("compatibility", x, STORE_ALL));
  }
  emit("compatibility", x.slug, rebase(swapHead(h, headBlock({ title: pageTitle(name, "IoT compatibility guide"), description: desc, canonical, ld }))));
}

/* model */
for (const x of W.IOT_MODELS || []) {
  const name = x.brand + " " + x.model;
  const desc = describe([x.summary, "App: " + (x.app || "verify"), "Protocols: " + list(x.protocols).join(", ") + "."], 158);
  const canonical = SITE + "/model/" + x.slug + ".html";
  let h = TPL.model;
  for (const [id, v] of [
    ["model-title", esc(name)], ["model-name", esc(x.model)], ["model-brand", esc(x.brand)], ["model-category", esc(x.category || "")],
    ["model-summary", esc(x.summary || "")], ["model-status", esc(x.status || "")], ["model-app", esc(x.app || "")],
    ["model-protocols", esc(list(x.protocols).join(" · "))], ["model-power", esc(x.power || "")],
    ["model-storage", esc(list(x.storage).join(" · "))], ["model-verified", esc(x.lastVerified || "")]
  ]) h = setInner(h, id, v).html;
  h = setHref(h, "model-manual", x.manualUrl || x.supportUrl || "models.html").html;
  h = setHref(h, "model-support", x.supportUrl || x.manualUrl || "models.html").html;
  h = setInner(h, "model-specs", specHtml(x.specs)).html;
  h = setInner(h, "model-sources", sourceHtml(x.sources)).html;
  h = setInner(h, "geo-block", geoHtml("model", x)).html;
  const ld = { "@context": "https://schema.org", "@graph": [
    { "@type": "Product", name: x.model, url: canonical, description: desc, brand: { "@type": "Brand", name: x.brand }, category: x.category || "" },
    crumb(name, "model", "Models and manuals")
  ]};
  const modelFaqs = entityFaqs("model", x, W, { site: SITE });
  if (modelFaqs.length) {
    ld["@graph"].push(faqNode(modelFaqs));
    h = injectFaq(h, modelFaqs, entityFaqsLocalized("model", x, STORE_ALL));
  }
  emit("model", x.slug, rebase(swapHead(h, headBlock({ title: pageTitle(name, "Model and manual"), description: desc, canonical, ld }))));
}

/* troubleshooting */
for (const x of W.IOT_TROUBLESHOOTING || []) {
  const name = x.title;
  const desc = describe([x.symptom, "Likely causes: " + list(x.likelyCauses).join(", ") + "."], 158);
  const canonical = SITE + "/troubleshooting/" + x.slug + ".html";
  let h = TPL.troubleshooting;
  for (const [id, v] of [["issue-title", esc(name)], ["issue-symptom", esc(x.symptom || "")], ["issue-category", esc(x.category || "")], ["issue-escalation", esc(x.escalation || "")], ["issue-verified", esc(x.lastVerified || "")]]) h = setInner(h, id, v).html;
  h = setInner(h, "issue-applies", listHtml(x.appliesTo)).html;
  h = setInner(h, "issue-causes", listHtml(x.likelyCauses)).html;
  h = setInner(h, "issue-checks", listHtml(x.quickChecks)).html;
  h = setInner(h, "issue-steps", stepsHtml(x.steps)).html;
  h = setInner(h, "issue-sources", sourceHtml(x.sources)).html;
  h = setInner(h, "geo-block", geoHtml("issue", x)).html;
  const ld = { "@context": "https://schema.org", "@graph": [
    { "@type": "HowTo", name: name, description: x.symptom || desc, step: list(x.steps).map((s, i) => ({ "@type": "HowToStep", position: i + 1, text: s })) },
    crumb(name, "troubleshooting", "Troubleshooting")
  ]};
  const issueFaqs = entityFaqs("troubleshooting", x, W, { site: SITE });
  if (issueFaqs.length) {
    ld["@graph"].push(faqNode(issueFaqs));
    h = injectFaq(h, issueFaqs, entityFaqsLocalized("troubleshooting", x, STORE_ALL));
  }
  emit("troubleshooting", x.slug, rebase(swapHead(h, headBlock({ title: pageTitle(name, "IoT troubleshooting guide"), description: desc, canonical, ld }))));
}

/* certification */
for (const x of W.IOT_CERTIFICATIONS || []) {
  const name = x.name;
  const desc = describe([x.summary, "Region: " + x.region + ".", "Applies to: " + list(x.appliesTo).join(", ") + "."], 158);
  const canonical = SITE + "/certification/" + x.slug + ".html";
  let h = TPL.certification;
  for (const [id, v] of [["cert-title", esc(name)], ["cert-crumb-title", esc(name)], ["cert-code", esc(x.code || "")], ["cert-region", esc(x.region || "")], ["cert-group", esc(x.group || "Certification")], ["cert-status", esc(x.status || "")], ["cert-issuer", esc(x.issuer || "")], ["cert-summary", esc(x.summary || "")], ["cert-meaning", esc(x.meaning || "")], ["cert-verified", esc(x.lastVerified || "")]]) h = setInner(h, id, v).html;
  h = setInner(h, "cert-applies", listHtml(x.appliesTo)).html;
  h = setInner(h, "cert-gaps", listHtml(x.doesNotCover)).html;
  h = setInner(h, "cert-checklist", listHtml(x.checklist)).html;
  h = setInner(h, "cert-sources", sourceHtml(x.sources)).html;
  h = setInner(h, "geo-block", geoHtml("certification", x)).html;
  h = setInner(h, "cert-related", (W.IOT_CERTIFICATIONS || []).filter((v) => v.slug !== x.slug && (v.group === x.group || v.region === x.region)).slice(0, 4).map((v) => '<a class="card expanded-card" href="./' + v.slug + '.html"><span class="pill blue">' + esc(v.code) + '</span><h3>' + esc(v.name) + '</h3><p>' + esc(v.summary || "") + '</p><span class="text-link">Open guide →</span></a>').join("")).html;
  const ld = { "@context": "https://schema.org", "@graph": [
    { "@type": "WebPage", name: name + " certification guide", url: canonical, description: desc },
    crumb(name, "certification", "Certifications")
  ]};
  const certFaqs = entityFaqs("certification", x, W, { site: SITE });
  if (certFaqs.length) {
    ld["@graph"].unshift(faqNode(certFaqs));
    h = injectFaq(h, certFaqs, entityFaqsLocalized("certification", x, STORE_ALL));
  }
  emit("certification", x.slug, rebase(swapHead(h, headBlock({ title: pageTitle(name, "IoT certification guide"), description: desc, canonical, ld }))));
}

/* ---------- crawlable HTML sitemap ----------
 * Every hub page renders its entity links with JavaScript, so a crawler that does
 * not execute JS sees no path into the 1,469 pre-rendered pages. This writes one
 * plain-HTML index that links all of them, and the footer links to it from every
 * page, so each entity is one hop away. */
const esc2 = (v) => String(v == null ? "" : v).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
const groups = [
  { key: "category", title: "Categories", items: (W.IOT_CATEGORY_HUB || []).map((c) => ({ url: "category/" + c.slug + ".html", label: (c.names && (c.names.en || Object.values(c.names)[0])) || c.slug })) },
  { key: "brand", title: "Brands", items: (W.IOT_BRANDS || []).map((b) => ({ url: "brand/" + b.slug + ".html", label: b.name })) },
  { key: "app", title: "Apps", items: (W.IOT_APP_DIRECTORY || []).map((a) => ({ url: "app/" + a.slug + ".html", label: a.name, group: a.category || "Other" })) },
  { key: "cloud", title: "Cloud and IoT platforms", items: (W.IOT_CLOUDS || []).map((c) => ({ url: "cloud/" + c.slug + ".html", label: c.name })) },
  { key: "protocol", title: "Protocols and standards", items: (K.protocols || []).map((x) => ({ url: "protocol/" + x.slug + ".html", label: x.name, group: x.category || "Other" })) },
  { key: "compare", title: "Comparisons", items: (W.IOT_COMPARISONS || []).map((x) => ({ url: "compare/" + x.slug + ".html", label: x.title || x.slug })) },
  { key: "product", title: "Products", items: (W.IOT_PRODUCT_DIRECTORY || []).map((x) => ({ url: "product/" + x.slug + ".html", label: x.name })) },
  { key: "compatibility", title: "Compatibility guides", items: (W.IOT_COMPATIBILITY || []).map((x) => ({ url: "compatibility/" + x.slug + ".html", label: x.title })) },
  { key: "model", title: "Models and manuals", items: (W.IOT_MODELS || []).map((x) => ({ url: "model/" + x.slug + ".html", label: x.brand + " " + x.model })) },
  { key: "troubleshooting", title: "Troubleshooting", items: (W.IOT_TROUBLESHOOTING || []).map((x) => ({ url: "troubleshooting/" + x.slug + ".html", label: x.title, group: x.category || "Other" })) },
  { key: "certification", title: "Certifications", items: (W.IOT_CERTIFICATIONS || []).map((x) => ({ url: "certification/" + x.slug + ".html", label: x.name })) }
];
function groupByKey(items) {
  const m = {};
  for (const it of items) (m[it.group || ""] = m[it.group || ""] || []).push(it);
  return Object.keys(m).sort().map((k) => [k, m[k].sort((a, b) => String(a.label).localeCompare(String(b.label)))]);
}
let smBody = "";
for (const g of groups) {
  const sorted = g.items.slice().sort((a, b) => String(a.label).localeCompare(String(b.label)));
  smBody += '<section class="section compact"><div class="container">';
  smBody += '<h2 id="' + g.key + '">' + esc2(g.title) + " <small>(" + g.items.length + ")</small></h2>";
  if (g.key === "app" || g.key === "protocol") {
    for (const [gk, list] of groupByKey(g.items)) {
      smBody += "<h3>" + esc2(gk || "Other") + " <small>(" + list.length + ")</small></h3>";
      smBody += '<ul class="sitemap-list">' + list.map((it) => '<li><a href="' + it.url + '">' + esc2(it.label) + "</a></li>").join("") + "</ul>";
    }
  } else {
    smBody += '<ul class="sitemap-list">' + sorted.map((it) => '<li><a href="' + it.url + '">' + esc2(it.label) + "</a></li>").join("") + "</ul>";
  }
  smBody += "</div></section>";
}
const totalLinks = groups.reduce((n, g) => n + g.items.length, 0);
let smIndex = '<!doctype html><html lang="en"><head><meta charset="utf-8">' +
  '<meta name="viewport" content="width=device-width,initial-scale=1">' +
  "<title>All pages | IoT Atlas site index</title>" +
  '<meta name="description" content="Complete index of every IoT Atlas page: ' + totalLinks + ' brands, apps, platforms, protocols, comparisons, models, manuals, troubleshooting and certifications.">' +
  '<link rel="canonical" href="' + SITE + '/sitemap.html">' +
  '<link rel="alternate" hreflang="en" href="' + SITE + '/sitemap.html">' +
  '<link rel="alternate" hreflang="es" href="' + SITE + '/sitemap.html?lang=es">' +
  '<link rel="alternate" hreflang="fr" href="' + SITE + '/sitemap.html?lang=fr">' +
  '<link rel="alternate" hreflang="x-default" href="' + SITE + '/sitemap.html">' +
  '<script type="application/ld+json">{"@context":"https://schema.org","@type":"CollectionPage","name":"All pages | IoT Atlas site index","url":"' + SITE + '/sitemap.html","inLanguage":["en","es","fr"]}</script>' +
  '<meta name="robots" content="index,follow,max-image-preview:large">' +
  '<meta property="og:type" content="website">' +
  '<meta property="og:site_name" content="IoT Atlas">' +
  '<meta property="og:title" content="All pages | IoT Atlas site index">' +
  '<meta property="og:description" content="Complete index of every IoT Atlas page.">' +
  '<meta property="og:url" content="' + SITE + '/sitemap.html">' +
  '<meta property="og:image" content="' + SITE + '/assets/og-default.png">' +
  '<meta property="og:image:width" content="1200">' +
  '<meta property="og:image:height" content="630">' +
  '<meta property="og:image:alt" content="All pages | IoT Atlas site index">' +
  '<meta property="og:locale" content="en_US">' +
  '<meta property="og:locale:alternate" content="es_ES">' +
  '<meta property="og:locale:alternate" content="fr_FR">' +
  '<meta name="twitter:card" content="summary_large_image">' +
  '<meta name="twitter:image" content="' + SITE + '/assets/og-default.png">' +
  '<meta name="twitter:image:alt" content="All pages | IoT Atlas site index">' +
  '<meta name="twitter:title" content="All pages | IoT Atlas site index">' +
  '<meta name="twitter:description" content="Complete index of every IoT Atlas page.">' +
  '<link rel="stylesheet" href="assets/styles.css?v=20261008t">' +
  "</head><body data-page=\"sitemap\"><a class=\"skip-link\" href=\"#main\">Skip to content</a>" +
  '<div id="site-header"></div><main id="main">' +
  '<section class="page-hero"><div class="container"><span class="eyebrow">Index</span>' +
  "<h1>All pages</h1><p class=\"lede\">Every catalogue page on IoT Atlas, in plain HTML. " + totalLinks + " destinations across brands, apps, platforms, protocols, comparisons and categories.</p></div></section>" +
  smBody + "</main><div id=\"site-footer\"></div>" +
  '<script src="assets/data.js?v=20261008t"></script><script src="assets/i18n.js?v=20261008t"></script>' +
  '<script src="assets/consent.js?v=20261008t"></script><script src="assets/analytics-config.js?v=20261008t"></script>' +
  '<script src="assets/analytics.js?v=20261008t"></script><script src="assets/monetization-config.js?v=20261008t"></script>' +
  '<script src="assets/monetization.js?v=20261008t"></script><script src="assets/entity-urls.js?v=20261008t"></script>' +
  '<script src="assets/app.js?v=20261008t"></script></body></html>';
smIndex = smIndex.replace(/\?v=20261008t/g, VERSIONED);
fs.writeFileSync(path.join(PROTO, "sitemap.html"), smIndex, "utf8");
console.log("wrote sitemap.html with " + totalLinks + " static entity links");

/* ---------- sitemap for the generated pages ---------- */
const sm = ['<?xml version="1.0" encoding="UTF-8"?>',
  '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9" xmlns:xhtml="http://www.w3.org/1999/xhtml">'];
for (const e of written) {
  sm.push("  <url>");
  sm.push("    <loc>" + e.url + "</loc>");
  sm.push("    <lastmod>" + (e.lastmod || TODAY) + "</lastmod>");
  sm.push('    <xhtml:link rel="alternate" hreflang="en" href="' + e.url + '"/>');
  if (!e.enOnly) {
    sm.push('    <xhtml:link rel="alternate" hreflang="es" href="' + e.url + '?lang=es"/>');
    sm.push('    <xhtml:link rel="alternate" hreflang="fr" href="' + e.url + '?lang=fr"/>');
    sm.push('    <xhtml:link rel="alternate" hreflang="x-default" href="' + e.url + '"/>');
  }
  sm.push("  </url>");
}
sm.push("</urlset>");
fs.writeFileSync(path.join(PROTO, "sitemap-entities.xml"), sm.join("\n") + "\n", "utf8");

const byType = {};
written.forEach(w => byType[w.type] = (byType[w.type] || 0) + 1);
console.log("pre-rendered " + written.length + " entity pages");
Object.entries(byType).sort((a, b) => b[1] - a[1]).forEach(([k, v]) => console.log("  " + k.padEnd(10) + v));
console.log("wrote sitemap-entities.xml");



