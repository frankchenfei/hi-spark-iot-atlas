/**
 * Related-entity links for catalogue pages.
 *
 * Internal links are the cheapest ranking lever the site has: every entity page
 * gains a "related" block built from fields that already exist (same brand, same
 * category, same protocol, competing platform, the two sides of a comparison).
 * Nothing is invented and no link points outside the catalogue.
 */
const clean = (v) => String(v == null ? "" : v).replace(/\s+/g, " ").trim();
const arr = (v) => (Array.isArray(v) ? v.filter(Boolean) : (v ? [v] : []));
const same = (a, b) => clean(a).toLowerCase() === clean(b).toLowerCase();

export function entityRelated(type, rec, W) {
  const brands = W.IOT_BRANDS || [], apps = W.IOT_APP_DIRECTORY || [], clouds = W.IOT_CLOUDS || [];
  const K = W.IOT_KNOWLEDGE || {}, cats = W.IOT_CATEGORY_HUB || [], products = W.IOT_PRODUCT_DIRECTORY || [];
  const links = [];
  const add = (href, label, meta) => { if (href && label && !links.some((l) => l.href === href)) links.push({ href, label: clean(label), meta: clean(meta || "") }); };

  if (type === "app") {
    apps.filter((a) => same(a.brand, rec.brand) && a.slug !== rec.slug).slice(0, 3).forEach((a) => add("app/" + a.slug + ".html", a.name, a.category));
    apps.filter((a) => same(a.category, rec.category) && a.slug !== rec.slug).slice(0, 3).forEach((a) => add("app/" + a.slug + ".html", a.name, a.category));
    const b = brands.find((x) => same(x.name, rec.brand));
    if (b) add("brand/" + b.slug + ".html", b.name + " brand page", "Brand");
    clean(rec.protocols).split(",").map((s) => s.trim()).filter(Boolean).forEach((p) => {
      const pr = (K.protocols || []).find((x) => same(x.name, p));
      if (pr) add("protocol/" + pr.slug + ".html", pr.name + " explained", "Protocol");
    });
  } else if (type === "brand") {
    apps.filter((a) => same(a.brand, rec.name)).slice(0, 4).forEach((a) => add("app/" + a.slug + ".html", a.name + " app", a.category));
    cats.filter((c) => arr(c.brands).some((x) => same(x, rec.slug) || same(x, rec.name))).slice(0, 2).forEach((c) => add("category/" + c.slug + ".html", clean((c.names || {}).en || c.slug) + " category", "Category"));
    arr(rec.protocols).forEach((p) => {
      const pr = (K.protocols || []).find((x) => same(x.name, p) || same(x.slug, p));
      if (pr) add("protocol/" + pr.slug + ".html", pr.name + " explained", "Protocol");
    });
  } else if (type === "protocol") {
    products.filter((p) => clean(p.protocols).toLowerCase().includes(clean(rec.name).toLowerCase())).slice(0, 3).forEach((p) => add("product/" + p.slug + ".html", p.name, p.category));
    apps.filter((a) => clean(a.protocols).toLowerCase().includes(clean(rec.name).toLowerCase())).slice(0, 3).forEach((a) => add("app/" + a.slug + ".html", a.name + " app", a.category));
    (K.protocols || []).filter((x) => same(x.category, rec.category) && x.slug !== rec.slug).slice(0, 3).forEach((x) => add("protocol/" + x.slug + ".html", x.name, x.category));
  } else if (type === "cloud") {
    clouds.filter((c) => same(c.type, rec.type) && c.slug !== rec.slug).slice(0, 4).forEach((c) => add("cloud/" + c.slug + ".html", c.name, c.type));
    arr(rec.compare).forEach((x) => { const c = clouds.find((y) => same(y.name, x) || same(y.slug, x)); if (c) add("cloud/" + c.slug + ".html", c.name, c.type); });
    (W.IOT_COMPARISONS || []).filter((c) => same(c.a, rec.name) || same(c.b, rec.name) || same(c.a, rec.provider) || same(c.b, rec.provider)).slice(0, 3).forEach((c) => add("compare/" + c.slug + ".html", c.title, "Comparison"));
  } else if (type === "compare") {
    const b1 = brands.find((x) => same(x.name, rec.a)), b2 = brands.find((x) => same(x.name, rec.b));
    if (b1) add("brand/" + b1.slug + ".html", rec.a + " brand page", "Brand");
    if (b2) add("brand/" + b2.slug + ".html", rec.b + " brand page", "Brand");
    apps.filter((a) => same(a.brand, rec.a) || same(a.brand, rec.b)).slice(0, 2).forEach((a) => add("app/" + a.slug + ".html", a.name + " app", a.category));
    const c = clouds.find((x) => same(x.name, rec.a) || same(x.name, rec.b));
    if (c) add("cloud/" + c.slug + ".html", c.name + " platform", c.type);
  } else if (type === "category") {
    arr(rec.brands).slice(0, 3).forEach((s) => { const b = brands.find((x) => same(x.slug, s) || same(x.name, s)); if (b) add("brand/" + b.slug + ".html", b.name, "Brand"); });
    arr(rec.apps).slice(0, 3).forEach((s) => { const a = apps.find((x) => same(x.slug, s) || same(x.name, s)); if (a) add("app/" + a.slug + ".html", a.name + " app", a.category); });
    arr(rec.protocols).slice(0, 3).forEach((p) => { const pr = (K.protocols || []).find((x) => same(x.name, p) || same(x.slug, p)); if (pr) add("protocol/" + pr.slug + ".html", pr.name, pr.category); });
  } else if (type === "product") {
    products.filter((p) => same(p.category, rec.category) && p.slug !== rec.slug).slice(0, 3).forEach((p) => add("product/" + p.slug + ".html", p.name, p.category));
    const b = brands.find((x) => same(x.name, rec.brand));
    if (b) add("brand/" + b.slug + ".html", b.name + " brand page", "Brand");
    const cat = cats.find((c) => same(clean((c.names || {}).en), rec.category) || same(c.slug, rec.category));
    if (cat) add("category/" + cat.slug + ".html", clean((cat.names || {}).en) + " category", "Category");
  }
  return links.slice(0, 8);
}

export function relatedMarkup(items, heading) {
  if (!items || !items.length) return "";
  const esc = (v) => String(v == null ? "" : v).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
  return '<section class="section compact"><div class="container">' +
    '<h2 class="group-heading">' + esc(heading || "Related pages") + "</h2>" +
    '<div class="related-grid">' +
    items.map((l) => '<a class="related-card" href="' + esc(l.href) + '"><span class="pill blue">' + esc(l.meta || "Reference") + "</span><strong>" + esc(l.label) + "</strong></a>").join("") +
    "</div></div></section>";
}

/* Cards only, for slots that already have their own heading. */
export function relatedCards(items) {
  if (!items || !items.length) return "";
  const esc = (v) => String(v == null ? "" : v).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
  return items.map((l) => '<a class="related-card" href="' + esc(l.href) + '"><span class="pill blue">' + esc(l.meta || "Reference") + "</span><strong>" + esc(l.label) + "</strong></a>").join("");
}

/* Compact link list, for the narrow sidebar slots. */
export function relatedCompact(items) {
  if (!items || !items.length) return "";
  const esc = (v) => String(v == null ? "" : v).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
  return '<div class="related-list">' + items.map((l) => '<a href="' + esc(l.href) + '"><span>' + esc(l.label) + "</span><small>" + esc(l.meta || "") + "</small></a>").join("") + "</div>";
}
