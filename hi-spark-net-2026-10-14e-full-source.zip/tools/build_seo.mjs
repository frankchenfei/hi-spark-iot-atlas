#!/usr/bin/env node
/**
 * SEO / GEO prerender.
 *
 *   node tools/build_seo.mjs
 *
 * Writes into every page <head>: canonical, hreflang alternates, Open Graph,
 * Twitter card and a robots directive. Also regenerates:
 *   - sitemap.xml   (with hreflang alternates)
 *   - robots.txt
 *   - llms.txt      (Generative Engine Optimization summary for AI answer engines)
 *
 * Configure the production domain with SITE_URL before deploying.
 */
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { APP_LOAD_ORDER } from "./app-batches.mjs";
import { injectShare } from "./share-cta-markup.mjs";
import vm from "node:vm";

const PROTO = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const SITE_URL = (process.env.SITE_URL || "https://hi-spark.net").replace(/\/$/, "");
const LOCALES = ["en", "es", "fr"];

// pages that should never be indexed
// The seven detail templates take their subject from a query parameter, so their
// real content now lives at /brand/<slug>.html and friends. Keeping them indexable
// would put one thin page in front of 1,461 pre-rendered ones.
// Two different reasons to keep a page out of the index:
//  - internal/demo pages: noindex, nofollow (nothing worth following)
//  - the seven detail templates: noindex, FOLLOW - they still link to the
//    pre-rendered entity pages, so let crawlers pass equity through them.
const NOINDEX = new Set(["styleguide.html", "logo-gallery.html", "perf-demo.html", "404.html"]);
// Policy: every published page ships in English, Spanish and French, so there is
// no English-only exception list any more. Keep the set (empty) because the sitemap
// and head builders still branch on it, and tools/audit_site.mjs fails the build if
// a page is missing its es/fr alternates.
const EN_ONLY = new Set();
const NOINDEX_FOLLOW = new Set([
  "brand-detail.html","app-detail.html","cloud-detail.html","protocol-detail.html",
  "compare-detail.html","category-detail.html","product.html",
  "compatibility-detail.html","model-detail.html","troubleshooting-detail.html","certification-detail.html"
]);
const robotsFor = (f) => NOINDEX.has(f) ? "noindex,nofollow"
  : NOINDEX_FOLLOW.has(f) ? "noindex,follow"
  : "index,follow,max-image-preview:large";

const files = fs.readdirSync(PROTO).filter((f) => f.endsWith(".html"));
const titleOf = (h) => (h.match(/<title>([^<]*)<\/title>/) || [, "IoT Atlas"])[1].trim();
const descOf = (h) => ((h.match(/<meta name="description" content="([^"]*)"/) || [, ""])[1] || "").trim();
const urlFor = (f, lang) =>
  SITE_URL + "/" + (f === "index.html" ? "" : f) + (lang && lang !== "en" ? "?lang=" + lang : "");

const entries = [];
let updated = 0;

for (const f of files) {
  const p = path.join(PROTO, f);
  let html = fs.readFileSync(p, "utf8");
  const title = titleOf(html);
  const desc = descOf(html) || title + " - IoT Atlas, independent IoT research.";
  const canonical = SITE_URL + "/" + (f === "index.html" ? "" : f);

  // strip anything a previous run added
  html = html.replace(/<!--seo:start-->[\s\S]*?<!--seo:end-->/g, "");

  const block = [
    "<!--seo:start-->",
    '<link rel="canonical" href="' + canonical + '">',
    ...(EN_ONLY.has(f) ? [] : [LOCALES.map((l) => '<link rel="alternate" hreflang="' + l + '" href="' + urlFor(f, l) + '">').join("\n"), '<link rel="alternate" hreflang="x-default" href="' + urlFor(f, "en") + '">']),
    '<meta name="robots" content="' + robotsFor(f) + '">',
    '<link rel="alternate" type="application/atom+xml" href="feed.xml" title="IoT Atlas - recently verified records">',
    '<link rel="icon" href="favicon.ico" sizes="any">',
    '<link rel="icon" type="image/png" sizes="32x32" href="favicon-32.png">',
    '<link rel="icon" type="image/png" sizes="192x192" href="icon-192.png">',
    '<link rel="apple-touch-icon" href="apple-touch-icon.png">',
    '<link rel="manifest" href="manifest.webmanifest">',
    '<meta name="theme-color" content="#0c7475">',
    '<meta property="og:type" content="website">',
    '<meta property="og:site_name" content="IoT Atlas">',
    '<meta property="og:title" content="' + title.replace(/"/g, "&quot;") + '">',
    '<meta property="og:description" content="' + desc.replace(/"/g, "&quot;") + '">',
    '<meta property="og:url" content="' + canonical + '">',
    '<meta property="og:image" content="' + SITE_URL + '/assets/og-default.png">',
    '<meta property="og:image:width" content="1200">',
    '<meta property="og:image:height" content="630">',
    '<meta property="og:locale" content="en_US">',
    ...(EN_ONLY.has(f) ? [] : ['<meta property="og:locale:alternate" content="es_ES">', '<meta property="og:locale:alternate" content="fr_FR">']),
    '<meta name="twitter:card" content="summary_large_image">',
    '<meta name="twitter:image" content="' + SITE_URL + '/assets/og-default.png">',
    '<meta name="twitter:title" content="' + title.replace(/"/g, "&quot;") + '">',
    '<meta name="twitter:description" content="' + desc.replace(/"/g, "&quot;") + '">',
    "<!--seo:end-->"
  ].join("\n");

  // Prominent share bar under the hero + call-to-action block at the end.
  // Both are written into the static HTML so they exist without JavaScript.
  html = injectShare(html, { url: canonical, title, base: "" });
  html = html.replace("</head>", block + "\n</head>");
  fs.writeFileSync(p, html, "utf8");
  updated++;

  if (!NOINDEX.has(f) && !NOINDEX_FOLLOW.has(f)) entries.push({ f, title, canonical });
}
console.log("SEO head prerendered into " + updated + " pages");

// ---------------- sitemap ----------------
const today = new Date().toISOString().slice(0, 10);
const sitemap = ['<?xml version="1.0" encoding="UTF-8"?>',
  '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9" xmlns:xhtml="http://www.w3.org/1999/xhtml">'];
for (const e of entries) {
  sitemap.push("  <url>");
  sitemap.push("    <loc>" + e.canonical + "</loc>");
  sitemap.push("    <lastmod>" + today + "</lastmod>");
  sitemap.push("    <changefreq>weekly</changefreq>");
  sitemap.push("    <priority>" + (e.f === "index.html" ? "1.0" : "0.7") + "</priority>");
  // Pages that exist in English only must not advertise es/fr alternates: the
  // language switch would show English content under a Spanish or French hreflang.
  if (EN_ONLY.has(e.f)) {
    sitemap.push('    <xhtml:link rel="alternate" hreflang="en" href="' + urlFor(e.f, "en") + '"/>');
  } else {
    for (const l of LOCALES) sitemap.push('    <xhtml:link rel="alternate" hreflang="' + l + '" href="' + urlFor(e.f, l) + '"/>');
    sitemap.push('    <xhtml:link rel="alternate" hreflang="x-default" href="' + urlFor(e.f, "en") + '"/>');
  }
  sitemap.push("  </url>");
}
sitemap.push("</urlset>");
fs.writeFileSync(path.join(PROTO, "sitemap.xml"), sitemap.join("\n") + "\n", "utf8");

// ---------------- IndexNow key ----------------
// The key file must sit at the site root and match tools/indexnow-key.json, which
// tools/ping_indexnow.mjs reads when it submits URLs to the IndexNow API.
const INKEY = JSON.parse(fs.readFileSync(path.join(PROTO, "tools", "indexnow-key.json"), "utf8")).key;
fs.writeFileSync(path.join(PROTO, INKEY + ".txt"), INKEY + "\n", "utf8");

// ---------------- robots ----------------
fs.writeFileSync(path.join(PROTO, "robots.txt"), [
  "User-agent: *",
  "Allow: /",
  "Disallow: /styleguide.html",
  "Disallow: /logo-gallery.html",
  "",
  "# AI answer engines and search agents are explicitly welcome (GEO).",
  "# Each crawler is listed by name so the permission is unambiguous.",
  ...["GPTBot","OAI-SearchBot","ChatGPT-User","ClaudeBot","Claude-Web","anthropic-ai",
      "PerplexityBot","Perplexity-User","Google-Extended","Applebot","Applebot-Extended",
      "CCBot","Bytespider","Amazonbot","DuckAssistBot","YouBot","Meta-ExternalAgent",
      "Meta-ExternalFetcher","cohere-ai","MistralAI-User","Timpibot","Diffbot",
      "ImagesiftBot","omgili","omgilibot","PetalBot","SemrushBot-OCOB","AhrefsBot",
      "Bingbot","YandexBot","Sogou web spider","Baiduspider"].flatMap((a) => ["User-agent: " + a, "Allow: /", ""]),
  "# Non-search scrapers that add no value",
  "User-agent: SemrushBot",
  "Disallow: /",
  "",
  "User-agent: MJ12bot",
  "Disallow: /",
  "",
  "User-agent: DotBot",
  "Disallow: /",
  "",
  "# Content signals: free to read, free to cite with attribution.",
  "Content-Signal: ai-train=yes, search=yes, ai-input=yes",
  "",
  "Sitemap: " + SITE_URL + "/sitemap.xml",
  "Sitemap: " + SITE_URL + "/sitemap-entities.xml",
  ""
].join("\n"), "utf8");

// ---------------- llms.txt (GEO) ----------------
function load(asset, key) {
  try {
    const ctx = { window: {} };
    vm.createContext(ctx);
    vm.runInContext(fs.readFileSync(path.join(PROTO, "assets", asset), "utf8"), ctx);
    return ctx.window[key];
  } catch (e) { return null; }
}
/* The catalogue is split across ordered batch files: each batch reads the array
   the previous one left on window and appends to it, so every batch must run in
   one shared context, in order. Loading only the first batch is what made
   llms.txt under-report the app count. */
function loadMany(files, key) {
  const ctx = { window: {} };
  vm.createContext(ctx);
  for (const f of files) {
    const p = path.join(PROTO, "assets", f);
    if (!fs.existsSync(p)) continue;
    try { vm.runInContext(fs.readFileSync(p, "utf8"), ctx, { filename: f }); } catch (e) {}
  }
  return ctx.window[key];
}
const APP_FILES = APP_LOAD_ORDER;

const K = loadMany(["knowledge.js", "knowledge-extra.js", "knowledge-extra2.js"], "IOT_KNOWLEDGE");
const APPS = loadMany(APP_FILES, "IOT_APP_DIRECTORY") || [];
const BRANDS = loadMany(["brands.js"], "IOT_BRANDS") || [];
const CLOUDS = load("clouds.js", "IOT_CLOUDS") || [];
const COMPS = load("compare-data.js", "IOT_COMPARISONS") || [];
const AMZ = load("amazon-rankings.js", "IOT_AMAZON") || { products: [], categories: [] };
const CATS = load("category-hub.js", "IOT_CATEGORY_HUB") || [];
const COMPAT = load("compatibility-data.js", "IOT_COMPATIBILITY") || [];
const MODELS = load("model-data.js", "IOT_MODELS") || [];
const ISSUES = load("troubleshooting-data.js", "IOT_TROUBLESHOOTING") || [];
const CERTS = load("certification-data.js", "IOT_CERTIFICATIONS") || [];

const out = [];
out.push("# IoT Atlas");
out.push("");
out.push("> Independent IoT decision platform covering devices, protocols, apps, cloud platforms and marketplace rankings across English, Spanish and French markets.");
out.push("");
out.push("## What this site is");
out.push("");
out.push("- A structured IoT catalogue plus editorial decision tools, not a shop and not a review farm.");
out.push("- Every record links to an official source. Marketplace ranks, prices and ASINs are prototype placeholders until a licensed Amazon data source is connected.");
out.push("- Editorial scores are opinionated, documented and not financial or investment advice.");
out.push("");
out.push("## Coverage");
out.push("");
const appCats = Object.keys(APPS.reduce(function (m, a) { if (a.category) m[a.category] = 1; return m; }, {})).sort();
out.push("- " + CATS.length + " IoT category hubs");
out.push("- " + BRANDS.length + " brands, including " + BRANDS.filter(function (b) { return ["cloud-infrastructure","cloud-iot-platform"].indexOf(b.type) === -1; }).length + " non-cloud brands");
out.push("- " + APPS.length + " mobile app records with Google Play and App Store links, across " + appCats.length + " app categories");
out.push("- App categories: " + appCats.join(", "));
out.push("- " + CLOUDS.length + " cloud, IoT and connectivity platforms");
out.push("- " + COMPS.length + " structured comparisons scored across decision factors");
out.push("- " + AMZ.products.length + " ranked marketplace products across " + AMZ.categories.length + " categories");
  out.push("- " + COMPAT.length + " compatibility guides, " + MODELS.length + " product model and manual records, " + ISSUES.length + " troubleshooting guides and " + CERTS.length + " certification references");
if (K) {
  out.push("- " + K.protocols.length + " protocols, " + K.standards.length + " standards, " + K.guides.length + " guides, " + (K.concepts || []).length + " concepts");
}
out.push("");
out.push("## Pre-rendered entity pages");
out.push("");
out.push("- Every brand, app, platform, protocol, comparison, category, model, compatibility guide, troubleshooting guide and certification has its own static page.");
out.push("- Brand: " + SITE_URL + "/brand/<slug>.html   App: " + SITE_URL + "/app/<slug>.html");
out.push("- Platform: " + SITE_URL + "/cloud/<slug>.html   Protocol: " + SITE_URL + "/protocol/<slug>.html");
out.push("- Comparison: " + SITE_URL + "/compare/<slug>.html   Category: " + SITE_URL + "/category/<slug>.html");
  out.push("- Compatibility: " + SITE_URL + "/compatibility/<slug>.html   Model: " + SITE_URL + "/model/<slug>.html");
  out.push("- Troubleshooting: " + SITE_URL + "/troubleshooting/<slug>.html   Certification: " + SITE_URL + "/certification/<slug>.html");
out.push("- Full index: " + SITE_URL + "/sitemap-entities.xml");
out.push("");
out.push("## Answer formats and citation");
out.push("");
out.push("- Compatibility, model, troubleshooting and certification pages each open with a Quick answer paragraph, a key-facts grid and a copy-ready citation line.");
out.push("- Citation format: IoT Atlas. \"<page title>\". https://hi-spark.net/<path>. Last verified <YYYY-MM-DD>.");
out.push("- Every record carries a last-verified date and links to the official source, so a statement can be traced back to the issuer before it is used in a compliance decision.");
out.push("- Certification records state what a scheme covers and what it does not cover, which keeps an answer scoped to the right market and product type.");
out.push("- Machine-readable data lives in /assets/*.js and the full static index is https://hi-spark.net/sitemap-entities.xml.");
out.push("");
out.push("## Key pages");
out.push("");
const KEY = [
  ["categories.html", "All IoT categories with live record counts"],
  ["apps.html", "IoT App Download Center"],
  ["cloud.html", "Cloud and IoT platform directory with world coverage map"],
  ["compare.html", "Structured comparison hub"],
  ["amazon-best-sellers.html", "Marketplace rankings with AI probability signals"],
  ["knowledge.html", "Knowledge base with a required-field completeness contract"],
  ["community.html", "Community Q&A and owner reviews"],
  ["compatibility.html", "Compatibility center"],
  ["models.html", "Product model and official manual center"],
  ["troubleshooting.html", "IoT setup and troubleshooting center"],
  ["certifications.html", "IoT certification and security reference"],
  ["ai-signals.html", "AI scoring methodology"]
];
for (const [u, d] of KEY) out.push("- [" + d + "](" + SITE_URL + "/" + u + ")");
out.push("");
out.push("## Protocols covered");
out.push("");
if (K) for (const p of K.protocols) out.push("- " + p.name + " (" + p.category + "): " + p.summary);
out.push("");
out.push("## Cloud platforms covered");
out.push("");
for (const c of CLOUDS) out.push("- " + c.name + " (" + c.provider + "): " + c.notes);
out.push("");
out.push("## Compatibility and reference centers");
out.push("");
out.push("- Compatibility center: " + SITE_URL + "/compatibility.html");
out.push("- Product models and official manuals: " + SITE_URL + "/models.html");
out.push("- Setup and troubleshooting: " + SITE_URL + "/troubleshooting.html");
out.push("- Certifications and security: " + SITE_URL + "/certifications.html");
for (const x of COMPAT.slice(0, 20)) out.push("- " + x.question + ": " + SITE_URL + "/compatibility/" + x.slug + ".html");
for (const x of MODELS.slice(0, 20)) out.push("- " + x.brand + " " + x.model + ": " + SITE_URL + "/model/" + x.slug + ".html");
out.push("");
out.push("## Common questions");
out.push("");
out.push("**What is IoT Atlas?** An independent IoT decision platform: a structured catalogue of devices, brands, protocols, companion apps and cloud platforms, with editorial comparisons and implementation guides.");
out.push("");
out.push("**Is the marketplace ranking data real?** No. Amazon ASINs, ranks, prices and ratings on this site are placeholder sample data for layout review. They must be replaced with a licensed data source before they can be relied on.");
out.push("");
out.push("**Are the brand scores a valuation?** No. The brand coverage index describes what a brand catalogue covers across ten dimensions. It is editorial opinion based on public information, it is not a rating or certification, and it is not a financial valuation or investment recommendation.");
out.push("");
out.push("**How are comparison scores produced?** Each comparison scores both options 0-100 on named decision factors. The weighted total is the average across factors. Readers can re-weight the factors on the brand index to get their own ordering.");
out.push("");
out.push("**What is verified in each app record?** The app name, its category and its store links. Many store links point to an official store search rather than a direct package listing; those are labelled store-search. An app is attributed to a parent company only when it is that vendor first-party app or the relationship is documented.");
out.push("");
out.push("**Can a brand request a correction?** Yes. Brands and manufacturers may request a correction, clarification or removal using the corrections policy. Supported requests are applied and the change is noted.");
out.push("");
out.push("**What is not medical advice?** Nothing here. Health and medical device listings are educational only and are not medical advice.");
out.push("");
out.push("## Content rules");
out.push("");
out.push("- Health and medical listings are not medical advice.");
out.push("- Legal pages require jurisdiction-specific review before production.");
out.push("- Community contributions are user-generated and carry their own disclaimers.");
out.push("- Corrections policy: see " + SITE_URL + "/corrections-policy.html");
out.push("");
out.push("## Open data (CC BY 4.0)");
out.push("");
out.push("- Dataset landing page: " + SITE_URL + "/dataset.html");
out.push("- Machine-readable dataset (JSON, 1,541 records, CC BY 4.0): " + SITE_URL + "/data/iot-atlas-open-dataset.json");
out.push("- Plain-text corpus for answer engines: " + SITE_URL + "/llms-full.txt");
out.push("- Recently verified records (Atom): " + SITE_URL + "/feed.xml");
out.push("- Citation: IoT Atlas. IoT Atlas open reference dataset. " + SITE_URL + "/data/iot-atlas-open-dataset.json");
out.push("");
out.push("## Contact");
out.push("");
out.push("- Corrections and takedown requests: " + SITE_URL + "/corrections-policy.html or info@hi-spark.com");
out.push("");

fs.writeFileSync(path.join(PROTO, "llms.txt"), out.join("\n"), "utf8");

/* ---------------- llms-full.txt (GEO corpus) ----------------
 * One plain-text file with every reference record we publish, so an answer engine
 * can ingest the dataset in a single request instead of crawling 1,543 pages.
 * Only facts that already exist on the records are written: no invented values. */
const line = (v) => String(v == null ? "" : v).replace(/\s+/g, " ").trim();
const items = (v) => (Array.isArray(v) ? v : []).map(line).filter(Boolean);
const full = [];
full.push("# IoT Atlas - full reference corpus");
full.push("");
full.push("> Generated " + today + " for AI answer engines and researchers. " + SITE_URL);
full.push("> Languages: English, Spanish, French. Every record links to an official source.");
full.push("> Publisher: IoT Atlas (" + SITE_URL + "). Corrections and data questions: info@hi-spark.com.");
full.push("> Cite as: IoT Atlas, \"<page title>\", " + SITE_URL + "/<path>, verified <YYYY-MM-DD>.");
full.push("");
full.push("## Certification and compliance records (" + CERTS.length + ")");
for (const x of CERTS) {
  full.push("");
  full.push("### " + line(x.name) + " (" + line(x.code) + ")");
  full.push("- Page: " + SITE_URL + "/certification/" + x.slug + ".html");
  full.push("- Group: " + line(x.group) + " | Region: " + line(x.region) + " | Status: " + line(x.status));
  full.push("- Issued or recognised by: " + line(x.issuer));
  full.push("- Summary: " + line(x.summary));
  full.push("- Meaning: " + line(x.meaning));
  full.push("- Applies to: " + items(x.appliesTo).join("; "));
  full.push("- Does not cover: " + items(x.doesNotCover).join("; "));
  full.push("- Verification checklist: " + items(x.checklist).join("; "));
  full.push("- Sources: " + items((x.sources || []).map((u) => (u.label || "") + " " + (u.url || ""))).join("; "));
  full.push("- Last verified: " + line(x.lastVerified));
}
full.push("");
full.push("## Compatibility guides (" + COMPAT.length + ")");
for (const x of COMPAT) {
  full.push("");
  full.push("### " + line(x.question || x.title));
  full.push("- Page: " + SITE_URL + "/compatibility/" + x.slug + ".html");
  full.push("- Verdict: " + line(x.verdict) + " | Category: " + line(x.category));
  full.push("- Summary: " + line(x.summary));
  full.push("- Requirements: " + items(x.requirements).join("; "));
  full.push("- Limitations: " + items(x.limitations).join("; "));
  full.push("- Steps: " + items(x.steps).join("; "));
  full.push("- Sources: " + items((x.sources || []).map((u) => (u.label || "") + " " + (u.url || ""))).join("; "));
  full.push("- Last verified: " + line(x.lastVerified));
}
full.push("");
full.push("## Device models and manuals (" + MODELS.length + ")");
for (const x of MODELS) {
  full.push("");
  full.push("### " + line(x.brand) + " " + line(x.model));
  full.push("- Page: " + SITE_URL + "/model/" + x.slug + ".html");
  full.push("- Category: " + line(x.category) + " | Status: " + line(x.status) + " | App: " + line(x.app));
  full.push("- Summary: " + line(x.summary));
  full.push("- Power: " + line(x.power) + " | Storage: " + items(x.storage).join(", ") + " | Protocols: " + items(x.protocols).join(", "));
  const specs = Object.keys(x.specs || {}).map((k2) => k2 + ": " + line(x.specs[k2]));
  if (specs.length) full.push("- Specifications: " + specs.join("; "));
  full.push("- Manual: " + line(x.manualUrl || x.supportUrl || ""));
  full.push("- Sources: " + items((x.sources || []).map((u) => (u.label || "") + " " + (u.url || ""))).join("; "));
  full.push("- Last verified: " + line(x.lastVerified));
}
full.push("");
full.push("## Troubleshooting guides (" + ISSUES.length + ")");
for (const x of ISSUES) {
  full.push("");
  full.push("### " + line(x.title));
  full.push("- Page: " + SITE_URL + "/troubleshooting/" + x.slug + ".html");
  full.push("- Category: " + line(x.category));
  full.push("- Symptom: " + line(x.symptom));
  full.push("- Likely causes: " + items(x.likelyCauses).join("; "));
  full.push("- Quick checks: " + items(x.quickChecks).join("; "));
  full.push("- Steps: " + items(x.steps).join("; "));
  full.push("- Escalate when: " + line(x.escalation));
  full.push("- Last verified: " + line(x.lastVerified));
}
full.push("");
full.push("## Cloud and IoT platforms (" + CLOUDS.length + ")");
for (const c of CLOUDS) {
  full.push("- " + line(c.name) + " (" + line(c.provider) + ") - " + line(c.type) + " | regions: " + line(c.regions) + " | protocols: " + items(c.protocols).join(", ") + " | " + SITE_URL + "/cloud/" + c.slug + ".html");
}
full.push("");
full.push("## Brands (" + BRANDS.length + ")");
for (const b of BRANDS) {
  full.push("- " + line(b.name) + " | " + line(b.type) + " | app: " + line(b.app) + " | HQ: " + line(b.hq) + " | protocols: " + items(b.protocols).join(", ") + " | " + SITE_URL + "/brand/" + b.slug + ".html");
}
full.push("");
full.push("## Apps (" + APPS.length + ")");
for (const a of APPS) {
  full.push("- " + line(a.name) + " | brand: " + line(a.brand) + " | category: " + line(a.category) + " | " + line(a.summary) + " | " + SITE_URL + "/app/" + a.slug + ".html");
}
full.push("");
full.push("## Comparison records (" + COMPS.length + ")");
for (const c of COMPS) {
  full.push("");
  full.push("### " + line(c.title));
  full.push("- Page: " + SITE_URL + "/compare/" + c.slug + ".html");
  full.push("- Compares: " + line(c.a) + " vs " + line(c.b) + " (" + line(c.type) + ")");
  full.push("- Summary: " + line(c.summary));
  full.push("- Verdict: " + line(c.verdict));
  const bf = c.bestFor || {};
  const bfKeys = Object.keys(bf).filter((k) => line(bf[k]));
  if (bfKeys.length) full.push("- Best for: " + bfKeys.map((k) => k + ": " + line(bf[k])).join("; "));
  if (typeof c.scoreA === "number") full.push("- Editorial scores: " + line(c.a) + " " + c.scoreA + ", " + line(c.b) + " " + c.scoreB + " (editorial estimates, not a rating or valuation)");
  full.push("- Decision factors: " + (Array.isArray(c.criteria) ? c.criteria.length : 0));
}
full.push("");
full.push("## IoT categories (" + CATS.length + ")");
for (const c of CATS) {
  const nm = (c.names && (c.names.en || c.names[Object.keys(c.names)[0]])) || c.slug;
  full.push("- " + line(nm) + " - " + line((c.descriptions || {}).en) + " | " + SITE_URL + "/category/" + c.slug + ".html");
}
full.push("");
full.push("## Standards (" + ((K && K.standards) || []).length + ")");
for (const x of (K && K.standards) || []) {
  full.push("- " + line(x.name) + " (" + line(x.region) + ") - " + line(x.summary) + " | applies to: " + items(x.applies_to).join(", "));
}
full.push("");
full.push("## Implementation guides (" + ((K && K.guides) || []).length + ")");
for (const x of (K && K.guides) || []) {
  full.push("- " + line(x.name) + " - " + line(x.summary) + " | audience: " + line(x.audience));
}
full.push("");
full.push("## Core concepts (" + ((K && K.concepts) || []).length + ")");
for (const x of (K && K.concepts) || []) {
  full.push("- " + line(x.name) + " - " + line(x.summary) + (x.why ? " Why it matters: " + line(x.why) : ""));
}
full.push("");
full.push("");
full.push("## Protocols and standards (" + ((K && K.protocols) || []).length + ")");
for (const x of (K && K.protocols) || []) {
  full.push("- " + line(x.name) + " - " + line(x.summary) + " | " + SITE_URL + "/protocol/" + x.slug + ".html");
}
full.push("");
fs.writeFileSync(path.join(PROTO, "llms-full.txt"), full.join("\n"), "utf8");

/* ---------------- Atom feed ----------------
 * Recently verified reference records, newest first. Dates come from the records
 * themselves, so the feed never claims a freshness the content does not have. */
const feedItems = []
  .concat(CERTS.map((x) => ({ d: x.lastVerified, t: x.name + " (" + x.code + ")", s: x.summary, u: SITE_URL + "/certification/" + x.slug + ".html", c: "Certification" })))
  .concat(COMPAT.map((x) => ({ d: x.lastVerified, t: x.question || x.title, s: x.summary, u: SITE_URL + "/compatibility/" + x.slug + ".html", c: "Compatibility" })))
  .concat(MODELS.map((x) => ({ d: x.lastVerified, t: x.brand + " " + x.model, s: x.summary, u: SITE_URL + "/model/" + x.slug + ".html", c: "Model" })))
  .concat(ISSUES.map((x) => ({ d: x.lastVerified, t: x.title, s: x.symptom, u: SITE_URL + "/troubleshooting/" + x.slug + ".html", c: "Troubleshooting" })))
  .filter((x) => x.d)
  .sort((a, b) => (a.d < b.d ? 1 : a.d > b.d ? -1 : a.t.localeCompare(b.t)))
  .slice(0, 80);
const esc = (v) => String(v == null ? "" : v).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
const feed = ['<?xml version="1.0" encoding="utf-8"?>', '<feed xmlns="http://www.w3.org/2005/Atom">',
  "  <title>IoT Atlas - recently verified records</title>",
  "  <subtitle>Certification, compatibility, model and troubleshooting references in English, Spanish and French.</subtitle>",
  '  <link href="' + SITE_URL + '/feed.xml" rel="self"/>',
  '  <link href="' + SITE_URL + '/"/>',
  "  <id>" + SITE_URL + "/feed.xml</id>",
  "  <updated>" + (feedItems[0] ? feedItems[0].d : today) + "T00:00:00Z</updated>",
  "  <author><name>IoT Atlas</name><uri>" + SITE_URL + "/methodology.html</uri></author>",
  "  <rights>Editorial summary of public information. Cite with attribution.</rights>"];
for (const it of feedItems) {
  feed.push("  <entry>");
  feed.push("    <title>" + esc(it.t) + "</title>");
  feed.push('    <link href="' + it.u + '"/>');
  feed.push("    <id>" + it.u + "</id>");
  feed.push("    <updated>" + it.d + "T00:00:00Z</updated>");
  feed.push("    <category term=\"" + esc(it.c) + "\"/>");
  feed.push("    <summary>" + esc(it.s) + "</summary>");
  feed.push("  </entry>");
}
feed.push("</feed>");
fs.writeFileSync(path.join(PROTO, "feed.xml"), feed.join("\n") + "\n", "utf8");
console.log("wrote sitemap.xml (" + entries.length + " urls), robots.txt, llms.txt, llms-full.txt, feed.xml");

