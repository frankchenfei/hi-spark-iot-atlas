/**
 * Share bar, share buttons and call-to-action markup.
 *
 * The build writes all of it into the static HTML so the links and labels exist
 * without JavaScript; assets/share-cta.js only adds behaviour (copy buttons, form
 * submit) and swaps the labels when the visitor changes language.
 *
 * Icons: inline SVG from a per-page sprite (simple-icons CC0 + Lucide ISC), so the
 * buttons cost one <use> each and the pages make no third-party requests.
 */
export const SHARE_EMAIL = "info@hi-spark.com";

export const SHARE_SPRITE = "<svg class=\"share-sprite\" aria-hidden=\"true\" focusable=\"false\" style=\"position:absolute;width:0;height:0;overflow:hidden\"><symbol id=\"share-i-x\" viewBox=\"0 0 24 24\"><path d=\"M18.901 1.153h3.68l-8.04 9.19L24 22.846h-7.406l-5.8-7.584-6.638 7.584H.474l8.6-9.83L0 1.154h7.594l5.243 6.932ZM17.61 20.644h2.039L6.486 3.24H4.298Z\" fill=\"currentColor\"/></symbol><symbol id=\"share-i-linkedin\" viewBox=\"0 0 24 24\"><path d=\"M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433c-1.144 0-2.063-.926-2.063-2.065 0-1.138.92-2.063 2.063-2.063 1.14 0 2.064.925 2.064 2.063 0 1.139-.925 2.065-2.064 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z\" fill=\"currentColor\"/></symbol><symbol id=\"share-i-facebook\" viewBox=\"0 0 24 24\"><path d=\"M9.101 23.691v-7.98H6.627v-3.667h2.474v-1.58c0-4.085 1.848-5.978 5.858-5.978.401 0 .955.042 1.468.103a8.68 8.68 0 0 1 1.141.195v3.325a8.623 8.623 0 0 0-.653-.036 26.805 26.805 0 0 0-.733-.009c-.707 0-1.259.096-1.675.309a1.686 1.686 0 0 0-.679.622c-.258.42-.374.995-.374 1.752v1.297h3.919l-.386 2.103-.287 1.564h-3.246v8.245C19.396 23.238 24 18.179 24 12.044c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.628 3.874 10.35 9.101 11.647Z\" fill=\"currentColor\"/></symbol><symbol id=\"share-i-whatsapp\" viewBox=\"0 0 24 24\"><path d=\"M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413Z\" fill=\"currentColor\"/></symbol><symbol id=\"share-i-reddit\" viewBox=\"0 0 24 24\"><path d=\"M12 0C5.373 0 0 5.373 0 12c0 3.314 1.343 6.314 3.515 8.485l-2.286 2.286C.775 23.225 1.097 24 1.738 24H12c6.627 0 12-5.373 12-12S18.627 0 12 0Zm4.388 3.199c1.104 0 1.999.895 1.999 1.999 0 1.105-.895 2-1.999 2-.946 0-1.739-.657-1.947-1.539v.002c-1.147.162-2.032 1.15-2.032 2.341v.007c1.776.067 3.4.567 4.686 1.363.473-.363 1.064-.58 1.707-.58 1.547 0 2.802 1.254 2.802 2.802 0 1.117-.655 2.081-1.601 2.531-.088 3.256-3.637 5.876-7.997 5.876-4.361 0-7.905-2.617-7.998-5.87-.954-.447-1.614-1.415-1.614-2.538 0-1.548 1.255-2.802 2.803-2.802.645 0 1.239.218 1.712.585 1.275-.79 2.881-1.291 4.64-1.365v-.01c0-1.663 1.263-3.034 2.88-3.207.188-.911.993-1.595 1.959-1.595Zm-8.085 8.376c-.784 0-1.459.78-1.506 1.797-.047 1.016.64 1.429 1.426 1.429.786 0 1.371-.369 1.418-1.385.047-1.017-.553-1.841-1.338-1.841Zm7.406 0c-.786 0-1.385.824-1.338 1.841.047 1.017.634 1.385 1.418 1.385.785 0 1.473-.413 1.426-1.429-.046-1.017-.721-1.797-1.506-1.797Zm-3.703 4.013c-.974 0-1.907.048-2.77.135-.147.015-.241.168-.183.305.483 1.154 1.622 1.964 2.953 1.964 1.33 0 2.47-.81 2.953-1.964.057-.137-.037-.29-.184-.305-.863-.087-1.795-.135-2.769-.135Z\" fill=\"currentColor\"/></symbol><symbol id=\"share-i-email\" viewBox=\"0 0 24 24\"><path d=\"m22 7-8.991 5.727a2 2 0 0 1-2.009 0L2 7\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.9\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/></symbol><symbol id=\"share-i-link\" viewBox=\"0 0 24 24\"><path d=\"M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71 M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.9\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/></symbol><symbol id=\"share-i-quote\" viewBox=\"0 0 24 24\"><path d=\"M16 3a2 2 0 0 0-2 2v6a2 2 0 0 0 2 2 1 1 0 0 1 1 1v1a2 2 0 0 1-2 2 1 1 0 0 0-1 1v2a1 1 0 0 0 1 1 6 6 0 0 0 6-6V5a2 2 0 0 0-2-2z M5 3a2 2 0 0 0-2 2v6a2 2 0 0 0 2 2 1 1 0 0 1 1 1v1a2 2 0 0 1-2 2 1 1 0 0 0-1 1v2a1 1 0 0 0 1 1 6 6 0 0 0 6-6V5a2 2 0 0 0-2-2z\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.9\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/></symbol></svg>";

const esc = (v) => String(v == null ? "" : v)
  .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
  .replace(/"/g, "&quot;").replace(/'/g, "&#39;");
const use = (n, cls) => '<svg class="' + (cls || "share-icon-svg") + '" aria-hidden="true" focusable="false"><use href="#share-i-' + n + '"></use></svg>';

export function shareTargets(title, url) {
  const enc = encodeURIComponent;
  return [
    ["x", "X", "https://twitter.com/intent/tweet?text=" + enc(title) + "&url=" + enc(url)],
    ["linkedin", "LinkedIn", "https://www.linkedin.com/sharing/share-offsite/?url=" + enc(url)],
    ["facebook", "Facebook", "https://www.facebook.com/sharer/sharer.php?u=" + enc(url)],
    ["whatsapp", "WhatsApp", "https://api.whatsapp.com/send?text=" + enc(title + " " + url)],
    ["reddit", "Reddit", "https://www.reddit.com/submit?url=" + enc(url) + "&title=" + enc(title)],
    ["email", "Email", "mailto:?subject=" + enc(title) + "&body=" + enc(url)]
  ];
}

function iconButton(net, label, href) {
  return '<a class="share-icon share-icon-' + net + '" data-share="' + net + '" data-s-title="net_' + net + '"' +
    ' href="' + href + '" target="_blank" rel="noopener nofollow" title="' + esc(label) + '" aria-label="' + esc(label) + '">' +
    use(net) + "</a>";
}

export function shareBarMarkup(o) {
  const url = o.url, title = String(o.title || "").replace(/\s+/g, " ").trim();
  return '<section class="share-bar" id="share-bar" data-rendered="1" aria-label="Share">' +
    '<div class="container"><div class="share-bar-inner">' +
      '<span class="share-bar-label" data-s="share">Share</span>' +
      '<span class="share-bar-icons">' + shareTargets(title, url).map((s) => iconButton(s[0], "Share on " + s[1], s[2])).join("") + "</span>" +
      '<span class="share-bar-tools">' +
        '<button type="button" class="share-tool" data-share="copy" data-s-title="copy">' + use("link") + '<span data-s="copy">Copy link</span></button>' +
        '<button type="button" class="share-tool" data-share="cite" data-s-title="copy_cite">' + use("quote") + '<span data-s="copy_cite">Copy citation</span></button>' +
      "</span>" +
      '<code class="share-url" hidden>' + esc(url) + "</code>" +
      '<script type="application/json" data-citation>' + JSON.stringify({ citation: 'IoT Atlas. "' + title + '". ' + url + "." }) + "<\/script>" +
    "</div></div></section>";
}

export function shareCtaMarkup(o) {
  const url = o.url, title = String(o.title || "").replace(/\s+/g, " ").trim();
  const base = o.base || "";
  const enc = encodeURIComponent;
  const mailto = "mailto:" + SHARE_EMAIL + "?subject=" + enc("Correction: " + title) +
    "&body=" + enc(url + "\n\nWhat looks wrong:\n\nCorrect information and an official source:\n");
  return '<section class="section compact" id="share-cta" data-rendered="1">' +
    '<div class="container"><div class="cta-band">' +
      '<div class="cta-band-copy">' +
        '<h2 class="share-heading" data-s="cta_title">Get the monthly IoT brief</h2>' +
        '<p class="share-note" data-s="cta_note">Certification changes, compatibility notes and platform updates. One short email, unsubscribe anytime.</p>' +
        '<form class="cta-form" action="mailto:' + SHARE_EMAIL + '" method="post" enctype="text/plain" novalidate>' +
          '<label class="sr-only" for="cta-email">Email address</label>' +
          '<input id="cta-email" type="email" name="email" required autocomplete="email" placeholder="you@company.com" data-s-ph="cta_email">' +
          '<button class="btn primary" type="submit" data-s="cta_button">Subscribe</button>' +
        "</form>" +
        '<p class="cta-status" role="status"></p>' +
      "</div>" +
      '<ul class="cta-links">' +
        "<li><a href=\"" + esc(base + "data/iot-atlas-open-dataset.json") + "\" download><span data-s=\"dataset\">Download the open dataset (CC BY 4.0)</span></a> <small data-s=\"dataset_note\">1,452 structured records as JSON</small></li>" +
        "<li><a href=\"" + esc(mailto) + "\"><span data-s=\"correction\">Suggest a correction</span></a> <small data-s=\"correction_note\">Email " + SHARE_EMAIL + " - we publish fixes and credit them</small></li>" +
        "<li><a href=\"" + esc(base + "feed.xml") + "\"><span data-s=\"feed\">Follow the Atom feed</span></a> <small data-s=\"feed_note\">Recently verified records</small></li>" +
      "</ul>" +
    "</div></div></section>";
}

/** Replaces the #share-bar and #share-cta slots, inserting the sprite once. */
export function injectShare(html, o) {
  // Idempotent: drop any sprite a previous build left behind before inserting a new one.
  html = html.replace(/<svg class="share-sprite"[\s\S]*?<\/svg>/g, "");
  const hasBar = /id="share-bar"/.test(html);
  const hasCta = /id="share-cta"/.test(html);
  if (!hasBar && !hasCta) return html;
  if (hasBar) {
    html = html.replace(/<section[^>]*id="share-bar"[^>]*>[\s\S]*?<\/section>/, SHARE_SPRITE + shareBarMarkup(o));
  }
  if (hasCta) {
    const block = (hasBar ? "" : SHARE_SPRITE) + shareCtaMarkup(o);
    html = html.replace(/<section[^>]*id="share-cta"[^>]*>[\s\S]*?<\/section>/, block);
  }
  return html;
}
