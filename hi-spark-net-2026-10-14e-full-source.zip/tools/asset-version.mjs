/* Single source of truth for browser cache-busting asset versions. */
export const ASSET_VERSION = "20261014q";
export const VERSIONED = "?v=" + ASSET_VERSION;

















