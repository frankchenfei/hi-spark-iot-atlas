#!/usr/bin/env node
/**
 * Publishes the reference dataset as open data (CC BY 4.0) under /data/.
 *
 *   node tools/build_open_dataset.mjs
 *
 * A citable dataset is the most reliable link magnet this site can offer:
 * researchers, tool directories and AI pipelines link to data, not to landing
 * pages. Only facts already published on the site are exported, and the export
 * excludes third-party logos and trademarks.
 */
import fs from "node:fs";
import path from "node:path";
import vm from "node:vm";
import { fileURLToPath } from "node:url";
import { APP_FILES } from "./app-batches.mjs";

const PROTO = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const ASSETS = path.join(PROTO, "assets");
const SITE = process.env.SITE_URL || "https://hi-spark.net";
const TODAY = new Date().toISOString().slice(0, 10);
/* Optional DOI. Fill tools/zenodo-doi.json after Zenodo issues one and the DOI is
   published in the dataset identifier, the README and the citation string. */
let DOI = "";
try { DOI = (JSON.parse(fs.readFileSync(path.join(PROTO, "tools", "zenodo-doi.json"), "utf8")).doi || "").trim(); } catch (e) {}

const CATALOG = ["brands.js","brand-site-verified.js","brand-scores.js","category-hub.js","clouds.js","knowledge.js","knowledge-extra.js","knowledge-extra2.js","logo-map.js","product-directory.js","compare-data.js","compatibility-data.js","model-data.js","troubleshooting-data.js","certification-data.js"];
const ctx = { window: {} };
vm.createContext(ctx);
for (const f of [...CATALOG, ...APP_FILES]) {
  const p = path.join(ASSETS, f);
  if (fs.existsSync(p)) vm.runInContext(fs.readFileSync(p, "utf8"), ctx, { filename: f });
}
const w = ctx.window;
const arr = (v) => (Array.isArray(v) ? v : []);
const K = w.IOT_KNOWLEDGE || {};

const dataset = {
  "@context": "https://schema.org",
  "@type": "Dataset",
  name: "IoT Atlas open reference dataset",
  description: "Certification requirements, ecosystem compatibility, device models, troubleshooting guides, cloud platforms, brands and mobile apps for connected products.",
  url: SITE + "/data/iot-atlas-open-dataset.json",
  license: "https://creativecommons.org/licenses/by/4.0/",
  creator: { "@type": "Organization", name: "IoT Atlas", url: SITE + "/" },
  isAccessibleForFree: true,
  dateModified: TODAY,
  inLanguage: ["en", "es", "fr"],
  contactPoint: { "@type": "ContactPoint", email: "info@hi-spark.com", contactType: "editorial" },
  citation: "IoT Atlas. IoT Atlas open reference dataset. " + SITE + "/data/iot-atlas-open-dataset.json" + (DOI ? " (DOI " + DOI + ")" : "") + ", retrieved " + TODAY + ".",
  ...(DOI ? { identifier: "https://doi.org/" + DOI, sameAs: "https://doi.org/" + DOI } : {}),
  counts: {},
  certifications: arr(w.IOT_CERTIFICATIONS),
  compatibility: arr(w.IOT_COMPATIBILITY),
  models: arr(w.IOT_MODELS),
  troubleshooting: arr(w.IOT_TROUBLESHOOTING),
  clouds: arr(w.IOT_CLOUDS).map((c) => ({ slug: c.slug, name: c.name, provider: c.provider, type: c.type, protocols: c.protocols, regions: c.regions, notes: c.notes, url: SITE + "/cloud/" + c.slug + ".html" })),
  brands: arr(w.IOT_BRANDS).map((b) => ({ slug: b.slug, name: b.name, type: b.type, app: b.app, hq: b.hq, protocols: b.protocols, categories: b.categories, url: SITE + "/brand/" + b.slug + ".html" })),
  apps: arr(w.IOT_APP_DIRECTORY).map((a) => ({ slug: a.slug, name: a.name, brand: a.brand, category: a.category, summary: a.summary, android_url: a.android_url, ios_url: a.ios_url, url: SITE + "/app/" + a.slug + ".html" })),
  protocols: arr(K.protocols).map((p) => ({ slug: p.slug, name: p.name, summary: p.summary, url: SITE + "/protocol/" + p.slug + ".html" }))
};
dataset.counts = {
  certifications: dataset.certifications.length,
  compatibility: dataset.compatibility.length,
  models: dataset.models.length,
  troubleshooting: dataset.troubleshooting.length,
  clouds: dataset.clouds.length,
  brands: dataset.brands.length,
  apps: dataset.apps.length,
  protocols: dataset.protocols.length
};
dataset.translations = { note: "ES and FR text for the reference records is published in content-i18n-core.js and applied per page.", store: SITE + "/assets/content-i18n-core.js" };

fs.mkdirSync(path.join(PROTO, "data"), { recursive: true });
fs.writeFileSync(path.join(PROTO, "data", "iot-atlas-open-dataset.json"), JSON.stringify(dataset, null, 2) + "\n", "utf8");

const quote = String.fromCharCode(34);
const readme = [
  "# IoT Atlas open reference dataset",
  "",
  "Machine-readable export of the reference records published on " + SITE + ". Generated " + TODAY + ".",
  "",
  "## Licence",
  "",
  "Creative Commons Attribution 4.0 International (CC BY 4.0): https://creativecommons.org/licenses/by/4.0/",
  "",
  "You may copy, redistribute, adapt and use the data commercially, including for AI training and retrieval, provided you attribute IoT Atlas.",
  "",
  "## Contact",
  "",
  "IoT Atlas. Corrections and data questions: info@hi-spark.com",
  "",
  "## Citation",
  "",
  "> IoT Atlas. IoT Atlas open reference dataset. " + SITE + "/data/iot-atlas-open-dataset.json, retrieved " + TODAY + ".",
  "",
  "Per-page citation: " + quote + "IoT Atlas. <page title>. " + SITE + "/<path>. Last verified <YYYY-MM-DD>." + quote,
  "",
  "## Files",
  "",
  "- `iot-atlas-open-dataset.json` - all records in one file (JSON-LD, @type Dataset)",
  "- Full plain-text corpus for answer engines: " + SITE + "/llms-full.txt",
  "- URL inventory: " + SITE + "/sitemap-entities.xml",
  "",
  "## Coverage",
  "",
  "| Collection | Records |",
  "|---|---|",
  ...Object.entries(dataset.counts).map(([k, v]) => "| " + k + " | " + v + " |"),
  "",
  "## What is not included",
  "",
  "- Brand and platform logos (third-party trademarks, used on the site under their owners terms).",
  "- Marketplace ranks, prices and ratings: sample data on the site until a licensed source is connected.",
  "- Personal data, analytics and community contributions.",
  "",
  "## Accuracy",
  "",
  "Every record carries a lastVerified date and links to an official source. Requirements change: confirm the current version with the issuing body or a test laboratory before making a compliance decision.",
  ""
].join("\n");
fs.writeFileSync(path.join(PROTO, "data", "README.md"), readme, "utf8");

console.log("open dataset written: " + JSON.stringify(dataset.counts));
