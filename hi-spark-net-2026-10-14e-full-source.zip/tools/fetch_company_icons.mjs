import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const here=path.dirname(fileURLToPath(import.meta.url));
const root=path.resolve(here,'..');
const logoDir=path.join(root,'assets','logos');
await fs.mkdir(logoDir,{recursive:true});

function readArray(file,varName){
  const text=fsSync.readFileSync(file,'utf8');
  return JSON.parse(text.slice(text.indexOf('['),text.lastIndexOf(';'))).map(x=>x);
}
import fsSync from 'node:fs';
const brands=readArray(path.join(root,'assets','brands.js')).filter(x=>!['cloud-infrastructure','cloud-iot-platform'].includes(x.type));
const clouds=readArray(path.join(root,'assets','clouds.js'));
const simple=await fetch('https://cdn.jsdelivr.net/npm/simple-icons@latest/_data/simple-icons.json').then(r=>r.json());
const norm=s=>String(s).toLowerCase().replace(/&/g,'and').replace(/\+/g,'plus').replace(/[^a-z0-9]+/g,'');
const entries=[];
for(const item of simple){
  entries.push({title:item.title,slug:norm(item.title),hex:item.hex});
  for(const alias of item.aliases?.aka||[]) entries.push({title:String(alias),slug:norm(item.title),hex:item.hex});
}
const exact=new Map(); for(const e of entries){if(!exact.has(norm(e.title))) exact.set(norm(e.title),e);}
function findIcon(name){
  const n=norm(name); if(!n) return null;
  if(exact.has(n)) return exact.get(n);
  const candidates=entries.filter(e=>norm(e.title).startsWith(n)||n.startsWith(norm(e.title)));
  return candidates.sort((a,b)=>norm(a.title).length-norm(b.title).length)[0]||null;
}
const cloudSlugs={
 'AWS':'amazonwebservices','Microsoft Azure':'microsoftazure','Oracle Cloud':'oracle','Google Cloud':'googlecloud',
 'IBM Cloud':'ibm','Alibaba Cloud':'alibabacloud','Huawei Cloud':'huawei','Arduino Cloud':'arduino','HiveMQ':'hivemq',
 'Cloudflare':'cloudflare','Scaleway':'scaleway','DigitalOcean':'digitalocean','Vultr':'vultr','Akamai / Linode':'linode',
 'OVHcloud':'ovh','Hetzner':'hetzner','Siemens Insights Hub':'siemens','SAP':'sap'
};
function initials(name){
  const words=String(name).replace(/[^a-zA-Z0-9 ]/g,' ').split(/\s+/).filter(Boolean);
  if(!words.length) return 'IO';
  if(words.length===1) return words[0].slice(0,2).toUpperCase();
  return (words[0][0]+words[1][0]).toUpperCase();
}
function monogram(name,fileSlug){
  const label=initials(name);
  const svg='<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64"><rect width="64" height="64" rx="16" fill="#E7F4F3"/><text x="32" y="38" text-anchor="middle" font-family="Arial,Helvetica,sans-serif" font-size="22" font-weight="700" fill="#0B6F70">'+label+'</text></svg>';
  return fs.writeFile(path.join(logoDir,fileSlug+'.svg'),svg);
}
async function fetchSvg(slug,hex,fileSlug){
  const r=await fetch('https://cdn.jsdelivr.net/npm/simple-icons@latest/icons/'+slug+'.svg');
  if(!r.ok) return false;
  let svg=await r.text();
  svg=svg.replace('<svg ', '<svg fill="#'+(hex||'111111')+'" ');
  await fs.writeFile(path.join(logoDir,fileSlug+'.svg'),svg);
  return true;
}
const map={brands:{},clouds:{},attribution:{source:'Simple Icons',url:'https://simpleicons.org/',license:'CC0-1.0'}};
for(const b of brands){
  const match=findIcon(b.name);
  const fileSlug=b.slug;
  let ok=false;
  if(match) ok=await fetchSvg(match.slug,match.hex,fileSlug);
  if(!ok) await monogram(b.name,fileSlug);
  map.brands[b.slug]={file:fileSlug+'.svg',source:ok?'simple-icons':'generated-monogram'};
}
for(const c of clouds){
  let slug=cloudSlugs[c.provider]||null,hex='111111';
  if(!slug){
    const match=findIcon(c.name)||findIcon(c.provider);
    if(match){slug=match.slug;hex=match.hex;}
  }
  const fileSlug=c.slug;
  let ok=false;
  if(slug) ok=await fetchSvg(slug,hex,fileSlug);
  if(!ok) await monogram(c.name||c.provider,fileSlug);
  map.clouds[c.slug]={file:fileSlug+'.svg',source:ok?'simple-icons':'generated-monogram'};
}
await fs.writeFile(path.join(root,'assets','logo-map.js'),'window.IOT_LOGO_MAP = '+JSON.stringify(map,null,2)+';\n');
const report=['# Company Icon Sources','','Icons marked as Simple Icons are downloaded from the Simple Icons project and are provided under CC0-1.0.','Icons marked as generated-monogram are original placeholder SVGs generated for this prototype.','','Simple Icons: https://simpleicons.org/','License: https://github.com/simple-icons/simple-icons/blob/develop/LICENSE.md','','Trademarks and brand rights remain with their respective owners. This prototype does not imply endorsement or partnership.'].join('\n');
await fs.writeFile(path.join(logoDir,'NOTICE.md'),report);
console.log('brand icons',Object.keys(map.brands).length,'cloud icons',Object.keys(map.clouds).length);
