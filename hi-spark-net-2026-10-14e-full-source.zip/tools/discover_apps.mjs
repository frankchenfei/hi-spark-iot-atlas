#!/usr/bin/env node
/**
 * Discovers real companion apps on the Apple App Store for a curated list of
 * IoT brands, so new directory rows are grounded in a live store record rather
 * than hand-written guesses.
 *
 *   node tools/discover_apps.mjs            # query every seed
 *   node tools/discover_apps.mjs --only Dash
 *
 * Writes content-templates/app-discovery.csv for editorial review. Nothing is
 * published until a human accepts the match and it is moved into a batch file.
 */
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const PROTO = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const OUT = path.join(PROTO, "content-templates", "app-discovery.csv");

// category | segment | protocols | brand | App Store query term
const S = (cat, seg, proto, brand, q) => ({ cat, seg, proto, brand, q });
const SEEDS = [
  // ---- Dash Cams ----
  S("Dash Cams","Dash cam","Wi-Fi, BLE","Viidure","Viidure"),
  S("Dash Cams","Dash cam","Wi-Fi, BLE","DDPAI","DDPAI"),
  S("Dash Cams","Dash cam","Wi-Fi, BLE","70mai","70mai"),
  S("Dash Cams","Dash cam","Wi-Fi, BLE","Vantrue","Vantrue"),
  S("Dash Cams","Dash cam","Wi-Fi, BLE","WOLFBOX","WOLFBOX"),
  S("Dash Cams","Dash cam","Wi-Fi, BLE","Cobra","Cobra Dash Cam"),
  S("Dash Cams","Dash cam","Wi-Fi, BLE","PAPAGO","PAPAGO"),
  S("Dash Cams","Dash cam","Wi-Fi, BLE","iRoad","iRoad"),
  S("Dash Cams","Dash cam","Wi-Fi","FineVu","FineVu"),
  S("Dash Cams","Dash cam","Wi-Fi","Lukas","Lukas Dashcam"),
  S("Dash Cams","Dash cam","Wi-Fi","Street Guardian","Street Guardian"),
  S("Dash Cams","Dash cam","Wi-Fi","Blueskysea","Blueskysea"),
  S("Dash Cams","Dash cam","Wi-Fi","Kdlinks","Kdlinks"),
  S("Dash Cams","Dash cam","Wi-Fi","Transcend","Transcend DrivePro"),
  S("Dash Cams","Dash cam","Wi-Fi","ROAV","ROAV DashCam"),
  S("Dash Cams","Dash cam","Wi-Fi","AZDOME","AZDOME"),
  S("Dash Cams","Dash cam","Wi-Fi","REDTIGER","REDTIGER"),
  S("Dash Cams","Dash cam","Wi-Fi","Kingslim","Kingslim"),
  S("Dash Cams","Dash cam","Wi-Fi, BLE","Garmin","Garmin Dash Cam"),
  S("Dash Cams","Dash cam","Wi-Fi","Vueroid","Vueroid"),
  S("Dash Cams","Dash cam","Wi-Fi","Apeman","Apeman"),
  S("Dash Cams","Dash cam","Wi-Fi","Crosstour","Crosstour"),
  S("Dash Cams","Dash cam","Wi-Fi","Z-Edge","Z-Edge"),
  S("Dash Cams","Dash cam","Wi-Fi","Rove","Rove Dash Cam"),
  S("Dash Cams","Dash cam","Wi-Fi","WheelWitness","WheelWitness"),
  // ---- Health & Home ----
  S("Health & Home","Air purifier","Wi-Fi, BLE","Dyson","Dyson Link"),
  S("Health & Home","Appliance","Wi-Fi","Bosch / Siemens","Home Connect"),
  S("Health & Home","Appliance","Wi-Fi","GE Appliances","SmartHQ"),
  S("Health & Home","Appliance","Wi-Fi","Whirlpool","Whirlpool"),
  S("Health & Home","Appliance","Wi-Fi","Electrolux","Electrolux Wellbeing"),
  S("Health & Home","Appliance","Wi-Fi","Candy","Candy simply-Fi"),
  S("Health & Home","Appliance","Wi-Fi","Haier","hOn"),
  S("Health & Home","Air purifier","Wi-Fi","Dreo","Dreo"),
  // ---- Infrared & Remotes ----
  S("Infrared & Remotes","IR blaster","BLE, Wi-Fi","Flipper Devices","Flipper Zero"),
  S("Infrared & Remotes","AC control","Wi-Fi, IR","Panasonic","Panasonic Comfort Cloud"),
  S("Infrared & Remotes","AC control","Wi-Fi, IR","Midea","Midea Air"),
  S("Infrared & Remotes","AC control","Wi-Fi, IR","Gree","Gree+"),
  S("Infrared & Remotes","AC control","Wi-Fi, IR","LG","LG ThinQ"),
  S("Infrared & Remotes","Fan control","Wi-Fi, BLE","Dreo","Dreo"),
  S("Infrared & Remotes","Universal remote","BLE, IR","SwitchBot","SwitchBot"),
  S("Infrared & Remotes","Universal remote","BLE","Sevenhugs","Sevenhugs"),
  // ---- Projectors ----
  S("Projectors","Smart projector","Wi-Fi, BLE","NexiGo","NexiGo"),
  S("Projectors","Smart projector","Wi-Fi","Wanbo","Wanbo"),
  S("Projectors","Smart projector","Wi-Fi","Aurzen","Aurzen"),
  S("Projectors","Smart projector","Wi-Fi","Magcubic","Magcubic"),
  S("Projectors","Smart projector","Wi-Fi","Dangbei","Dangbei"),
  S("Projectors","Smart projector","Wi-Fi","JMGO","JMGO"),
  S("Projectors","Smart projector","Wi-Fi","Yaber","Yaber"),
  // ---- Label Printers ----
  S("Label Printers","Label printer","BLE, Wi-Fi","Bixolon","Bixolon"),
  S("Label Printers","Label printer","BLE","Postek","Postek"),
  S("Label Printers","Label printer","BLE, Wi-Fi","Citizen","Citizen Print"),
  S("Label Printers","Label printer","BLE, Wi-Fi","Brother","Brother iPrint&Label"),
  S("Label Printers","Label printer","BLE","Rongta","Rongta"),
  S("Label Printers","Label printer","BLE","Vretti","Vretti"),
  S("Label Printers","Label printer","BLE","Zink","Zink"),
  // ---- Health & Home end ----
  S("Air & Water","Air quality","Wi-Fi, BLE","Sharp","Sharp Air"),
  S("Air & Water","Air quality","Wi-Fi","Dreo","Dreo"),
  S("Air & Water","Air quality","Wi-Fi","Venta","Venta"),
  S("Air & Water","Water leak","Wi-Fi, BLE","Eve","Eve Water Guard"),
  S("Air & Water","Air quality","Wi-Fi, BLE","Bosch","Bosch Air"),
  // ---- AI Toys & Education ----
  S("AI Toys & Education","Audio toy","BLE, Wi-Fi","tonies","tonies"),
  S("AI Toys & Education","Audio toy","BLE, Wi-Fi","Yoto","Yoto"),
  S("AI Toys & Education","Coding robot","BLE, Wi-Fi","Kano","Kano"),
  S("AI Toys & Education","Coding kit","BLE","littleBits","littleBits"),
  S("AI Toys & Education","Coding robot","BLE","Microduino","Microduino"),
  S("AI Toys & Education","STEM robot","BLE","Matatalab","Matatalab"),
  // ---- Energy & Solar ----
  S("Energy & Solar","Solar inverter","Wi-Fi","Hoymiles","S-Miles"),
  S("Energy & Solar","Inverter","Wi-Fi","Sunsynk","Sunsynk"),
  S("Energy & Solar","Home battery","Wi-Fi, BLE","GivEnergy","GivEnergy"),
  S("Energy & Solar","Home battery","Wi-Fi, BLE","FranklinWH","FranklinWH"),
  S("Energy & Solar","Solar monitoring","Wi-Fi","SunPower","SunPower"),
  S("Energy & Solar","Solar inverter","Wi-Fi","Sungrow","iSolarCloud"),
  // ---- Tracking ----
  S("Tracking","OBD tracker","BLE, 4G","Bouncie","Bouncie"),
  S("Tracking","OBD tracker","BLE, 4G","Zubie","Zubie"),
  S("Tracking","GPS tracker","4G, BLE","Tracki","Tracki"),
  S("Tracking","GPS tracker","4G","LandAirSea","LandAirSea"),
  S("Tracking","Vehicle tracker","4G","Samsara","Samsara Driver"),
  S("Tracking","Vehicle tracker","4G","Geotab","myGeotab"),
  // ---- Pet Tech ----
  S("Pet Tech","Pet activity","BLE","Whisker / Purina","Petivity"),
  S("Pet Tech","Pet feeder","Wi-Fi","Catit","Catit"),
  S("Pet Tech","Pet tracker","BLE, 4G","Pawfit","Pawfit"),
  S("Pet Tech","Pet tracker","BLE, 4G","Invoxia","Invoxia"),
  S("Pet Tech","Pet camera","Wi-Fi","Furbo","Furbo"),
  S("Pet Tech","Litter box","Wi-Fi","Whisker","Whisker"),
  // ---- Smart Garden ----
  S("Smart Garden","Robotic mower","BLE, Wi-Fi","Husqvarna","Automower Connect"),
  S("Smart Garden","Robotic mower","4G, BLE","Segway","Navimow"),
  S("Smart Garden","Robotic mower","Wi-Fi, BLE","ECOVACS","Goat G1"),
  S("Smart Garden","Yard robot","Wi-Fi, 4G","Yarbo","Yarbo"),
  S("Smart Garden","Robotic mower","BLE, Wi-Fi","Sunseeker","Sunseeker"),
  S("Smart Garden","Robotic mower","Wi-Fi","Positec","Worx Landroid"),
  // ---- Trail Cameras ----
  S("Trail Cameras","Trail cam","4G, Wi-Fi","Vosker","Vosker"),
  S("Trail Cameras","Trail cam","4G","Covert","Covert Scouting Cameras"),
  S("Trail Cameras","Trail cam","4G","Cuddeback","Cuddeback"),
  S("Trail Cameras","Trail cam","BLE, Wi-Fi","Exodus","Exodus Trail Cameras"),
  S("Trail Cameras","Trail cam","BLE, Wi-Fi","Reolink","Reolink"),
  // ---- TV & Streaming ----
  S("TV & Streaming","TV remote","Wi-Fi, BLE","Sony","Video & TV SideView"),
  S("TV & Streaming","TV remote","Wi-Fi","Panasonic","Panasonic TV Remote 2"),
  S("TV & Streaming","TV remote","Wi-Fi, BLE","NVIDIA","NVIDIA SHIELD TV"),
  S("TV & Streaming","TV remote","Wi-Fi","Philips","Philips TV Remote"),
  S("TV & Streaming","TV remote","Wi-Fi","Samsung","SmartThings"),
  // ---- Drones ----
  S("Drones","Camera drone","Wi-Fi, BLE","HOVERAir","HOVERAir"),
  S("Drones","Camera drone","Wi-Fi","Parrot","FreeFlight"),
  S("Drones","Camera drone","Wi-Fi","Yuneec","Yuneec Pilot"),
  S("Drones","Survey drone","4G, Wi-Fi","DroneDeploy","DroneDeploy"),
  S("Drones","Camera drone","Wi-Fi, BLE","Ruko","Ruko"),
  // ---- Audio ----
  S("Audio & Headphones","Speaker","Wi-Fi, BLE","Bowers & Wilkins","Bowers & Wilkins Music"),
  S("Audio & Headphones","AV receiver","Wi-Fi","Denon / Marantz","HEOS"),
  S("Audio & Headphones","Hi-Fi streamer","Wi-Fi","Naim","Naim"),
  S("Audio & Headphones","Hi-Fi streamer","Wi-Fi","Linn","Linn"),
  S("Audio & Headphones","Earbuds","BLE","1MORE","1MORE Music"),
  S("Audio & Headphones","Earbuds","BLE","Baseus","Baseus"),
  // ---- Health ----
  S("Health","Smart scale","BLE","Tanita","Health Planet"),
  S("Health","Smart scale","BLE, Wi-Fi","Eufy","Eufy Life"),
  S("Health","CGM","BLE","Dexcom","Stelo"),
  S("Health","Wearable sensor","BLE","Cosinuss","Cosinuss"),
  S("Health","Blood pressure","BLE","Omron","OMRON connect"),
  S("Health","Pulse oximeter","BLE","Wellue","Wellue Health"),
  // ---- Wearables ----
  S("Wearables","Smart watch","BLE","Nothing","CMF Watch"),
  S("Wearables","Smart watch","BLE","Amazfit","Notify for Amazfit"),
  S("Wearables","Watch faces","BLE","Amoled Watch Faces","Amoled Watch Faces"),
  S("Wearables","Watch faces","BLE","TimeShow","TimeShow"),
  S("Wearables","Smart ring","BLE","Oura","Oura"),
  S("Wearables","Smart watch","BLE","Polar","Polar Flow"),
  // ---- Security ----
  S("Security","NVR software","Wi-Fi, Ethernet","Ubiquiti","UniFi Protect"),
  S("Security","NVR software","Wi-Fi, Ethernet","Frigate","Frigate"),
  S("Security","Camera","Wi-Fi, BLE","Amcrest","Amcrest View Pro"),
  S("Security","Camera","Wi-Fi","ZOSI","Zosi Smart"),
  S("Security","Camera","Wi-Fi","HiLook","HiLook"),
  S("Security","Alarm system","Wi-Fi, 4G","Cove","Cove Security"),
  S("Security","Alarm system","Wi-Fi, 4G","Kangaroo","Kangaroo Security"),
  S("Security","Video monitoring","Wi-Fi","Deep Sentinel","Deep Sentinel"),
  S("Security","Access control","Wi-Fi, 4G","Brivo","Brivo Mobile Pass"),
  S("Security","Camera","Wi-Fi","Verkada","Verkada"),
  // ---- Smart Locks ----
  S("Smart Locks","Smart lock","BLE, Wi-Fi","Ultraloq","Ultraloq"),
  S("Smart Locks","Smart lock","BLE, Wi-Fi","RemoteLock","RemoteLock"),
  S("Smart Locks","Smart lock","BLE","Haven","Haven Lock"),
  S("Smart Locks","Smart lock","BLE, Wi-Fi","Kwikset","Kwikset"),
  // ---- Access Control ----
  S("Access Control","Intercom","Wi-Fi, PoE","Genetec","Genetec"),
  S("Access Control","Intercom","Wi-Fi, PoE","Avigilon","Avigilon Alta"),
  S("Access Control","Intercom","Wi-Fi, PoE","Aiphone","Aiphone"),
  S("Access Control","Intercom","Wi-Fi, PoE","Fanvil","Fanvil"),
  // ---- Robot Vacuums ----
  S("Robot Vacuums","Robot vacuum","Wi-Fi, BLE","Trifo","Trifo"),
  S("Robot Vacuums","Robot vacuum","Wi-Fi, BLE","bObsweep","bObsweep"),
  S("Robot Vacuums","Robot vacuum","Wi-Fi, BLE","ILIFE","ILIFEHOME"),
  S("Robot Vacuums","Robot vacuum","Wi-Fi, BLE","Proscenic","Proscenic"),
  S("Robot Vacuums","Robot vacuum","Wi-Fi, BLE","Lefant","Lefant"),
  S("Robot Vacuums","Robot vacuum","Wi-Fi","Bosch","Home Connect"),
  // ---- Lighting ----
  S("Lighting","LED strip","BLE, Wi-Fi","Cololight","Cololight"),
  S("Lighting","Smart bulb","Wi-Fi, BLE","Geeni","Geeni"),
  S("Lighting","Smart bulb","Wi-Fi, BLE","Cree Lighting","Cree Lighting"),
  S("Lighting","LED controller","BLE","MiBoxer","MiBoxer"),
  S("Lighting","LED controller","BLE, Wi-Fi","Sunricher","Sunricher"),
  S("Lighting","Smart bulb","Wi-Fi, BLE","Aurora","Aurora Lighting"),
  // ---- Electrical ----
  S("Electrical","Smart plug","Wi-Fi, BLE","Wemo","Wemo"),
  S("Electrical","Smart plug","Wi-Fi","Insteon","Insteon"),
  S("Electrical","Smart plug","Wi-Fi, BLE","iDevices","iDevices"),
  S("Electrical","Smart switch","Wi-Fi, BLE","Eaton","Eaton"),
  // ---- Smart Home ----
  S("Smart Home","Automation system","Wi-Fi, Ethernet","Crestron","Crestron Home"),
  S("Smart Home","Automation system","Wi-Fi, Ethernet","Control4","Control4"),
  S("Smart Home","Automation system","Wi-Fi, Ethernet","Savant","Savant"),
  S("Smart Home","Automation system","Wi-Fi, Ethernet","RTI","RTI Control"),
  S("Smart Home","Automation system","Wi-Fi, Ethernet","Nice / ELAN","ELAN"),
  // ---- Smart Locks extra ----
  S("Smart Locks","Smart lock","BLE, Wi-Fi","Master Lock","Master Lock Vault"),
  // ---- Dash Cams extra ----
  S("Dash Cams","Dash cam","Wi-Fi","Thinkware","Thinkware"),
  S("Dash Cams","Dash cam","Wi-Fi, Cloud","BlackVue","BlackVue"),
];

const arg = (k, d) => { const i = process.argv.indexOf(k); return i > -1 ? process.argv[i + 1] : d; };
const ONLY = arg("--only", "");
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const norm = (s) => String(s || "").toLowerCase().replace(/[^a-z0-9]/g, "");

async function search(term, attempt = 0) {
  const url = "https://itunes.apple.com/search?term=" + encodeURIComponent(term) + "&entity=software&limit=8&country=us";
  try {
    const res = await fetch(url, { headers: { "user-agent": "iot-atlas-discovery/1.0" } });
    if (res.status === 403 || res.status === 429) {
      if (attempt >= 3) return [];
      await sleep(5000 * Math.pow(2, attempt));
      return search(term, attempt + 1);
    }
    if (!res.ok) return [];
    return (await res.json()).results || [];
  } catch { return []; }
}

const cell = (v) => { const s = v == null ? "" : String(v); return /[",\r\n]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s; };
const HEAD = ["category","segment","protocols","brand","query","match","app_name","developer","app_id","price","score"];
const rows = [];
const seeds = ONLY ? SEEDS.filter((s) => s.cat.toLowerCase().includes(ONLY.toLowerCase())) : SEEDS;

for (const s of seeds) {
  const results = await search(s.q);
  const q = norm(s.q), b = norm(s.brand);
  let best = null, bestScore = 0;
  for (const r of results) {
    const t = norm(r.trackName), d = norm(r.sellerName);
    let sc = 0;
    if (t === q) sc = 100; else if (t.startsWith(q)) sc = 80; else if (t.includes(q)) sc = 60;
    if (b && (t.includes(b) || d.includes(b))) sc += 20;
    if (r.primaryGenreName === "Utilities" || r.primaryGenreName === "Health & Fitness") sc += 3;
    if (sc > bestScore) { bestScore = sc; best = r; }
  }
  rows.push([s.cat,s.seg,s.proto,s.brand,s.q,best?best.trackName:"",best?(best.trackName+""):"",best?best.sellerName:"",best?best.trackId:"",best?best.formattedPrice:"",bestScore].map(cell).join(","));
  process.stdout.write(".");
  await sleep(320);
}
fs.writeFileSync(OUT, [HEAD.join(",")].concat(rows).join("\r\n") + "\r\n", "utf8");
console.log("\nwrote " + rows.length + " rows -> content-templates/app-discovery.csv");
