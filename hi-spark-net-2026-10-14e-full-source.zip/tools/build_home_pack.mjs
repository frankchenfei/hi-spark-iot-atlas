#!/usr/bin/env node
/**
 * Builds assets/home-pack.js - the trimmed dataset the homepage renders from.
 *
 * The homepage needs about twenty brands, sixteen platforms, twelve apps and a
 * dozen knowledge records, but the shared catalogue files carry the whole
 * database (290 brands, 998 apps, 1,543 entities). Loading all of them costs the
 * homepage roughly 1.8 MB of JavaScript.
 *
 * This tool loads the real catalogue in a sandbox, takes the records the
 * homepage actually paints, keeps their translations and writes one compact
 * file. Counters that must show the true catalogue size are preserved in
 * window.IOT_TOTALS so nothing on the page under-claims the dataset.
 */
import fs from "node:fs";
import path from "node:path";
import vm from "node:vm";
import { fileURLToPath } from "node:url";
import { APP_FILES } from "./app-batches.mjs";

const PROTO = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const ASSETS = path.join(PROTO, "assets");

/* Catalogue load order. This is deliberately independent of index.html: the
   homepage's own script list is the slim profile this tool produces, so reading it
   back would make the pack shrink on every rebuild. Mirrors the catalogue lists in
   tools/apply_script_profiles.mjs. */
const DATA = ["data.js"];
const CATALOG = ["brands.js","brand-site-verified.js","brand-scores.js","category-hub.js","clouds.js","knowledge.js","knowledge-extra.js","knowledge-extra2.js","logo-map.js","product-directory.js","compare-data.js","brand-index.js","compatibility-data.js","model-data.js","troubleshooting-data.js","certification-data.js"];
const AMAZON = ["amazon-rankings.js"];
const CONTENT = ["content-i18n-brands.js","content-i18n-apps.js","content-i18n-knowledge.js","content-i18n-cloud.js"];
const ordered = [...DATA, ...CATALOG, ...APP_FILES, ...AMAZON, ...CONTENT];
if (!ordered.length) throw new Error("no catalogue scripts declared");

const ctx = { console, URLSearchParams, location: { pathname: "/index.html", search: "" } };
ctx.window = ctx;
ctx.globalThis = ctx;
vm.createContext(ctx);
for (const f of ordered) {
  const abs = path.join(ASSETS, f);
  if (!fs.existsSync(abs)) throw new Error("missing asset " + f);
  vm.runInContext(fs.readFileSync(abs, "utf8"), ctx, { filename: f });
}
const W = ctx;
const arr = (v) => (Array.isArray(v) ? v : []);
const brandList = arr(W.IOT_BRANDS);
const cloudList = arr(W.IOT_CLOUDS);
const appList = arr(W.IOT_APP_DIRECTORY);
const knowledge = W.IOT_KNOWLEDGE || {};
const products = arr(W.IOT_PRODUCT_DIRECTORY);
const scores = W.IOT_BRAND_SCORES || { brands: {} };
const scoreMap = scores.brands || {};
const logoMap = W.IOT_LOGO_MAP || { brands: {}, clouds: {} };
const amazon = W.IOT_AMAZON || { products: [], categories: [] };
const content = W.IOT_CONTENT_I18N || {};

/* ---- what the homepage paints -------------------------------------------------
   app.js:  brandDirectory(18) slice of non-cloud brands, cloudDirectory(12)
   brand-scorecard-ui.js: top 6 by overall score
   apps-ui.js: slice(0, 6) of the app directory
   knowledge-ui.js: protocols slice(0, 6)
   ai-signals-ui.js: IOT_PRODUCT_DIRECTORY[0] or the reolink fallback record      */
const nonCloud = brandList.filter((b) => !["cloud-infrastructure", "cloud-iot-platform"].includes(b.type));
const keptBrands = nonCloud.slice(0, 20);
const keptBrandSlugs = new Set(keptBrands.map((b) => b.slug));
const topScoreSlugs = Object.keys(scoreMap)
  .sort((a, b) => (Number(scoreMap[b] && scoreMap[b].overall) || 0) - (Number(scoreMap[a] && scoreMap[a].overall) || 0))
  .slice(0, 8);
topScoreSlugs.forEach((s) => keptBrandSlugs.add(s));
const keptClouds = cloudList.slice(0, 16);
const keptCloudSlugs = new Set(keptClouds.map((c) => c.slug));
const keptApps = appList.slice(0, 12);
const keptKnowledge = {
  protocols: arr(knowledge.protocols).slice(0, 12),
  standards: arr(knowledge.standards).slice(0, 12),
  guides: arr(knowledge.guides).slice(0, 12),
  concepts: arr(knowledge.concepts).slice(0, 8),
  apps: arr(knowledge.apps).slice(0, 8)
};
const keptProducts = products.filter((p) => p.slug === "reolink-argus-4-pro").concat(products.slice(0, 6));
const seenProduct = new Set();
const productsTrimmed = keptProducts.filter((p) => !seenProduct.has(p.slug) && seenProduct.add(p.slug));

/* ---- translations for exactly the kept records ------------------------------- */
function trimBucket(bucket, slugs) {
  const src = content[bucket];
  if (!src || !slugs) return {};
  const out = {};
  slugs.forEach((s) => { if (src[s]) out[s] = src[s]; });
  return out;
}
const knowledgeSlugs = new Set([
  ...keptKnowledge.protocols.map((x) => x.slug),
  ...keptKnowledge.standards.map((x) => x.slug),
  ...keptKnowledge.concepts.map((x) => x.slug)
]);
const contentTrimmed = {
  brands: trimBucket("brands", keptBrandSlugs),
  apps: trimBucket("apps", new Set(keptApps.map((a) => a.slug))),
  clouds: trimBucket("clouds", keptCloudSlugs),
  protocols: trimBucket("protocols", knowledgeSlugs),
  standards: trimBucket("standards", knowledgeSlugs),
  concepts: trimBucket("concepts", knowledgeSlugs),
  comparisons: {}
};

const totals = {
  allBrands: brandList.length,
  brands: nonCloud.length,
  apps: appList.length,
  clouds: cloudList.length,
  knowledge: arr(knowledge.protocols).length + arr(knowledge.standards).length + arr(knowledge.guides).length + arr(knowledge.concepts).length,
  comparisons: arr(W.IOT_COMPARISONS).length,
  categories: arr(W.IOT_CATEGORY_HUB).length,
  products: products.length,
  amazon: arr(amazon.products).length
};
totals.records = totals.brands + totals.apps + totals.clouds + totals.comparisons + totals.knowledge + totals.amazon;

const payload = [
  "/* Generated by tools/build_home_pack.mjs - the homepage renders from this trimmed",
  "   dataset instead of loading the full catalogue. Counters that must show the true",
  "   catalogue size live in window.IOT_TOTALS. Re-run the build after data changes. */",
  "window.IOT_TOTALS = " + JSON.stringify(totals) + ";",
  "window.IOT_BRANDS = " + JSON.stringify(keptBrands) + ";",
  "window.IOT_BRAND_SCORES = " + JSON.stringify({ generated_at: scores.generated_at, disclaimer: scores.disclaimer, method: scores.method, dims: scores.dims, brands: Object.keys(scoreMap).filter((s) => keptBrandSlugs.has(s)).reduce((m, s) => (m[s] = scoreMap[s], m), {}) }) + ";",
  "window.IOT_CLOUDS = " + JSON.stringify(keptClouds) + ";",
  "window.IOT_LOGO_MAP = " + JSON.stringify({ brands: Object.keys(logoMap.brands || {}).filter((s) => keptBrandSlugs.has(s)).reduce((m, s) => (m[s] = logoMap.brands[s], m), {}), clouds: Object.keys(logoMap.clouds || {}).filter((s) => keptCloudSlugs.has(s)).reduce((m, s) => (m[s] = logoMap.clouds[s], m), {}) }) + ";",
  "window.IOT_KNOWLEDGE = " + JSON.stringify(keptKnowledge) + ";",
  "window.IOT_APP_DIRECTORY = " + JSON.stringify(keptApps) + ";",
  "window.IOT_PRODUCT_DIRECTORY = " + JSON.stringify(productsTrimmed) + ";",
  "window.IOT_AMAZON = " + JSON.stringify({ products: arr(amazon.products).slice(0, 6), categories: arr(amazon.categories).slice(0, 3) }) + ";",
  "window.IOT_COMPARISONS = [];",
  "window.IOT_CATEGORY_HUB = [];",
  "window.IOT_COMPATIBILITY = [];",
  "window.IOT_MODELS = [];",
  "window.IOT_TROUBLESHOOTING = [];",
  "window.IOT_CERTIFICATIONS = [];",
  "window.IOT_CONTENT_I18N = " + JSON.stringify(contentTrimmed) + ";",
  ""
].join("\n");

fs.writeFileSync(path.join(ASSETS, "home-pack.js"), payload, "utf8");
const before = ordered.reduce((n, f) => n + fs.statSync(path.join(ASSETS, f)).size, 0);
console.log("home-pack.js written: " + (payload.length / 1024).toFixed(0) + " KB replacing " + (before / 1024).toFixed(0) + " KB of catalogue scripts");
console.log("  brands " + keptBrands.length + "/" + brandList.length + " | clouds " + keptClouds.length + "/" + cloudList.length + " | apps " + keptApps.length + "/" + appList.length + " | knowledge " + (keptKnowledge.protocols.length + keptKnowledge.standards.length + keptKnowledge.guides.length + keptKnowledge.concepts.length) + " | products " + productsTrimmed.length + "/" + products.length);
