#!/usr/bin/env node
/**
 * IoT Atlas - global pre-delivery audit.
 * Scans the customer-facing prototype for language leaks, broken links,
 * missing assets, incomplete records and malformed markup.
 *
 * Usage: node tools/audit_site.mjs
 * Exit code 1 if any ERROR-level finding is present.
 */
import fs from "node:fs";
import path from "node:path";
import vm from "node:vm";
import { fileURLToPath } from "node:url";
import { APP_FILES } from "./app-batches.mjs";

const PROTO = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const ASSETS = path.join(PROTO, "assets");
const errors = [];
const warnings = [];
const notes = [];

// Files that are operator-facing evidence rather than published content.
// Developer legal names are recorded verbatim, which can include CJK characters.
// Nothing here is served to visitors; the rule still applies to every page asset.
const INTERNAL_FILES = new Set(["app-store-verification.csv","app-store-not-found-review.csv","app-brand-attribution-review.csv","app-brand-attribution-review-v2.csv","app-brand-verification-evidence.csv","app-discovery.csv","app-link-review.csv","brand-site-verification.csv"]);

const err = (m) => errors.push(m);
const warn = (m) => warnings.push(m);
const list = (dir, ext) =>
  fs.readdirSync(dir, { withFileTypes: true })
    .filter((d) => d.isFile() && ext.includes(path.extname(d.name)))
    .map((d) => d.name);

// Root pages plus the pre-rendered entity pages under /brand, /app and friends.
const ENTITY_DIRS = ["brand","app","cloud","protocol","compare","category","product"];
const htmlFiles = list(PROTO, [".html"]).concat(
  ENTITY_DIRS.flatMap((d) => fs.existsSync(path.join(PROTO, d))
    ? list(path.join(PROTO, d), [".html"]).map((f) => d + "/" + f)
    : [])
);
const jsFiles = list(ASSETS, [".js"]);
const cssFiles = list(ASSETS, [".css"]);
const csvFiles = fs.existsSync(path.join(PROTO, "content-templates"))
  ? list(path.join(PROTO, "content-templates"), [".csv"]) : [];

// ---------- 1. language leak scan ----------
const CJK = /[\u3400-\u4dbf\u4e00-\u9fff\uf900-\ufaff\u3040-\u30ff\uac00-\ud7af]/;
const scriptScan = /\u0000/;
let scanned = 0;
for (const f of [...htmlFiles, ...jsFiles, ...cssFiles, ...csvFiles]) {
  const p = f.endsWith(".csv")
    ? path.join(PROTO, "content-templates", f)
    : (htmlFiles.includes(f) ? path.join(PROTO, f) : path.join(ASSETS, f));
  const text = fs.readFileSync(p, "utf8");
  if (INTERNAL_FILES.has(path.basename(p))) { scanned++; continue; }
  scanned++;
  if (CJK.test(text)) {
    const sample = (text.match(CJK) || []).slice(0, 5).join("");
    err(`CJK/CJK-adjacent characters in customer-facing file ${path.relative(PROTO, p)} (e.g. ${sample})`);
  }
  if (scriptScan.test(text)) err(`NUL byte in ${path.relative(PROTO, p)}`);
}
notes.push(`Language scan: ${scanned} customer-facing files checked, 0 CJK leaks expected.`);

// ---------- 2. internal link + asset reference check ----------
// Search engines count rendered characters, so decode entities before measuring
// title and description length. Without this, "&amp;" counts as five characters.
const decodeEntities = (s) => String(s)
  .replace(/&amp;/g, "&").replace(/&lt;/g, "<").replace(/&gt;/g, ">")
  .replace(/&quot;/g, '"').replace(/&#39;/g, "'").replace(/&nbsp;/g, " ");
const plain = (s) => decodeEntities(s).trim();

/* Links are page-relative now ("../assets/app.js" from a page one directory
   down), so a reference has to be resolved against the page that contains it -
   joining it to the project root made every relative link look broken. */
const existsRel = (from, ref) => {
  const clean = ref.split("?")[0].split("#")[0];
  if (!clean || /^(https?:|mailto:|tel:|data:|#)/.test(clean)) return true;
  const target = clean.startsWith("/")
    ? path.join(PROTO, clean)
    : path.resolve(PROTO, path.dirname(from), clean);
  return fs.existsSync(target);
};
let linkCount = 0;
for (const f of htmlFiles) {
  const p = path.join(PROTO, f);
  const text = fs.readFileSync(p, "utf8");
  // JSON-LD payloads carry URLs in string values; they are data, not navigable
  // references, so strip script blocks before collecting link targets.
  const linkText = text.replace(/<script[\s\S]*?<\/script>/gi, "");
  const refs = [...linkText.matchAll(/(?:href|src)="([^"]+)"/g)]
    .map((m) => m[1])
    .filter((r) => !/[+`]|\$\{/.test(r));
  for (const r of refs) {
    linkCount++;
    if (!existsRel(f, r)) err(`Broken reference in ${f}: ${r}`);
  }
  // malformed markup sanity
  const open = (text.match(/<div\b/g) || []).length;
  const close = (text.match(/<\/div>/g) || []).length;
  if (open !== close) err(`Unbalanced <div> in ${f}: ${open} open / ${close} close`);
  if (!/<html[^>]*lang="/.test(text)) warn(`${f}: <html> missing lang attribute`);
  if (!/<title>[^<]+<\/title>/.test(text)) warn(`${f}: missing or empty <title>`);
  if (!/name="viewport"/.test(text)) warn(`${f}: missing viewport meta`);
  // SEO hygiene
  const title=plain((text.match(/<title>([^<]*)<\/title>/)||[,""])[1]);
  const desc=plain((text.match(/<meta name="description" content="([^"]*)"/)||[,""])[1]);
  if(title.length<25||title.length>65) warn(`${f}: title length ${title.length} (aim 25-65)`);
  if(!desc) warn(`${f}: missing meta description`);
  else if(desc.length<70||desc.length>165) warn(`${f}: description length ${desc.length} (aim 70-165)`);
  if(!/property="og:image"/.test(text)) warn(`${f}: no og:image`);
  const h1 = (text.match(/<h1[\s>]/g) || []).length;
  if (h1 === 0) warn(`${f}: no <h1>`);
  // every page should load the shared shell
  if (!/assets\/app\.js/.test(text)) warn(`${f}: does not load assets/app.js`);
  if (/https:\/\/example\.com/.test(text)) err(`${f}: stale example.com production URL`);
  const hashLinks = (text.match(/href=["']#["']/g) || []).length;
  if (hashLinks && !/styleguide\.html$/.test(f)) warn(`${f}: ${hashLinks} placeholder href="#" link(s)`);
}
notes.push(`Link check: ${linkCount} internal references resolved across ${htmlFiles.length} pages.`);

// ---------- 3. asset inventory ----------
for (const f of jsFiles) {
  const text = fs.readFileSync(path.join(ASSETS, f), "utf8");
  if (text.length < 20) warn(`assets/${f} looks empty`);
}
const logoDir = path.join(ASSETS, "logos");
const logos = fs.existsSync(logoDir) ? fs.readdirSync(logoDir).filter((f) => f.endsWith(".svg")) : [];
notes.push(`Assets: ${jsFiles.length} scripts, ${cssFiles.length} stylesheets, ${logos.length} SVG logos.`);

// ---------- 4. content integrity ----------
const ctx = { window: {} };
vm.createContext(ctx);
for (const f of ["data.js","brands.js","brand-site-verified.js","brand-scores.js","clouds.js","knowledge.js","knowledge-extra.js","knowledge-extra2.js","logo-map.js","compare-data.js","amazon-rankings.js","compatibility-data.js","model-data.js","troubleshooting-data.js","certification-data.js"]) {
  const p = path.join(ASSETS, f);
  if (!fs.existsSync(p)) { warn(`missing data file assets/${f}`); continue; }
  vm.runInContext(fs.readFileSync(p, "utf8"), ctx, { filename: f });
}
const w = ctx.window;

function dupCheck(label, items, key = "slug") {
  if (!Array.isArray(items)) return;
  const seen = new Map();
  for (const it of items) {
    const k = it && it[key];
    if (!k) { err(`${label}: record missing "${key}"`); continue; }
    if (seen.has(k)) err(`${label}: duplicate ${key} "${k}"`);
    seen.set(k, true);
  }
  notes.push(`${label}: ${items.length} records, ${seen.size} unique ${key}s.`);
}

dupCheck("brands", w.IOT_BRANDS);
dupCheck("clouds", w.IOT_CLOUDS);
dupCheck("comparisons", w.IOT_COMPARISONS);
dupCheck("knowledge.protocols", w.IOT_KNOWLEDGE && w.IOT_KNOWLEDGE.protocols);
dupCheck("knowledge.standards", w.IOT_KNOWLEDGE && w.IOT_KNOWLEDGE.standards);
dupCheck("knowledge.guides", w.IOT_KNOWLEDGE && w.IOT_KNOWLEDGE.guides);
dupCheck("knowledge.concepts", w.IOT_KNOWLEDGE && w.IOT_KNOWLEDGE.concepts);
dupCheck("knowledge.apps", w.IOT_KNOWLEDGE && w.IOT_KNOWLEDGE.apps);

// app directory integrity
const appCtx = { window: {} };
vm.createContext(appCtx);
const APP_ORDER = APP_FILES;
for (const f of APP_ORDER.filter((f) => fs.existsSync(path.join(ASSETS, f)))) {
  vm.runInContext(fs.readFileSync(path.join(ASSETS, f), "utf8"), appCtx, { filename: f });
}
const apps = appCtx.window.IOT_APP_DIRECTORY || [];
dupCheck("apps", apps);
for (const a of apps) {
  if (!a.android_url || !/^https?:\/\//.test(a.android_url)) err(`app ${a.slug}: missing Google Play URL`);
  if (!a.ios_url || !/^https?:\/\//.test(a.ios_url)) err(`app ${a.slug}: missing App Store URL`);
  if (!a.category) warn(`app ${a.slug}: no category`);
  if (!/^https:\/\/play\.google\.com\//.test(a.android_url)) err(`app ${a.slug}: Android URL is not a Google Play URL`);
  if (!/^https:\/\/apps\.apple\.com\//.test(a.ios_url)) err(`app ${a.slug}: iOS URL is not an Apple App Store URL`);
}
// logo integrity: every directory record must resolve to a locally hosted,
// self-contained SVG. Record source categories so official marks and fallbacks
// remain auditable instead of silently drifting.
const logoMap = w.IOT_LOGO_MAP || { brands: {}, clouds: {} };
const directoryBrands = (w.IOT_BRANDS || []).filter((b) => !["cloud-infrastructure", "cloud-iot-platform"].includes(b.type));
const logoSourceCounts = {};
for (const [group, items] of [["brands", directoryBrands], ["clouds", w.IOT_CLOUDS || []]]) {
  for (const item of items) {
    const entry = logoMap[group] && logoMap[group][item.slug];
    if (!entry || !entry.file) { err(`logo map ${group}/${item.slug}: missing entry`); continue; }
    const file = path.join(logoDir, entry.file);
    if (!fs.existsSync(file)) { err(`logo map ${group}/${item.slug}: missing assets/logos/${entry.file}`); continue; }
    const svg = fs.readFileSync(file, "utf8");
    if (!/<svg[\s>]/i.test(svg) || !/\bviewBox=/i.test(svg)) err(`logo ${entry.file}: missing svg root or viewBox`);
    if (/<script\b|(?:^|\s)on\w+\s*=|foreignObject|javascript:/i.test(svg)) err(`logo ${entry.file}: unsafe SVG content`);
    const source = entry.source || "unlabelled";
    logoSourceCounts[source] = (logoSourceCounts[source] || 0) + 1;
  }
}
const logoSourceSummary = Object.keys(logoSourceCounts).sort().map((k) => `${k}=${logoSourceCounts[k]}`).join(", ");
notes.push(`Logo sources: ${logoSourceSummary}.`);

// amazon integrity
const am = w.IOT_AMAZON;
if (am) {
  dupCheck("amazon products", am.products, "asin");
  const cats = new Set();
  for (const p of am.products) {
    cats.add(p.category);
    if (!p.markets || !p.markets.length) err(`amazon ${p.asin}: no markets`);
    if (typeof p.score !== "number") err(`amazon ${p.asin}: score not numeric`);
  }
  notes.push(`Amazon: ${am.products.length} products across ${cats.size} categories.`);
}

// completeness manifest cross-check
const k = w.IOT_KNOWLEDGE;
if (k && k.completeness) {
  const t = k.completeness.types;
  const actual = { protocols: k.protocols.length, standards: k.standards.length, guides: k.guides.length, concepts: k.concepts.length, apps: k.apps.length };
  for (const key of Object.keys(actual)) {
    if (!t[key]) { err(`completeness manifest missing type "${key}"`); continue; }
    if (t[key].count !== actual[key]) err(`completeness count mismatch for ${key}: manifest ${t[key].count} vs actual ${actual[key]}`);
  }
}

// ---------- 5b. entity subject guard ----------
// Detail pages are static files with no query string. If a renderer reads its
// subject straight from \`params.get('brand')\` it gets null and falls back to the
// hard-coded default, so every page showed Ring / Tuya Smart / AWS / Matter while
// the pre-rendered markup underneath was correct. The subject must come from
// window.IOT_ENTITY_SLUG, which resolves the path first and the query second.
const SUBJECT_PARAMS = ["brand","app","provider","protocol","pair","category","product","compat","model","issue","certification"];
let subjectReads = 0;
for (const f of jsFiles) {
  const text = fs.readFileSync(path.join(ASSETS, f), "utf8");
  for (const param of SUBJECT_PARAMS) {
    for (const q of ["'", '"']) {
      const needle = "params.get(" + q + param + q + ")";
      if (text.indexOf(needle) > -1) {
        err(f + ": reads the page subject from " + needle + " - use window.IOT_ENTITY_SLUG instead");
      }
    }
    // the helper itself legitimately reads the query string as a fallback
    const helperUses = text.indexOf("IOT_ENTITY_SLUG");
    if (helperUses > -1) subjectReads++;
  }
}
notes.push("Entity subject guard: " + subjectReads + " renderer(s) resolve their subject from the path.");

// ---------- 5a. entity link guard ----------
// Entity pages live at <base>/brand/<slug>.html and so on, and the links are built
// in JavaScript so the static link check never sees them. Two failure modes have
// shipped: a missing ".html", and a search-result index that passed the URL as a
// function argument instead of an href attribute. Scan every href expression and
// require an .html suffix on the same line.
const ENTITY_DIR = /(?:^|[\"'`+\/])(app|brand|cloud|protocol|compare|category|product)\//;
let entityLinks = 0;
for (const f of jsFiles) {
  const text = fs.readFileSync(path.join(ASSETS, f), "utf8");
  const lines2 = text.split("\n");
  lines2.forEach((line, idx) => {
    if (line.indexOf("href") === -1) return;
    // only lines that actually build an entity URL
    const expr = line.slice(line.indexOf("href"));
    if (!ENTITY_DIR.test(expr)) return;
    entityLinks++;
    if (!/\.html/.test(expr)) {
      err(f + ":" + (idx + 1) + " entity link without .html -> " + expr.trim().slice(0, 76));
    }
  });
  // bare URL strings passed as arguments (search-index entries)
  for (const m of text.matchAll(/,[\"'`](?:\.\.\/|\$\{[^}]*\})?(app|brand|cloud|protocol|compare|category|product)\//g)) {
    const line = text.slice(m.index, text.indexOf("\n", m.index) < 0 ? m.index + 160 : text.indexOf("\n", m.index));
    entityLinks++;
    if (!/\.html/.test(line)) err(f + ": entity URL argument without .html -> " + line.trim().slice(0, 76));
  }
  // slugs must be URL-safe
  if (/[\"'`][^\"'`]*?(app|brand|cloud|protocol|compare|category|product)\/[^\"'`]*\s[^\"'`]*[\"'`]/.test(text)) {
    err(f + ": entity URL contains a space");
  }
}
notes.push("Entity link guard: " + entityLinks + " JS-built detail URLs checked.");

// ---------- 5. script loading regression guard ----------
// Page-specific script profiles (tools/apply_script_profiles.mjs) trim each page to the
// scripts it needs. Two failure modes have bitten us before and must never ship:
//   (a) a page references app.js before the data files it reads at IIFE time
//   (b) an asset script that exists on disk is wired into no page at all
const SRC_RE = /<script src="assets\/([^"?]+)(?:\?[^"]*)?"><\/script>/g;
const referenced = new Map(); // filename -> [pages]
for (const f of htmlFiles) {
  const text = fs.readFileSync(path.join(PROTO, f), "utf8");
  const order = [...text.matchAll(SRC_RE)].map((m) => m[1]);
  for (const n of order) {
    if (!referenced.has(n)) referenced.set(n, []);
    referenced.get(n).push(f);
  }
  const appIdx = order.lastIndexOf("app.js");
  if (appIdx === -1) continue;
  if (appIdx !== order.length - 1) {
    err(`${f}: app.js is not the last script (position ${appIdx + 1}/${order.length}); runtime data will be missing`);
  }
  // any window.IOT_* producer must precede app.js
  const producers = order.map((n, i) => [n, i]).filter(([n, i]) => i > appIdx && n !== "app.js");
  if (producers.length) err(`${f}: ${producers.length} script(s) load after app.js (${producers.map(([n]) => n).join(", ")})`);
}
const orphanScripts = jsFiles.filter((f) => !referenced.has(f));
if (orphanScripts.length) err(`asset scripts referenced by no page: ${orphanScripts.join(", ")}`);
// Detail templates carry their subject in a query parameter, so they need
// entity-seo.js to give each entity its own title, canonical and JSON-LD node.
// Without it every brand and app collapses into one template URL.
const DETAIL_PAGES = ["brand-detail.html","app-detail.html","cloud-detail.html","protocol-detail.html","compare-detail.html","product.html","category-detail.html"];
for (const f of DETAIL_PAGES) {
  const refs = referenced.get("entity-seo.js") || [];
  if (!refs.includes(f)) err(f + ": entity-seo.js must be loaded so the entity gets its own canonical");
}
notes.push(`Script guard: ${jsFiles.length} asset scripts, ${referenced.size} wired into pages, ${orphanScripts.length} orphaned; app.js last on every page that loads it.`);

// ---------- 6. homepage first-load pack ----------
// The homepage renders from assets/home-pack.js (a trimmed catalogue) instead of
// loading every data file. If the catalogue changes without rebuilding the pack,
// the page silently under-reports the dataset, so verify the totals here.
const homeHtml = fs.readFileSync(path.join(PROTO, "index.html"), "utf8");
const homePackPath = path.join(ASSETS, "home-pack.js");
if (!fs.existsSync(homePackPath)) {
  err("assets/home-pack.js is missing - run tools/build_home_pack.mjs");
} else {
  const hpCtx = { window: {} };
  vm.createContext(hpCtx);
  vm.runInContext(fs.readFileSync(homePackPath, "utf8"), hpCtx, { filename: "home-pack.js" });
  const hp = hpCtx.window;
  const T = hp.IOT_TOTALS || {};
  const kn = w.IOT_KNOWLEDGE || {};
  const truth = {
    brands: (w.IOT_BRANDS || []).filter((b) => !["cloud-infrastructure","cloud-iot-platform"].includes(b.type)).length,
    apps: apps.length,
    clouds: (w.IOT_CLOUDS || []).length,
    amazon: ((w.IOT_AMAZON || {}).products || []).length,
    knowledge: (kn.protocols || []).length + (kn.standards || []).length + (kn.guides || []).length + (kn.concepts || []).length
  };
  for (const key of Object.keys(truth)) {
    if (T[key] !== truth[key]) err("home-pack.js is stale: IOT_TOTALS." + key + "=" + T[key] + " but the catalogue has " + truth[key] + " - re-run tools/build_home_pack.mjs");
  }
  const brandSlugs = new Set((w.IOT_BRANDS || []).map((b) => b.slug));
  for (const b of hp.IOT_BRANDS || []) if (!brandSlugs.has(b.slug)) err("home-pack.js brand " + b.slug + " is no longer in the catalogue");
  const appSlugs = new Set(apps.map((a) => a.slug));
  for (const a of hp.IOT_APP_DIRECTORY || []) if (!appSlugs.has(a.slug)) err("home-pack.js app " + a.slug + " is no longer in the app directory");
  if (!homeHtml.includes("assets/home-pack.js")) err("index.html does not load assets/home-pack.js");
  const homeScripts = [...homeHtml.matchAll(/<script src="assets\/([^"?]+)/g)].map((m) => m[1]);
  const homeBytes = homeScripts.reduce((n, f) => n + (fs.existsSync(path.join(ASSETS, f)) ? fs.statSync(path.join(ASSETS, f)).size : 0), 0);
  const hpKnowledge = hp.IOT_KNOWLEDGE || {};
  const hpKnow = (hpKnowledge.protocols || []).length + (hpKnowledge.standards || []).length + (hpKnowledge.guides || []).length + (hpKnowledge.concepts || []).length;
  notes.push("Homepage first load: " + homeScripts.length + " scripts / " + (homeBytes / 1024).toFixed(0) + " KB; trimmed pack " + (fs.statSync(homePackPath).size / 1024).toFixed(0) + " KB covers " + (hp.IOT_BRANDS || []).length + " brands, " + (hp.IOT_CLOUDS || []).length + " platforms, " + (hp.IOT_APP_DIRECTORY || []).length + " apps, " + hpKnow + " knowledge records.");
  if (homeBytes > 400 * 1024) warn("homepage JavaScript payload is " + (homeBytes / 1024).toFixed(0) + " KB, over the 400 KB budget");
}

// ---------- 7. trilingual policy ----------
// Every new or updated page and record must ship in English, Spanish and French.
// This is a release gate, not a suggestion - a missing translation blocks the build.
const corePath = path.join(ASSETS, "content-i18n-core.js");
const coreCtx = { window: {} };
vm.createContext(coreCtx);
if (fs.existsSync(corePath)) vm.runInContext(fs.readFileSync(corePath, "utf8"), coreCtx, { filename: "content-i18n-core.js" });
const CORE = coreCtx.window.IOT_CONTENT_I18N_CORE || {};
const CORE_SETS = [["compatibility", w.IOT_COMPATIBILITY], ["model", w.IOT_MODELS], ["troubleshooting", w.IOT_TROUBLESHOOTING], ["certification", w.IOT_CERTIFICATIONS]];
let trilingualRecords = 0;
for (const [bucket, records] of CORE_SETS) {
  const store = CORE[bucket] || {};
  for (const rec of records || []) {
    const entry = store[rec.slug];
    if (!entry || !entry.es || !entry.fr) err("trilingual: " + bucket + "/" + rec.slug + " has no es/fr translation (see assets/content-i18n-core.js)");
    else trilingualRecords++;
  }
}
// Indexable root pages must advertise all three languages.
const NO_ALT = new Set(["styleguide.html","logo-gallery.html","perf-demo.html","404.html","brand-detail.html","app-detail.html","cloud-detail.html","protocol-detail.html","compare-detail.html","category-detail.html","product.html"]);
let trilingualPages = 0;
for (const f of fs.readdirSync(PROTO).filter((x) => x.endsWith(".html"))) {
  if (NO_ALT.has(f)) continue;
  const text = fs.readFileSync(path.join(PROTO, f), "utf8");
  const has = (l) => new RegExp('hreflang="' + l + '"').test(text);
  if (has("en") && has("es") && has("fr") && has("x-default")) trilingualPages++;
  else if (!INTERNAL_FILES.has(f)) err("trilingual: " + f + " is missing its en/es/fr + x-default hreflang set");
}
notes.push("Trilingual policy: " + trilingualRecords + " centre records carry es/fr text; " + trilingualPages + " root pages advertise en/es/fr.");

// ---------- report ----------
const line = "-".repeat(68);
console.log(line);
console.log("IoT Atlas - pre-delivery audit");
console.log(line);
for (const n of notes) console.log("  note  " + n);
console.log("");
if (warnings.length) { console.log("WARNINGS (" + warnings.length + ")"); warnings.forEach((m, i) => console.log("  " + (i + 1) + ". " + m)); console.log(""); }
if (errors.length) { console.log("ERRORS (" + errors.length + ")"); errors.forEach((m, i) => console.log("  " + (i + 1) + ". " + m)); }
else console.log("No blocking errors found.");
console.log(line);
console.log(`Result: ${errors.length} errors, ${warnings.length} warnings.`);
process.exit(errors.length ? 1 : 0);

