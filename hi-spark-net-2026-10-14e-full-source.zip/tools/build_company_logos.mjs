import fs from 'node:fs/promises';
import fsSync from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const here=path.dirname(fileURLToPath(import.meta.url));
const root=path.resolve(here,'..');
const logoDir=path.join(root,'assets','logos');
const discoveryPath=path.join(root,'data-sources','logo-discovery.json');
const currentMapPath=path.join(root,'assets','logo-map.js');
const UA={'user-agent':'Mozilla/5.0 (compatible; IoTAtlasBot/1.0; +https://hi-spark.net/)','accept':'image/avif,image/webp,image/png,image/svg+xml,*/*;q=0.8'};
const REPO_BASE={
  'simple-icons':'https://cdn.jsdelivr.net/npm/simple-icons@latest/icons/',
  'gilbarbara-logos':'https://cdn.jsdelivr.net/gh/gilbarbara/logos@main/',
  'dashboard-icons':'https://cdn.jsdelivr.net/gh/homarr-labs/dashboard-icons@main/',
  'lobe-icons':'https://cdn.jsdelivr.net/gh/lobehub/lobe-icons@master/'
};
const REPO_OVERRIDES={
  'hikvision':{repo:'dashboard-icons',path:'svg/hikvision.svg'},
  'axis-communications':{repo:'dashboard-icons',path:'svg/axis.svg'},
  'netatmo':{repo:'dashboard-icons',path:'svg/netatmo.svg'},
  'gl-inet':{repo:'dashboard-icons',path:'svg/glinet.svg'},
  'mercusys':{repo:'dashboard-icons',path:'svg/mercusys.svg'},
  'tenda':{repo:'dashboard-icons',path:'svg/tenda.svg'},
  'losant-losant-enterprise-iot-platform':{repo:'gilbarbara-logos',path:'logos/losant.svg'},
  'tencent-cloud-tencent-cloud-iot-hub':{repo:'lobe-icons',path:'packages/static-svg/icons/tencentcloud-color.svg'},
  'particle-particle-iot-platform':{repo:'gilbarbara-logos',path:'logos/particle.svg',optional:true},
  'blynk-blynk-iot':{repo:'gilbarbara-logos',path:'logos/blynk.svg',optional:true}
};
const MANUAL_SOURCES={
  'simplisafe':{kind:'url',url:'https://simplisafe.com/icons/simplisafe-logo.svg',source:'official-website',license:'Trademark; source recorded'},
  't-motor':{kind:'symbol',url:'https://uav-en.tmotor.com/svg/symbol-defs.svg',symbol:'logo',source:'official-website',license:'Trademark; source recorded'}
  ,'u-blox':{kind:'avatar',url:'https://avatars.githubusercontent.com/u/8056698?v=4',source:'official-social-profile',license:'Profile mark; source recorded'}
  ,'withings':{kind:'avatar',url:'https://avatars.githubusercontent.com/u/125350627?v=4',source:'official-social-profile',license:'Profile mark; source recorded'}
  ,'emnify':{kind:'avatar',url:'https://avatars.githubusercontent.com/u/7429005?v=4',source:'official-social-profile',license:'Profile mark; source recorded'}
  ,'silicon-labs':{kind:'avatar',url:'https://avatars.githubusercontent.com/u/7750191?v=4',source:'official-social-profile',license:'Profile mark; source recorded'}
  ,'airalo':{kind:'avatar',url:'https://avatars.githubusercontent.com/u/65718733?v=4',source:'official-social-profile',license:'Profile mark; source recorded'}
  ,'betafpv':{kind:'avatar',url:'https://avatars.githubusercontent.com/u/35035590?v=4',source:'official-social-profile',license:'Profile mark; source recorded'}
  ,'newbeedrone':{kind:'avatar',url:'https://avatars.githubusercontent.com/u/41106001?v=4',source:'official-social-profile',license:'Profile mark; source recorded'}
  ,'diatone':{kind:'avatar',url:'https://avatars.githubusercontent.com/u/54715061?v=4',source:'official-social-profile',license:'Profile mark; source recorded'}
  ,'ayla-networks-ayla-iot-platform':{kind:'avatar',url:'https://avatars.githubusercontent.com/u/1697025?v=4',source:'official-social-profile',license:'Profile mark; source recorded'}
  ,'thingworx-ptc-thingworx':{kind:'avatar',url:'https://avatars.githubusercontent.com/u/3270533?v=4',source:'official-social-profile',license:'Profile mark; source recorded'}
};
const REJECT_OFFICIAL=new Set(['samsara','bics','blurams','aeris','sensefly','hikvision','simplisafe','miko','mubview','whistle','bissell','t-motor']);
const SOURCE_LABEL={officialSvg:'official-site-svg',officialRaster:'official-site-raster-svg',library:'open-logo-library',monogram:'generated-monogram'};

function readArray(file){const t=fsSync.readFileSync(file,'utf8');return JSON.parse(t.slice(t.indexOf('['),t.lastIndexOf(';')));}
function readMap(file){return eval('('+fsSync.readFileSync(file,'utf8').replace(/^window\.IOT_LOGO_MAP\s*=\s*/,'').replace(/;\s*$/,'')+')');}
const brands=readArray(path.join(root,'assets','brands.js')).filter(x=>!['cloud-infrastructure','cloud-iot-platform'].includes(x.type));
const clouds=readArray(path.join(root,'assets','clouds.js'));
const currentMap=readMap(currentMapPath);
const discovery=JSON.parse(fsSync.readFileSync(discoveryPath,'utf8'));
const discoveryMap=new Map(discovery.map(x=>[x.slug,x]));

const esc=s=>String(s==null?'':s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
const clean=s=>String(s||'').toLowerCase().normalize('NFKD').replace(/&/g,'and').replace(/\+/g,'plus').replace(/[^a-z0-9]+/g,'');
const initials=name=>{const words=String(name||'').replace(/[^a-zA-Z0-9 ]/g,' ').split(/\s+/).filter(Boolean);if(!words.length)return 'IO';if(words.length===1)return words[0].slice(0,2).toUpperCase();return (words[0][0]+words[1][0]).toUpperCase()};
const titleOf=svg=>(svg.match(/<title[^>]*>([\s\S]*?)<\/title>/i)||[,''])[1].replace(/<[^>]+>/g,'').trim();
function parseDim(tag,name){const m=tag.match(new RegExp('\\b'+name+'=["\']([0-9.]+)(?:px)?','i'));return m?parseFloat(m[1]):0}
function sanitizeSvg(raw,name){
  if(!raw||!/<svg[\s>]/i.test(raw)||raw.length>260000)throw new Error('invalid svg');
  if(/<script\b|(?:^|\s)on\w+\s*=|foreignObject|javascript:/i.test(raw))throw new Error('unsafe svg');
  let svg=raw.replace(/<\?xml[\s\S]*?\?>/i,'').replace(/<!doctype[\s\S]*?>/i,'').replace(/<!--[\s\S]*?-->/g,'').trim();
  const open=svg.match(/<svg\b[^>]*>/i); if(!open)throw new Error('missing svg root');
  let tag=open[0];
  let vb=(tag.match(/\bviewBox=["']([^"']+)["']/i)||[])[1];
  if(!vb){const w=parseDim(tag,'width'),h=parseDim(tag,'height');if(w>0&&h>0){vb='0 0 '+w+' '+h;tag=tag.replace(/^<svg/i,'<svg viewBox="'+vb+'"')}}
  if(!vb)throw new Error('svg has no viewBox');
  tag=tag.replace(/\s(width|height)=["'][^"']*["']/gi,'');
  if(!/\sxmlns=/i.test(tag))tag=tag.replace(/^<svg/i,'<svg xmlns="http://www.w3.org/2000/svg"');
  if(!/\brole=/i.test(tag))tag=tag.replace(/^<svg/i,'<svg role="img"');
  if(!/\baria-label=/i.test(tag))tag=tag.replace(/^<svg/i,'<svg aria-label="'+esc(name)+' logo"');
  svg=svg.replace(open[0],tag);
  if(!/<title[\s>]/i.test(svg))svg=svg.replace(/<svg\b[^>]*>/i,m=>m+'<title>'+esc(name)+' logo</title>');
  svg=svg.replace(/currentColor/g,'#0F172A');
  const refs=[...svg.matchAll(/\b(?:href|xlink:href)=["']([^"']+)["']/gi)].map(m=>m[1]);
  const ids=new Set([...svg.matchAll(/\bid=["']([^"']+)["']/gi)].map(m=>m[1]));
  for(const ref of refs){if(/^data:image\//i.test(ref))continue;if(/^#/.test(ref)){if(!ids.has(ref.slice(1)))throw new Error('broken internal svg reference');continue}if(/^https?:|^\//i.test(ref))throw new Error('external svg reference');}
  const colors=[...svg.matchAll(/(?:fill|stroke)=["']([^"']+)["']/gi)].map(m=>m[1].trim()).filter(c=>!['none','transparent','currentColor'].includes(c)&&!c.startsWith('url('));
  const isLight=c=>/^#(?:fff(?:fff)?|f[0-9a-f]{5}|e[0-9a-f]{5})$/i.test(c);
  if(colors.length&&colors.every(isLight))svg=svg.replace(/<svg\b[^>]*>/i,m=>m+'<rect width="100%" height="100%" rx="14" fill="#0F172A"/>');
  return svg;
}
function pngSize(b){if(b.length<24||b.toString('hex',0,8)!=='89504e470d0a1a0a')return null;return {w:b.readUInt32BE(16),h:b.readUInt32BE(20)}}
function gifSize(b){if(b.length<10)return null;return {w:b.readUInt16LE(6),h:b.readUInt16LE(8)}}
function jpegSize(b){let i=2;while(i+9<b.length){if(b[i]!==0xff){i++;continue}const m=b[i+1];if([0xc0,0xc1,0xc2,0xc3,0xc5,0xc6,0xc7,0xc9,0xca,0xcb,0xcd,0xce,0xcf].includes(m))return {h:b.readUInt16BE(i+5),w:b.readUInt16BE(i+7)};if(m===0xd8||m===0xd9){i+=2;continue}i+=2+b.readUInt16BE(i+2)}return null}
function webpSize(b){if(b.length<30||b.toString('ascii',0,4)!=='RIFF'||b.toString('ascii',8,12)!=='WEBP')return null;const type=b.toString('ascii',12,16);if(type==='VP8X')return {w:1+b.readUIntLE(24,3),h:1+b.readUIntLE(27,3)};if(type==='VP8 '){return {w:b.readUInt16LE(26)&0x3fff,h:b.readUInt16LE(28)&0x3fff}}if(type==='VP8L'){const bits=b.readUInt32LE(21);return {w:(bits&0x3fff)+1,h:((bits>>14)&0x3fff)+1}}return null}
function rasterInfo(b,ct){let s=null;const head=b.slice(0,12).toString('hex');if(/png/.test(ct)||head.startsWith('89504e470d0a1a0a'))s=pngSize(b);else if(/gif/.test(ct)||b.slice(0,3).toString('ascii')==='GIF')s=gifSize(b);else if(/jpe?g/.test(ct)||(b[0]===0xff&&b[1]===0xd8))s=jpegSize(b);else if(/webp/.test(ct)||b.toString('ascii',0,4)==='RIFF')s=webpSize(b);if(!s||!s.w||!s.h)return null;return s}
function mimeFor(b,ct){if(/image\//.test(ct))return ct.split(';')[0];if(b.slice(0,8).toString('hex')==='89504e470d0a1a0a')return 'image/png';if(b.slice(0,3).toString('ascii')==='GIF')return 'image/gif';if(b[0]===0xff&&b[1]===0xd8)return 'image/jpeg';if(b.toString('ascii',0,4)==='RIFF'&&b.toString('ascii',8,12)==='WEBP')return 'image/webp';return null}
function wrapRaster(b,name,ct,dark,sourceUrl=''){let info=rasterInfo(b,ct);if(!info){const m=(sourceUrl||'').match(/[?_,]w_?(\\d+)[^0-9]+h_?(\\d+)/i)||(sourceUrl||'').match(/[?&]width=(\\d+)[^0-9]+[?&]?height=(\\d+)/i);if(m)info={w:parseInt(m[1],10),h:parseInt(m[2],10)}}if(!info)throw new Error('invalid raster');if(Math.max(info.w,info.h)<48)throw new Error('raster too small '+info.w+'x'+info.h);const mime=mimeFor(b,ct);if(!mime)throw new Error('unknown raster mime');const ratio=info.w/info.h;let w=96,h=96;if(ratio>1)h=96/ratio;else w=96*ratio;const x=(96-w)/2,y=(96-h)/2;const bg=dark?'<rect width="96" height="96" rx="18" fill="#0F172A"/>':'';return '<svg xmlns="http://www.w3.org/2000/svg" role="img" aria-label="'+esc(name)+' logo" viewBox="0 0 96 96"><title>'+esc(name)+' logo</title>'+bg+'<image x="'+x.toFixed(2)+'" y="'+y.toFixed(2)+'" width="'+w.toFixed(2)+'" height="'+h.toFixed(2)+'" preserveAspectRatio="xMidYMid meet" href="data:'+mime+';base64,'+b.toString('base64')+'"/></svg>';}
async function fetchAsset(url,asText=false){const r=await fetch(url,{headers:UA,redirect:'follow',signal:AbortSignal.timeout(18000)});if(!r.ok)throw new Error('HTTP '+r.status);const b=Buffer.from(await r.arrayBuffer());return {b,ct:(r.headers.get('content-type')||'').toLowerCase(),url:r.url,text:asText?b.toString('utf8'):''}}
function extractSymbol(svg,id){const safe=id.replace(/[.*+?^${}()|[\]\\]/g,'\\$&');const re=new RegExp('<symbol\\b[^>]*\\bid=["\']'+safe+'["\'][^>]*>[\\s\\S]*?<\\/symbol>','i');const m=svg.match(re);if(!m)throw new Error('symbol not found');const tag=m[0].match(/<symbol\b[^>]*>/i)[0];const vb=(tag.match(/viewBox=["']([^"']+)["']/i)||[])[1];const body=m[0].replace(/<symbol\b[^>]*>/i,'').replace(/<\/symbol>/i,'');return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="'+vb+'">'+body+'</svg>';}
function hash(s){let h=0;for(const c of String(s))h=(h*31+c.charCodeAt(0))|0;return Math.abs(h)}
function monogram(name){const palettes=[['#0F766E','#0B4F4A'],['#1D4ED8','#172554'],['#7C3AED','#3B0764'],['#B45309','#5A2E06'],['#0E7490','#164E63'],['#BE123C','#4C0519']];const p=palettes[hash(name)%palettes.length];const label=initials(name);return '<svg xmlns="http://www.w3.org/2000/svg" role="img" aria-label="'+esc(name)+' logo" viewBox="0 0 64 64"><title>'+esc(name)+' logo</title><defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1"><stop stop-color="'+p[0]+'"/><stop offset="1" stop-color="'+p[1]+'"/></linearGradient></defs><rect width="64" height="64" rx="18" fill="url(#g)"/><path d="M-8 45C10 32 25 53 72 22" fill="none" stroke="#fff" stroke-opacity=".14" stroke-width="8"/><text x="32" y="39" text-anchor="middle" font-family="Arial,Helvetica,sans-serif" font-size="21" font-weight="800" fill="#fff">'+esc(label)+'</text></svg>';}
async function loadSimpleIcons(){try{const r=await fetch('https://cdn.jsdelivr.net/npm/simple-icons@latest/_data/simple-icons.json',{headers:UA,signal:AbortSignal.timeout(18000)});const j=await r.json();const m=new Map();for(const x of j){m.set(clean(x.title),x);for(const a of x.aliases?.aka||[])m.set(clean(a),x)}return m}catch{return new Map()}}
const simpleMeta=await loadSimpleIcons();
function recolor(svg){const title=titleOf(svg);const meta=simpleMeta.get(clean(title))||simpleMeta.get(clean(title.replace(/ logo$/i,'')));if(!meta?.hex)return svg;const open=svg.match(/<svg\b[^>]*>/i);if(!open)return svg;let tag=open[0].replace(/\s+fill=["'][^"']*["']/gi,'').replace(/^<svg/i,'<svg fill="#'+meta.hex+'"');return svg.replace(open[0],tag);}
async function buildOne(item,kind){const slug=item.slug;const current=(currentMap[kind]||{})[slug];if(current&&current.source!=='generated-monogram'&&!REJECT_OFFICIAL.has(slug)&&fsSync.existsSync(path.join(logoDir,current.file))){let svg=fsSync.readFileSync(path.join(logoDir,current.file),'utf8');if(current.source==='simple-icons'||current.source==='Simple Icons'||current.source==='cloud-platform-logo')svg=recolor(svg);if(/currentColor/.test(svg))svg=svg.replace(/currentColor/g,'#0F172A');return {slug,file:slug+'.svg',source:current.source==='Simple Icons'?'simple-icons':current.source,sourceUrl:current.sourceUrl||'',license:current.license||'',svg};}
 const manual=MANUAL_SOURCES[slug];if(manual){try{const got=await fetchAsset(manual.url,manual.kind!=='avatar');const svg=manual.kind==='avatar'?wrapRaster(got.b,item.name,got.ct,false,manual.url):(manual.kind==='symbol'?sanitizeSvg(extractSymbol(got.text,manual.symbol),item.name):sanitizeSvg(got.text,item.name));return {slug,file:slug+'.svg',source:manual.kind==='avatar'?SOURCE_LABEL.officialRaster:SOURCE_LABEL.officialSvg,sourceUrl:manual.url,license:manual.license,svg}}catch{}}
 const repo=REPO_OVERRIDES[slug];if(repo&&!repo.optional){try{const url=REPO_BASE[repo.repo]+repo.path;const got=await fetchAsset(url,true);return {slug,file:slug+'.svg',source:SOURCE_LABEL.library,sourceUrl:url,license:'Open logo library; trademarks remain with their owners.',svg:sanitizeSvg(got.text,item.name)}}catch{}}
 const found=discoveryMap.get(slug);if(found&&!REJECT_OFFICIAL.has(slug)){try{if(found.assetType==='svg-inline'){return {slug,file:slug+'.svg',source:SOURCE_LABEL.officialSvg,sourceUrl:found.url||found.source||'',license:'Trademark; source recorded',svg:sanitizeSvg(found.svg,item.name)}}if(found.assetType==='svg-url'||found.assetType==='raster-official'){const got=await fetchAsset(found.source,found.assetType==='svg-url');if(found.assetType==='svg-url'){return {slug,file:slug+'.svg',source:SOURCE_LABEL.officialSvg,sourceUrl:got.url||found.source,license:'Trademark; source recorded',svg:sanitizeSvg(got.text,item.name)}}const dark=/white|night[_-]?owl|avatar[_-]?controls/i.test(found.source||'');return {slug,file:slug+'.svg',source:SOURCE_LABEL.officialRaster,sourceUrl:got.url||found.source,license:'Trademark; source recorded',svg:wrapRaster(got.b,item.name,got.ct,dark,found.source)}}}catch{}}
 if(repo?.optional){try{const url=REPO_BASE[repo.repo]+repo.path;const got=await fetchAsset(url,true);return {slug,file:slug+'.svg',source:SOURCE_LABEL.library,sourceUrl:url,license:'Open logo library; trademarks remain with their owners.',svg:sanitizeSvg(got.text,item.name)}}catch{}}
 return {slug,file:slug+'.svg',source:SOURCE_LABEL.monogram,sourceUrl:'',license:'Original placeholder created by IoT Atlas.',svg:monogram(item.name)};
}
const map={version:'20261008ao',updatedAt:new Date().toISOString(),brands:{},clouds:{},attribution:{simpleIcons:'https://simpleicons.org/',gilbarbara:'https://github.com/gilbarbara/logos',dashboardIcons:'https://github.com/homarr-labs/dashboard-icons',lobeIcons:'https://github.com/lobehub/lobe-icons'}};
const jobs=[...brands.map(x=>['brands',x]),...clouds.map(x=>['clouds',x])];let cursor=0;async function worker(){while(cursor<jobs.length){const [kind,item]=jobs[cursor++];try{const r=await buildOne(item,kind);await fs.writeFile(path.join(logoDir,r.file),r.svg,'utf8');map[kind][r.slug]={file:r.file,source:r.source,sourceUrl:r.sourceUrl,license:r.license}}catch(e){await fs.writeFile(path.join(logoDir,item.slug+'.svg'),monogram(item.name),'utf8');map[kind][item.slug]={file:item.slug+'.svg',source:SOURCE_LABEL.monogram,sourceUrl:'',license:'Original placeholder created by IoT Atlas.'}}}}
await Promise.all(Array.from({length:8},worker));
await fs.writeFile(currentMapPath,'window.IOT_LOGO_MAP = '+JSON.stringify(map,null,2)+';\n','utf8');
const counts={};for(const kind of ['brands','clouds'])for(const v of Object.values(map[kind]))counts[v.source]=(counts[v.source]||0)+1;
const report=['# Company Icon Sources','','This file records how each locally hosted brand and cloud SVG was obtained.','','Generated: '+map.updatedAt,'','- official-site-svg: official website or brand-source vector.','- official-site-raster-svg: official raster mark wrapped in an SVG container when no vector was published.','- simple-icons: Simple Icons, CC0-1.0.','- open-logo-library: jsDelivr/GitHub open logo libraries; trademarks remain with their owners.','- cloud-platform-logo: legacy local cloud vector.','- generated-monogram: original fallback only when no reliable source was available.','','## Source counts','',...Object.entries(counts).sort().map(([k,v])=>'- '+k+': '+v),'','Trademarks and brand rights remain with their respective owners. Listing does not imply endorsement or partnership.',''];
await fs.writeFile(path.join(logoDir,'NOTICE.md'),report.join('\n'),'utf8');
console.log(JSON.stringify({brands:Object.keys(map.brands).length,clouds:Object.keys(map.clouds).length,counts},null,2));
















