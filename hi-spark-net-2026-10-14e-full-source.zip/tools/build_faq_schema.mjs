#!/usr/bin/env node
/**
 * Prerenders FAQPage JSON-LD into selected pages.
 * FAQ structured data is the highest-leverage GEO signal: answer engines and
 * search rich results both extract question/answer pairs verbatim.
 *   node tools/build_faq_schema.mjs
 */
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
const PROTO = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");

const FAQ = {
  "index.html": [
    ["What is IoT Atlas?", "An independent IoT decision platform: a structured catalogue of devices, brands, protocols, companion apps and cloud platforms, with editorial comparisons and implementation guides."],
    ["Does IoT Atlas sell products?", "No. It is a research and comparison site. Some outgoing links are affiliate links, disclosed on every page that uses them."],
    ["Are the Amazon rankings real?", "No. The marketplace pages currently use editorial preview rows. ASINs, ranks, prices and ratings require a licensed source before they can be relied on."],
    ["How many apps and brands are covered?", "Over 800 mobile app records and 290 brand records, each with an official source link where one exists."]
  ],
  "apps.html": [
    ["How do I find the app for my device?", "Search by brand or app name, or filter by category and subcategory. If you are unsure, the product manual or the QR code on the device names the correct app."],
    ["Are the download links official?", "Most point at the official App Store or Google Play listing, verified against Apple's catalogue. Some remain official store search links and are labelled as such."],
    ["Why do several brands use the same app?", "White-label hardware platforms are common in wearables and cameras. Different brands can ship devices managed by the same underlying app, and one vendor can publish several apps."],
    ["An app is missing from one store. What does that mean?", "Usually it is Android-only, or region-locked. Records that could not be found on the US App Store are flagged so you can confirm on Google Play."]
  ],
  "compare.html": [
    ["How are the comparison scores calculated?", "Each decision factor is scored 0-100 for both sides. The headline score is the average across factors, and the winner column shows who takes each individual factor."],
    ["What does a small score gap mean?", "A gap under five points means the choice depends on your priorities rather than a clear winner. Read the individual factors instead of the headline number."],
    ["Who decides the scores?", "IoT Atlas editors, from publicly available product information. They are opinion, not measurements, and the method is stated on each comparison."]
  ],
  "cloud.html": [
    ["Which IoT cloud platform should I choose?", "It depends on whether you are building consumer products or industrial systems, where your data must live, and how much you want to own versus buy. The comparison pages break this into factors."],
    ["Is Google Cloud IoT Core still available?", "No. Google retired the standalone IoT Core service in 2023. Google Cloud remains useful for data and machine learning downstream of your own ingestion layer."],
    ["What is the difference between a hyperscaler and an IoT platform?", "A hyperscaler gives you infrastructure and building blocks you assemble. An IoT platform gives you device management, an app and onboarding as a finished product."]
  ],
  "knowledge.html": [
    ["What is the difference between Matter and Thread?", "They operate at different layers. Matter is the application layer that defines how devices talk to each other. Thread is a low-power IPv6 mesh that carries that traffic. Most Matter devices that are not mains-powered use Thread underneath."],
    ["Is Wi-Fi or Zigbee better for smart home devices?", "Wi-Fi for anything that streams or needs bandwidth, like cameras. Zigbee for battery sensors, buttons and bulbs where low power and mesh range matter more than throughput."],
    ["How do I choose between LoRaWAN and NB-IoT?", "LoRaWAN when you control your own gateways and want low device cost. NB-IoT when devices move across a national footprint and you need operator coverage and an SLA."]
  ],
  "community.html": [
    ["Is the community open to new members?", "Reading is open to everyone. Posting, replying and reviews open with member accounts at launch."],
    ["Are the current discussions written by users?", "No. The existing threads are editorial seed content written by the IoT Atlas desks, clearly labelled as samples. Member discussions replace them over time."],
    ["Can a brand respond to a thread about its product?", "Yes. Brands and manufacturers can request a correction or post a reply under the corrections policy."]
  ],
  "methodology.html": [
    ["What is verified on this site?", "Brand official sites and app store listings are checked by fetching them. Editorial scoring and the brand coverage index are labelled as opinion with the method stated."],
    ["What is placeholder data?", "Marketplace ASINs, ranks, prices and ratings are editorial preview values. They are clearly marked on every page that shows them."],
    ["How do I request a correction?", "Use the corrections policy page. Brands and manufacturers may request a correction, clarification or removal, and supported requests are applied with the change noted."]
  ]
};

let written = 0;
for (const [file, pairs] of Object.entries(FAQ)) {
  const p = path.join(PROTO, file);
  if (!fs.existsSync(p)) continue;
  let html = fs.readFileSync(p, "utf8");
  html = html.replace(/<script type="application\/ld\+json" data-generated="faq-schema"[^>]*>[\s\S]*?<\/script>/g, "");
  const node = {
    "@context": "https://schema.org",
    "@type": "FAQPage",
    mainEntity: pairs.map(([q, a]) => ({
      "@type": "Question",
      name: q,
      acceptedAnswer: { "@type": "Answer", text: a }
    }))
  };
  const tag = '<script type="application/ld+json" data-generated="faq-schema">' + JSON.stringify(node) + "</script>";
  html = html.includes("</head>") ? html.replace("</head>", tag + "</head>") : tag + html;
  fs.writeFileSync(p, html, "utf8");
  written++;
}
console.log("FAQ schema prerendered into " + written + " pages");
