from pathlib import Path
import csv, json, re
# framework CSVs may sit either next to the site (deploy package) or one level up (workspace)
_proto = Path(__file__).resolve().parents[1]
_candidates = [_proto/'data-sources', _proto, _proto.parent]
ROOT = next((c for c in _candidates if (c/'iot_entity_seed_companies.csv').exists()), _proto.parent)
PROTO=Path(__file__).resolve().parents[1]
ASSETS=PROTO/'assets'

def slugify(value):
    value=value.lower().replace('&',' and ').replace('/',' ')
    return re.sub(r'[^a-z0-9]+','-',value).strip('-') or 'item'

brands=[]
seen=set()
for source in ['iot_entity_seed_companies.csv','amazon_iot_brands_seed.csv']:
    with (ROOT/source).open(encoding='utf-8-sig',newline='') as f:
        for r in csv.DictReader(f):
            slug=slugify(r['name'])
            if slug in seen: continue
            seen.add(slug)
            brands.append({'slug':slug,'name':r['name'],'type':r['entity_type'],'url':r['official_url'],'hq':r['hq'],'priority':r['priority'],'app':r['app_or_platform'],'protocols':[x.strip() for x in r['protocols'].split(',') if x.strip()],'categories':[x.strip() for x in r['categories'].split(',') if x.strip()],'notes':r['research_notes']})
(ASSETS/'brands.js').write_text('window.IOT_BRANDS = '+json.dumps(brands,ensure_ascii=False,indent=2)+';\n',encoding='utf-8')

clouds=[]
aliases={
 'AWS':['Amazon','Amazon Web Services'],
 'Microsoft Azure':['Azure','Microsoft'],
 'Oracle Cloud':['Oracle','OCI'],
 'Google Cloud':['Google','GCP'],
 'Alibaba Cloud':['Alibaba','Alibaba Cloud'],
 'Tencent Cloud':['Tencent','Tencent Cloud'],
 'Huawei Cloud':['Huawei','Huawei Cloud'],
 'Volcano Engine':['Volcengine','Volcano Engine'],
 'Tuya Cloud':['Tuya','Tuya IoT'],
 'EMQX':['MQTT broker'],
 'Particle':['Particle IoT']
}
with (ROOT/'cloud_provider_matrix.csv').open(encoding='utf-8-sig',newline='') as f:
    for r in csv.DictReader(f):
        guide=[{'title':'Confirm service status','text':'Verify the current product lifecycle, regional availability and whether the service is active, retired or changing.'},{'title':'Choose the device protocol','text':'Select MQTT, HTTPS, CoAP or another supported protocol and validate authentication, topic design and payload size.'},{'title':'Plan device onboarding','text':'Define certificate provisioning, fleet enrollment, device registry structure and first-boot workflow.'},{'title':'Model operations and cost','text':'Estimate messages, connections, rules, storage, egress and monitoring. Record the pricing date and region.'},{'title':'Design security and OTA','text':'Plan certificate rotation, least-privilege policies, firmware updates, audit logs and incident response.'},{'title':'Connect and pilot','text':'Use the official SDK to onboard a small pilot fleet, monitor failures and document rollback before scaling.'}]
        clouds.append({'slug':slugify(r['provider']+'-'+r['iot_service_or_platform']),'provider':r['provider'],'name':r['iot_service_or_platform'],'type':r['provider_type'],'aliases':aliases.get(r['provider'],[]),'docs':r['official_docs'],'protocols':[x.strip() for x in r['protocols'].split(',') if x.strip()],'regions':r['regions'],'keywords':[x.strip() for x in r['priority_keywords_en'].split(',') if x.strip()],'compare':[x.strip() for x in r['comparison_targets'].split(',') if x.strip()],'notes':r['editorial_notes'],'status':'Verify on official status page','price':'Usage-based / verify official pricing','score':'prototype','guidance':guide})
(ASSETS/'clouds.js').write_text('window.IOT_CLOUDS = '+json.dumps(clouds,ensure_ascii=False,indent=2)+';\n',encoding='utf-8')
print(f'wrote {len(brands)} brands and {len(clouds)} cloud platforms')
