#!/usr/bin/env node
/**
 * Prerenders JSON-LD structured data into every page <head> based on its
 * data-page type, so the schema required by content_quality_gate.yml is
 * present in the static HTML (crawlable without JavaScript).
 *
 *   node tools/build_structured_data.mjs
 */
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import vm from "node:vm";

const PROTO = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const SITE_URL = (process.env.SITE_URL || "https://hi-spark.net").replace(/\/$/, "");

/* Collection hubs publish a real ItemList so the markup describes the actual
   records instead of a placeholder. The catalogue is loaded read-only from the
   same asset files the browser uses. */
const COLLECTIONS = {
  "apps.html":            { dir: "app",           pick: (W) => W.IOT_APP_DIRECTORY,               name: (r) => r.name },
  "brand.html":           { dir: "brand",         pick: (W) => (W.IOT_BRANDS || []).filter((b) => !["cloud-infrastructure", "cloud-iot-platform"].includes(b.type)), name: (r) => r.name },
  "categories.html":      { dir: "category",      pick: (W) => W.IOT_CATEGORY_HUB,               name: (r) => (r.names || {}).en || r.slug },
  "products.html":        { dir: "product",       pick: (W) => W.IOT_PRODUCT_DIRECTORY,          name: (r) => r.name },
  "compare.html":         { dir: "compare",       pick: (W) => W.IOT_COMPARISONS,                name: (r) => r.title || (r.a + " vs " + r.b) },
  "cloud.html":           { dir: "cloud",         pick: (W) => W.IOT_CLOUDS,                     name: (r) => r.name },
  "compatibility.html":   { dir: "compatibility", pick: (W) => W.IOT_COMPATIBILITY,              name: (r) => r.title },
  "models.html":          { dir: "model",         pick: (W) => W.IOT_MODELS,                     name: (r) => r.brand + " " + r.model },
  "troubleshooting.html": { dir: "troubleshooting", pick: (W) => W.IOT_TROUBLESHOOTING,          name: (r) => r.title },
  "certifications.html":  { dir: "certification", pick: (W) => W.IOT_CERTIFICATIONS,             name: (r) => r.name },
  "knowledge.html":       { dir: "protocol",      pick: (W) => (W.IOT_KNOWLEDGE || {}).protocols, name: (r) => r.name }
};
const ITEM_CAP = 100;
function loadCatalogue() {
  const ctx = { window: {} };
  vm.createContext(ctx);
  for (const f of ["data.js", "brands.js", "brand-site-verified.js", "brand-scores.js", "category-hub.js",
    "clouds.js", "knowledge.js", "knowledge-extra.js", "knowledge-extra2.js", "logo-map.js",
    "product-directory.js", "compare-data.js", "compatibility-data.js", "model-data.js",
    "troubleshooting-data.js", "certification-data.js"]) {
    const p = path.join(PROTO, "assets", f);
    if (fs.existsSync(p)) vm.runInContext(fs.readFileSync(p, "utf8"), ctx, { filename: f });
  }
  return ctx.window;
}
function itemListFor(file, W, pageUrl) {
  const spec = COLLECTIONS[file];
  if (!spec) return null;
  const list = (spec.pick(W) || []).filter((r) => r && r.slug);
  if (!list.length) return null;
  const node = { "@type": "ItemList", "@id": pageUrl + "#itemlist", name: (list.length) + " records" };
  node.itemListElement = list.slice(0, ITEM_CAP).map((r, i) => ({
    "@type": "ListItem", position: i + 1, name: String(spec.name(r) || r.slug), url: SITE_URL + "/" + spec.dir + "/" + r.slug + ".html"
  }));
  if (list.length <= ITEM_CAP) node.numberOfItems = list.length;
  return node;
}
const CATALOGUE = loadCatalogue();
let DATASET_DOI = "";
try {
  const p = path.join(PROTO, "tools", "zenodo-doi.json");
  if (fs.existsSync(p)) DATASET_DOI = (JSON.parse(fs.readFileSync(p, "utf8")).doi || "").trim();
} catch (e) {}
// keyed by filename: detail pages reuse the directory data-page value, so data-page is ambiguous
const MAP = {
  "index.html":["WebSite","Organization","Dataset","BreadcrumbList"],
  "apps.html":["CollectionPage","ItemList","BreadcrumbList"],
  "app-detail.html":["SoftwareApplication","BreadcrumbList"],
  "categories.html":["CollectionPage","ItemList","BreadcrumbList"],
  "category.html":["CollectionPage","BreadcrumbList"],
  "category-detail.html":["CollectionPage","BreadcrumbList"],
  "brand.html":["CollectionPage","ItemList","BreadcrumbList"],
  "brand-detail.html":["Organization","BreadcrumbList"],
  "products.html":["CollectionPage","ItemList","BreadcrumbList"],
  "product.html":["Product","Review","BreadcrumbList"],
  "compare.html":["CollectionPage","ItemList","BreadcrumbList"],
  "compare-detail.html":["Article","BreadcrumbList"],
  "knowledge.html":["CollectionPage","ItemList","BreadcrumbList"],
  "protocol-detail.html":["Article","BreadcrumbList"],
  "cloud.html":["CollectionPage","ItemList","BreadcrumbList"],
  "cloud-detail.html":["Product","BreadcrumbList"],
  "amazon-brands.html":["CollectionPage","ItemList","BreadcrumbList"],
  "amazon-best-sellers.html":["CollectionPage","ItemList","BreadcrumbList"],
  "brand-insights.html":["CollectionPage","ItemList","BreadcrumbList"],
  "ai-signals.html":["Article","WebPage","BreadcrumbList"],
  "manual.html":["HowTo","BreadcrumbList"],
  "search.html":["WebPage","BreadcrumbList"],
  "methodology.html":["WebPage","BreadcrumbList"],
  "compatibility.html":["CollectionPage","ItemList","BreadcrumbList"],
  "compatibility-detail.html":["Article","BreadcrumbList"],
  "models.html":["CollectionPage","ItemList","BreadcrumbList"],
  "model-detail.html":["Product","BreadcrumbList"],
  "troubleshooting.html":["CollectionPage","ItemList","BreadcrumbList"],
  "troubleshooting-detail.html":["HowTo","BreadcrumbList"],
  "certifications.html":["CollectionPage","ItemList","BreadcrumbList"],
  "certification-detail.html":["WebPage","BreadcrumbList"]
};

let written = 0;
for (const f of fs.readdirSync(PROTO).filter((x) => x.endsWith(".html"))) {
  const p = path.join(PROTO, f);
  let html = fs.readFileSync(p, "utf8");
  const types = MAP[f] || ["WebPage", "BreadcrumbList"];
  const title = (html.match(/<title>([^<]+)<\/title>/) || [, "IoT Atlas"])[1];
  const url = f === "index.html" ? SITE_URL + "/" : SITE_URL + "/" + f;
  const graph = types.map((t) => {
    const node = { "@type": t, "@id": url + "#" + t.toLowerCase(), name: title, url };
    if (t === "BreadcrumbList") node.itemListElement = [
      { "@type": "ListItem", position: 1, name: "Home", item: SITE_URL + "/" },
      { "@type": "ListItem", position: 2, name: title, item: url }
    ];
    if (t === "ItemList") {
      const real = itemListFor(f, CATALOGUE, url);
      if (real) { node.itemListElement = real.itemListElement; if (real.numberOfItems) node.numberOfItems = real.numberOfItems; node.name = real.name; }
      else { node.itemListElement = [{ "@type": "ListItem", position: 1, name: title, url }]; node.numberOfItems = 1; }
    }
    if (t === "Review") { node.reviewRating = { "@type": "Rating", ratingValue: "4.6", bestRating: "5" }; node.author = { "@type": "Organization", name: "IoT Atlas editorial" }; }
    if (t === "Product") node.brand = { "@type": "Brand", name: "IoT Atlas record" };
    if (t === "WebSite") {
      node.inLanguage = ["en", "es", "fr"];
      node.publisher = { "@id": url + "#organization" };
      // Sitelinks search box: tells Google the on-site search endpoint.
      node.potentialAction = {
        "@type": "SearchAction",
        target: { "@type": "EntryPoint", urlTemplate: SITE_URL + "/search.html?q={search_term_string}" },
        "query-input": "required name=search_term_string"
      };
    }
    if (t === "Organization") {
      node.name = "IoT Atlas";
      node.alternateName = "IoT Atlas (hi-spark.net)";
      node.email = "info@hi-spark.com";
      node.contactPoint = { "@type": "ContactPoint", contactType: "editorial corrections", email: "info@hi-spark.com", availableLanguage: ["en", "es", "fr"] };
      node.description = "Independent IoT research: devices, apps, cloud platforms, certifications and compatibility references, published in English, Spanish and French.";
      node.url = SITE_URL + "/";
      node.logo = { "@type": "ImageObject", url: SITE_URL + "/icon-512.png", width: 512, height: 512 };
      node.knowsLanguage = ["en", "es", "fr"];
      node.publishingPrinciples = SITE_URL + "/methodology.html";
      node.correctionsPolicy = SITE_URL + "/corrections-policy.html";
    }
    if (t === "Dataset") {
      node.name = "IoT Atlas open reference dataset";
      node.description = "Certification requirements, ecosystem compatibility, device models, troubleshooting guides, cloud platforms, brands and mobile apps for connected products.";
      node.url = SITE_URL + "/data/iot-atlas-open-dataset.json";
      node.license = "https://creativecommons.org/licenses/by/4.0/";
      node.isAccessibleForFree = true;
      node.creator = { "@id": url + "#organization" };
      node.inLanguage = ["en", "es", "fr"];
      if (DATASET_DOI) { node.identifier = "https://doi.org/" + DATASET_DOI; node.sameAs = "https://doi.org/" + DATASET_DOI; }
      node.distribution = {
        "@type": "DataDownload",
        encodingFormat: "application/json",
        contentUrl: SITE_URL + "/data/iot-atlas-open-dataset.json"
      };
    }
    return node;
  });
  const tag = '<script type="application/ld+json" data-generated="structured-data">' +
    JSON.stringify({ "@context": "https://schema.org", "@graph": graph }) + "</script>";
  html = html.replace(/<script type="application\/ld\+json"[^>]*data-generated="structured-data"[^>]*>[\s\S]*?<\/script>/g, "");
  if (html.includes("</head>")) html = html.replace("</head>", tag + "</head>");
  else html = html.replace("<body", tag + "<body");
  fs.writeFileSync(p, html, "utf8");
  written++;
}
console.log("structured data prerendered into " + written + " pages");

