#!/usr/bin/env node
/**
 * Generates the site icons from the same mark the header uses.
 *
 *   node tools/build_icons.mjs
 *
 * Writes favicon.ico (16/32/48), apple-touch-icon.png (180), icon-192.png and
 * icon-512.png for the manifest. No image libraries: the PNG encoder below is
 * zlib plus the PNG chunk format, so the icons rebuild anywhere Node runs.
 */
import fs from "node:fs";
import path from "node:path";
import zlib from "node:zlib";
import { fileURLToPath } from "node:url";

const PROTO = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");

// Brand palette, mirrored from assets/styles.css
const BRAND = [12, 116, 117];      // --brand #0c7475
const BRAND_DARK = [8, 79, 85];    // --brand-dark #084f55
const WHITE = [255, 255, 255];

const CRC = (() => { const t = new Int32Array(256); for (let n = 0; n < 256; n++) { let c = n; for (let k = 0; k < 8; k++) c = c & 1 ? 0xEDB88320 ^ (c >>> 1) : c >>> 1; t[n] = c; } return t; })();
const crc32 = (b) => { let c = -1; for (let i = 0; i < b.length; i++) c = CRC[(c ^ b[i]) & 0xFF] ^ (c >>> 8); return (c ^ -1) >>> 0; };
function chunk(type, data) {
  const len = Buffer.alloc(4); len.writeUInt32BE(data.length, 0);
  const td = Buffer.concat([Buffer.from(type, "ascii"), data]);
  const crc = Buffer.alloc(4); crc.writeUInt32BE(crc32(td), 0);
  return Buffer.concat([len, td, crc]);
}
function encodePNG(w, h, rgba) {
  const sig = Buffer.from([0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A]);
  const ihdr = Buffer.alloc(13);
  ihdr.writeUInt32BE(w, 0); ihdr.writeUInt32BE(h, 4);
  ihdr[8] = 8; ihdr[9] = 6; ihdr[10] = 0; ihdr[11] = 0; ihdr[12] = 0;
  const raw = Buffer.alloc((w * 4 + 1) * h);
  for (let y = 0; y < h; y++) {
    raw[y * (w * 4 + 1)] = 0;
    rgba.copy(raw, y * (w * 4 + 1) + 1, y * w * 4, (y + 1) * w * 4);
  }
  return Buffer.concat([sig, chunk("IHDR", ihdr), chunk("IDAT", zlib.deflateSync(raw, { level: 9 })), chunk("IEND", Buffer.alloc(0))]);
}

/** Draws the IoT Atlas mark: rounded square, signal rings, centre dot. */
function render(size, { transparent = false, radius = 0.22 } = {}) {
  const SS = 4, N = size * SS;
  const buf = Buffer.alloc(size * size * 4);
  const cx = N / 2, cy = N / 2;
  const rDot = N * 0.085, ring1 = N * 0.255, ring2 = N * 0.40, stroke = N * 0.058;
  const r = radius * N, half = N / 2;
  const inRounded = (x, y) => {
    const dx = Math.abs(x - half) - (half - r), dy = Math.abs(y - half) - (half - r);
    if (dx <= 0 || dy <= 0) return Math.max(dx, dy) <= 0 ? true : (dx > 0 && dy > 0 ? Math.hypot(dx, dy) <= r : true);
    return Math.hypot(Math.max(dx, 0), Math.max(dy, 0)) <= r;
  };
  const cover = (x, y) => {
    if (!transparent && !inRounded(x, y)) return null;
    const d = Math.hypot(x - cx, y - cy);
    if (d <= rDot) return WHITE;
    if (Math.abs(d - ring1) <= stroke / 2) return WHITE;
    if (Math.abs(d - ring2) <= stroke / 2) return WHITE;
    return transparent ? null : BRAND;
  };
  for (let y = 0; y < size; y++) {
    for (let x = 0; x < size; x++) {
      let rs = 0, gs = 0, bs = 0, as = 0;
      for (let sy = 0; sy < SS; sy++) for (let sx = 0; sx < SS; sx++) {
        const c = cover(x * SS + sx + 0.5, y * SS + sy + 0.5);
        if (c) { rs += c[0]; gs += c[1]; bs += c[2]; as += 255; }
      }
      const n = SS * SS, o = (y * size + x) * 4;
      const a = as / n;
      if (a > 0) { buf[o] = Math.round(rs / (as / 255)); buf[o + 1] = Math.round(gs / (as / 255)); buf[o + 2] = Math.round(bs / (as / 255)); buf[o + 3] = Math.round(a); }
    }
  }
  return encodePNG(size, size, buf);
}
function ico(entries) {
  const head = Buffer.alloc(6); head.writeUInt16LE(0, 0); head.writeUInt16LE(1, 2); head.writeUInt16LE(entries.length, 4);
  const dir = [], data = [];
  let off = 6 + entries.length * 16;
  for (const { size, png } of entries) {
    const e = Buffer.alloc(16);
    e[0] = size >= 256 ? 0 : size; e[1] = size >= 256 ? 0 : size;
    e[2] = 0; e[3] = 0; e.writeUInt16LE(1, 4); e.writeUInt16LE(32, 6);
    e.writeUInt32LE(png.length, 8); e.writeUInt32LE(off, 12);
    dir.push(e); data.push(png); off += png.length;
  }
  return Buffer.concat([head, ...dir, ...data]);
}

const ico4048 = ico([16, 32, 48].map((size) => ({ size, png: render(size) })));
fs.writeFileSync(path.join(PROTO, "favicon.ico"), ico4048);
fs.writeFileSync(path.join(PROTO, "favicon-32.png"), render(32));
fs.writeFileSync(path.join(PROTO, "apple-touch-icon.png"), render(180, { radius: 0 }));
fs.writeFileSync(path.join(PROTO, "icon-192.png"), render(192));
fs.writeFileSync(path.join(PROTO, "icon-512.png"), render(512));

const manifest = {
  name: "IoT Atlas - independent IoT research",
  short_name: "IoT Atlas",
  description: "Devices, apps, clouds, certifications and compatibility references for connected products, in English, Spanish and French.",
  start_url: "/",
  scope: "/",
  display: "standalone",
  background_color: "#f4f7f9",
  theme_color: "#0c7475",
  lang: "en",
  dir: "ltr",
  icons: [
    { src: "/icon-192.png", sizes: "192x192", type: "image/png", purpose: "any" },
    { src: "/icon-512.png", sizes: "512x512", type: "image/png", purpose: "any" },
    { src: "/icon-512.png", sizes: "512x512", type: "image/png", purpose: "maskable" }
  ]
};
fs.writeFileSync(path.join(PROTO, "manifest.webmanifest"), JSON.stringify(manifest, null, 2) + "\n");
console.log("icons written: favicon.ico (" + ico4048.length + "B), apple-touch-icon.png, icon-192.png, icon-512.png, manifest.webmanifest");
