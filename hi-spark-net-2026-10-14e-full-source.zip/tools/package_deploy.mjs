#!/usr/bin/env node
/**
 * Builds the deployable archive (outputs/iot-atlas-deploy-v1.zip).
 *
 * Included: every published page, asset, tool, schema and content template.
 * Excluded: local screenshot previews (preview-*.png at the repo root) and any
 * transient render artifacts, so the archive stays small for hosting uploads.
 *
 * Usage: node tools/package_deploy.mjs
 */
import fs from "node:fs";
import path from "node:path";
import { execFileSync } from "node:child_process";
import { fileURLToPath } from "node:url";

const PROTO = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const OUT = path.resolve(PROTO, "..");
const STAGE = path.join(OUT, "_deploy_stage");
const ZIP = path.join(OUT, "iot-atlas-deploy-v1.zip");
const SKIP_DIRS = new Set(["node_modules", ".git", ".edge-profile", "_deploy_stage"]);
const SKIP_FILE = /^preview-.*\.(png|jpe?g|webp)$/i;
const SKIP_FILE2 = /^\.render/;

fs.rmSync(STAGE, { recursive: true, force: true });
fs.mkdirSync(STAGE, { recursive: true });

let copied = 0, skipped = 0;
const walk = (abs, rel) => {
  for (const e of fs.readdirSync(abs, { withFileTypes: true })) {
    const src = path.join(abs, e.name);
    const outRel = rel ? rel + "/" + e.name : e.name;
    if (e.isDirectory()) {
      if (SKIP_DIRS.has(e.name)) { skipped++; continue; }
      fs.mkdirSync(path.join(STAGE, outRel), { recursive: true });
      walk(src, outRel);
    } else {
      if (SKIP_FILE.test(e.name) || SKIP_FILE2.test(e.name)) { skipped++; continue; }
      fs.mkdirSync(path.dirname(path.join(STAGE, outRel)), { recursive: true });
      fs.copyFileSync(src, path.join(STAGE, outRel));
      copied++;
    }
  }
};
walk(PROTO, "");

fs.rmSync(ZIP, { force: true });
// Pass the top-level entries explicitly so tar records clean paths (no leading "./").
const tops = fs.readdirSync(STAGE);
execFileSync("tar", ["-a", "-c", "-f", ZIP, "-C", STAGE, ...tops], { stdio: "inherit" });
fs.rmSync(STAGE, { recursive: true, force: true });

const size = fs.statSync(ZIP).size;
console.log(`packaged ${copied} files (${skipped} skipped) -> ${ZIP}`);
console.log(`archive size: ${(size / 1024).toFixed(0)} KB`);
