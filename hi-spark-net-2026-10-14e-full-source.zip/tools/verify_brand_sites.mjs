#!/usr/bin/env node
/**
 * Brand official-site verification.
 *
 *   node tools/verify_brand_sites.mjs              # all brands, resumable
 *   node tools/verify_brand_sites.mjs --limit 40
 *
 * For every brand it fetches the recorded official URL and records:
 *   - HTTP status and final URL (redirects are flagged)
 *   - whether the page actually mentions the brand name
 * Writes content-templates/brand-site-verification.csv, saving every 25 rows.
 */
import fs from "node:fs";
import path from "node:path";
import vm from "node:vm";
import { fileURLToPath } from "node:url";

const PROTO = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const OUT = path.join(PROTO, "content-templates", "brand-site-verification.csv");
const ctx = { window: {} }; vm.createContext(ctx);
vm.runInContext(fs.readFileSync(path.join(PROTO, "assets/brands.js"), "utf8"), ctx);
let brands = ctx.window.IOT_BRANDS || [];
const urlOf = (b) => b.official_url || b.url || "";

const arg = (k, d) => { const i = process.argv.indexOf(k); return i > -1 ? process.argv[i + 1] : d; };
const LIMIT = Number(arg("--limit", "0")) || 0;

const HEAD = ["brand","recorded_url","http_status","final_url","redirected","brand_mentioned_in_page","page_title","verdict","checked_at","note"];
const cell = (v) => { const s = v == null ? "" : String(v); return /[",\r\n]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s; };
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const norm = (s) => String(s || "").toLowerCase().replace(/[^a-z0-9]/g, "");

const done = new Map();
if (fs.existsSync(OUT)) {
  const ls = fs.readFileSync(OUT, "utf8").trim().split(/\r?\n/);
  for (const l of ls.slice(1)) { const m = l.match(/^("(?:[^"]|"")*"|[^,]*),/); if (m) done.set(m[1].replace(/^"|"$/g, "").replace(/""/g, '"').toLowerCase(), l); }
}
const rows = [...done.values()];
const seen = new Set(done.keys());
const todo = brands.filter((b) => urlOf(b) && !seen.has(b.name.toLowerCase()));
const run = LIMIT ? todo.slice(0, LIMIT) : todo;
const save = () => fs.writeFileSync(OUT, [HEAD.join(",")].concat(rows).join("\r\n") + "\r\n", "utf8");

async function check(brand, url) {
  const started = Date.now();
  try {
    const ctl = new AbortController(); const t = setTimeout(() => ctl.abort(), 12000);
    const res = await fetch(url, { redirect: "follow", signal: ctl.signal, headers: { "user-agent": "Mozilla/5.0 (compatible; iot-atlas-verify/1.0)" } });
    clearTimeout(t);
    const final = res.url || url;
    const html = res.ok ? (await res.text()).slice(0, 300000) : "";
    const title = (html.match(/<title[^>]*>([^<]{0,140})/i) || [, ""])[1].replace(/\s+/g, " ").trim();
    const words = (brand.name || "").split(/\s+/).filter((w) => w.length > 3);
    const hay = norm(html.slice(0, 200000));
    const mentioned = words.length
      ? words.some((w) => hay.includes(norm(w)))
      : hay.includes(norm(brand.name));
    const redirected = norm(final) !== norm(url);
    let verdict = "ok";
    if (!res.ok) verdict = "unreachable";
    else if (redirected) verdict = "redirected";
    else if (!mentioned) verdict = "check-name";
    return { status: res.status, final, redirected: redirected ? "yes" : "no", mentioned: mentioned ? "yes" : "no", title, verdict,
             note: (!res.ok ? "http " + res.status : "") + (Date.now() - started > 9000 ? " slow" : "") };
  } catch (e) {
    return { status: "", final: "", redirected: "", mentioned: "", title: "", verdict: "error", note: e.name === "AbortError" ? "timeout 12s" : e.message.slice(0, 60) };
  }
}

console.log(`brands ${brands.length} | already checked ${done.size} | to check ${run.length}`);
for (let i = 0; i < run.length; i++) {
  const b = run[i]; const url = urlOf(b);
  const r = await check(b, url);
  rows.push([b.name, url, r.status, r.final, r.redirected, r.mentioned, r.title, r.verdict,
    new Date().toISOString().slice(0, 10), r.note].map(cell).join(","));
  if ((i + 1) % 25 === 0 || i === run.length - 1) { save(); console.log(`  ${i + 1}/${run.length} (saved)`); }
  await sleep(500);
}
save();
const all = rows.map((l) => l.split(","));
console.log("\nwritten: content-templates/brand-site-verification.csv");
