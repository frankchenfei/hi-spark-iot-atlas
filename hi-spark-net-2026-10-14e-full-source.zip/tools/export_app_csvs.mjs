import fs from "node:fs";
import path from "node:path";
import vm from "node:vm";
import { fileURLToPath } from "node:url";
import { APP_FILES } from "./app-batches.mjs";

const here = path.dirname(fileURLToPath(import.meta.url));
const proto = path.resolve(here, "..");
const assets = path.join(proto, "assets");
const outDir = path.join(proto, "content-templates");

// Load order matters: later files append to earlier ones.
const ORDER = APP_FILES;

const ctx = { window: {} };
vm.createContext(ctx);
for (const file of ORDER) {
  const p = path.join(assets, file);
  if (!fs.existsSync(p)) continue;
  vm.runInContext(fs.readFileSync(p, "utf8"), ctx, { filename: file });
}
const apps = ctx.window.IOT_APP_DIRECTORY || [];

const CATEGORY_DEFAULT = "Smart Home";
const normalized = apps.map((a) => ({ ...a, category: a.category || CATEGORY_DEFAULT }));

function csvCell(value) {
  const s = value === undefined || value === null ? "" : String(value);
  return /[",\r\n]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s;
}
function toCsv(header, rows, pick) {
  const lines = [header.join(",")];
  for (const row of rows) lines.push(header.map((h) => csvCell(pick(row)[h])).join(","));
  return lines.join("\r\n") + "\r\n";
}

const totals = {};
for (const a of normalized) totals[a.category] = (totals[a.category] || 0) + 1;

const combinedHeader = ["slug","name","brand","developer","category","segment","platforms","protocols","summary","google_play_url","ios_url","ios_verified","verified_at","source","status"];
fs.writeFileSync(path.join(outDir, "app-download-links.csv"),
  toCsv(combinedHeader, normalized, (a) => ({
    slug: a.slug, name: a.name, brand: a.brand, category: a.category, segment: a.segment || "",
    platforms: a.platforms, protocols: a.protocols, summary: a.summary,
    google_play_url: a.android_url, ios_url: a.ios_url, ios_verified: a.ios_verified===true?"yes":(a.ios_verified===false?"no":""), verified_at: a.verified_at || "", developer: a.developer || "", source: a.source, status: a.status
  })), "utf8");

const byCategoryFile = [
  { file: "camera-apps.csv", categories: ["Security", "Cameras & Drones"], header: ["slug","name","brand","category","protocols","summary","google_play_url","ios_url","source","status"] },
  { file: "wearable-apps.csv", categories: ["Wearables"], header: ["slug","name","brand","segment","protocols","summary","google_play_url","ios_url"] },
  { file: "health-apps.csv", categories: ["Health", "Health & Home"], header: ["slug","name","brand","segment","protocols","summary","google_play_url","ios_url"] },
];
for (const spec of byCategoryFile) {
  const rows = normalized.filter((a) => spec.categories.includes(a.category));
  fs.writeFileSync(path.join(outDir, spec.file),
    toCsv(spec.header, rows, (a) => ({
      slug: a.slug, name: a.name, brand: a.brand, category: a.category, segment: a.segment || "",
      protocols: a.protocols, summary: a.summary,
      google_play_url: a.android_url, ios_url: a.ios_url, source: a.source, status: a.status
    })), "utf8");
  console.log(spec.file.padEnd(24), rows.length);
}
console.log("app-download-links.csv".padEnd(24), normalized.length);
console.log("--- category totals ---");
for (const k of Object.keys(totals).sort()) console.log("  " + k.padEnd(22), totals[k]);
