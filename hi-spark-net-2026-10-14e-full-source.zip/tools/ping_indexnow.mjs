#!/usr/bin/env node
/**
 * Submits the site URLs to the IndexNow API (Bing, Yandex, Naver, Seznam).
 *
 *   node tools/ping_indexnow.mjs                 # everything in both sitemaps
 *   node tools/ping_indexnow.mjs --limit 200     # only the first 200 URLs
 *   node tools/ping_indexnow.mjs <url> <url>     # specific URLs
 *
 * The key file <key>.txt must already be deployed at the site root: IndexNow
 * fetches it to prove ownership before it accepts the submission.
 */
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const PROTO = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const HOST = process.env.INDEXNOW_HOST || "hi-spark.net";
const SITE = "https://" + HOST;
const key = JSON.parse(fs.readFileSync(path.join(PROTO, "tools", "indexnow-key.json"), "utf8")).key;

const args = process.argv.slice(2);
const limitFlag = args.indexOf("--limit");
const limit = limitFlag > -1 ? Number(args[limitFlag + 1]) : 0;
let urls = args.filter((a) => /^https?:\/\//.test(a));

if (!urls.length) {
  for (const f of ["sitemap.xml", "sitemap-entities.xml"]) {
    const p = path.join(PROTO, f);
    if (!fs.existsSync(p)) continue;
    urls = urls.concat([...fs.readFileSync(p, "utf8").matchAll(/<loc>([^<]+)<\/loc>/g)].map((m) => m[1].trim()));
  }
}
urls = [...new Set(urls)];
if (limit) urls = urls.slice(0, limit);
if (!urls.length) { console.error("no URLs found"); process.exit(1); }

const keyLocation = SITE + "/" + key + ".txt";
console.log("IndexNow: " + urls.length + " URLs, key " + key + ", keyLocation " + keyLocation);

const res = await fetch("https://api.indexnow.org/indexnow", {
  method: "POST",
  headers: { "Content-Type": "application/json; charset=utf-8" },
  body: JSON.stringify({ host: HOST, key, keyLocation, urlList: urls })
});
console.log("HTTP " + res.status + " " + res.statusText + (res.status === 200 ? " - accepted" : " - see https://www.indexnow.org/documentation"));
if (res.status >= 400) {
  const body = await res.text().catch(() => "");
  if (body) console.log(body.slice(0, 400));
  process.exit(1);
}
