#!/usr/bin/env node
/**
 * App store verification (Apple App Store).
 *
 *   node tools/verify_app_stores.mjs                 # verify all, resumable
 *   node tools/verify_app_stores.mjs --limit 50      # first 50 unchecked
 *   node tools/verify_app_stores.mjs --android       # also attempt Google Play
 *
 * Writes content-templates/app-store-verification.csv and saves progress every
 * 25 apps, so a long run can be resumed simply by running it again.
 *
 * ENVIRONMENT NOTE (verified 2026-10-08)
 *   The build sandbox cannot reach any Google property: play.google.com,
 *   googleapis.com and firebase.google.com all time out, and Bing search
 *   returns no extractable Play links. Apple's API is reachable and was used
 *   for the 642 verified records. Google Play must be checked from a network
 *   that can reach it, then re-run with --android.
 */
import fs from "node:fs";
import path from "node:path";
import vm from "node:vm";
import { fileURLToPath } from "node:url";
import { APP_LOAD_ORDER } from "./app-batches.mjs";

const PROTO = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const ASSETS = path.join(PROTO, "assets");
const OUT = path.join(PROTO, "content-templates", "app-store-verification.csv");

const ORDER = APP_LOAD_ORDER;
const ctx = { window: {} }; vm.createContext(ctx);
for (const f of ORDER) { const p = path.join(ASSETS, f); if (fs.existsSync(p)) vm.runInContext(fs.readFileSync(p, "utf8"), ctx, { filename: f }); }
let apps = ctx.window.IOT_APP_DIRECTORY || [];

const arg = (k, d) => { const i = process.argv.indexOf(k); return i > -1 ? process.argv[i + 1] : d; };
const LIMIT = Number(arg("--limit", "0")) || 0;
const DO_ANDROID = process.argv.includes("--android");

const HEAD = ["app","brand","verified_ios","ios_url","ios_developer","ios_price","verified_android","android_url","android_developer","checked_at","note"];
const cell = (v) => { const s = v == null ? "" : String(v); return /[",\r\n]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s; };

// resume
const done = new Map();
if (fs.existsSync(OUT)) {
  const lines = fs.readFileSync(OUT, "utf8").trim().split(/\r?\n/);
  for (const l of lines.slice(1)) {
    const m = l.match(/^("(?:[^"]|"")*"|[^,]*),/);
    if (m) { const name = m[1].replace(/^"|"$/g, "").replace(/""/g, '"'); done.set(name.toLowerCase(), l); }
  }
}
const rows = [...done.values()];
const seen = new Set(done.keys());
const todo = apps.filter((a) => !seen.has(a.name.toLowerCase()));
const run = LIMIT ? todo.slice(0, LIMIT) : todo;

function save() { fs.writeFileSync(OUT, [HEAD.join(",")].concat(rows).join("\r\n") + "\r\n", "utf8"); }
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const norm = (s) => String(s || "").toLowerCase().replace(/[^a-z0-9]/g, "");

async function ios(name, brand, attempt = 0) {
  const term = encodeURIComponent(name);
  const url = `https://itunes.apple.com/search?term=${term}&entity=software&limit=8&country=us`;
  try {
    const res = await fetch(url, { headers: { "user-agent": "iot-atlas-verifier/2.0" } });
    if (res.status === 403 || res.status === 429) {
      if (attempt >= 4) return { ok: false, note: "rate limited (gave up)" };
      const wait = 6000 * Math.pow(2, attempt);
      process.stdout.write(`\n  rate limited, waiting ${wait / 1000}s... `);
      await sleep(wait);
      return ios(name, brand, attempt + 1);
    }
    if (!res.ok) return { ok: false, note: "http " + res.status };
    const j = await res.json();
    const target = norm(name);
    const b = norm(brand);
    let best = null, bestScore = 0;
    for (const r of j.results || []) {
      const t = norm(r.trackName);
      if (t === target) { best = r; bestScore = 3; break; }
      const contains = t.includes(target) || target.includes(t);
      const brandHit = b && (norm(r.sellerName).includes(b) || t.includes(b));
      const score = (contains ? 2 : 0) + (brandHit ? 1 : 0);
      if (score > bestScore) { bestScore = score; best = r; }
    }
    if (!best || bestScore === 0) return { ok: false, note: "no match on App Store" };
    return { ok: true, url: best.trackViewUrl, dev: best.sellerName || "", price: best.formattedPrice || "",
             match: bestScore === 3 ? "exact" : bestScore >= 2 ? "name" : "brand" };
  } catch (e) { return { ok: false, note: "ios error: " + e.message }; }
}

console.log(`total ${apps.length} | already verified ${done.size} | to check ${run.length}`);
let both = 0, one = 0, none = 0;
for (let i = 0; i < run.length; i++) {
  const a = run[i];
  const io = await ios(a.name, a.brand);
  let an = { ok: false, note: DO_ANDROID ? "" : "android not attempted" };
  if (io.ok) one++; else none++;
  if (!io.ok && !DO_ANDROID) { /* counted below */ }
  rows.push([a.name, a.brand || "", io.ok ? "yes" : "no", io.url || "", io.dev || "", io.price || "",
    an.ok ? "yes" : "no", an.url || "", an.dev || "", new Date().toISOString().slice(0, 10),
    [io.note, io.match ? "match:" + io.match : ""].filter(Boolean).join("; ")].map(cell).join(","));
  if ((i + 1) % 25 === 0 || i === run.length - 1) {
    save();
    console.log(`  ${i + 1}/${run.length}  found=${rows.filter(r => r.includes(",yes,")).length}  (saved)`);
  }
  await sleep(700);
}
save();
const found = rows.filter(r => /,(yes|no),/.test(r) && r.split(",").includes("yes")).length;
console.log(`\ndone. verified on App Store: ${rows.filter(r=>r.split(",")[2]==="yes").length} / ${rows.length}`);
console.log("written: content-templates/app-store-verification.csv");
