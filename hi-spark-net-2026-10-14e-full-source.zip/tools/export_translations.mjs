#!/usr/bin/env node
/**
 * Exports the highest-value catalogue strings for translation.
 *
 * The site ships UI chrome in EN/ES/FR but the catalogue prose is English only.
 * Rather than block the launch on 1,611 strings, this tool produces a worklist
 * for a staged rollout:
 *
 *   brands: top 100 by editorial priority (P0, then P1, then breadth)
 *   apps:   top 200, ranked by their brand priority and verification status
 *
 * Output: content-templates/translation-worklist.csv
 * The CSV is the hand-off artifact for a translation vendor, and the input to
 * tools/build_content_i18n.mjs which compiles assets/content-i18n.js.
 *
 * Usage: node tools/export_translations.mjs [--brands 100] [--apps 200]
 */
import fs from "node:fs";
import path from "node:path";
import vm from "node:vm";
import { fileURLToPath } from "node:url";
import * as BATCHES from "./app-batches.mjs";

const PROTO = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const ASSETS = path.join(PROTO, "assets");
const OUT = path.join(PROTO, "content-templates", "translation-worklist.csv");

const CATALOG = ["brands.js","brand-site-verified.js","brand-scores.js","category-hub.js","clouds.js","knowledge.js","knowledge-extra.js","knowledge-extra2.js","compare-data.js","product-directory.js"];

const ctx = { window: {} };
vm.createContext(ctx);
for (const f of CATALOG.concat(BATCHES.APP_FILES)) {
  const p = path.join(ASSETS, f);
  if (fs.existsSync(p)) vm.runInContext(fs.readFileSync(p, "utf8"), ctx, { filename: f });
}
const w = ctx.window;
const brands = w.IOT_BRANDS || [];
const apps = w.IOT_APP_DIRECTORY || [];

const arg = (k, d) => { const i = process.argv.indexOf(k); return i > -1 ? Number(process.argv[i + 1]) : d; };
// The catalogue is fully translated, so export everything by default.
// Override with --brands / --apps for a partial batch.
const N_BRANDS = arg("--brands", 9999);
const N_APPS = arg("--apps", 9999);

const PRI = { P0: 0, P1: 1, P2: 2 };
const brandRank = (b) => [
  PRI[b.priority] === undefined ? 3 : PRI[b.priority],
  -(b.categories || []).length,
  b.name
];
const byName = (a, b) => String(a).localeCompare(String(b));

const rankedBrands = brands.slice().sort((a, b) => {
  const x = brandRank(a), y = brandRank(b);
  for (let i = 0; i < x.length; i++) {
    if (x[i] < y[i]) return -1;
    if (x[i] > y[i]) return 1;
  }
  return 0;
});
const topBrands = rankedBrands.slice(0, N_BRANDS);
const brandPriority = {};
topBrands.forEach((b, i) => { brandPriority[b.slug] = i; });

// Apps follow their brand's editorial priority; verified store records break ties.
const CAT_WEIGHT = { "Security": 0, "Smart Home": 1, "Lighting": 2, "Wearables": 3, "Health": 4, "Dash Cams": 5, "Audio & Headphones": 6 };
const appRank = (a) => {
  const bp = brandPriority[String(a.brand || "").toLowerCase().replace(/[^a-z0-9]/g, "")];
  const byBrandSlug = brands.findIndex(b => (b.name || "").toLowerCase() === String(a.brand || "").toLowerCase());
  return [
    byBrandSlug > -1 && topBrands.some(b => b.slug === brands[byBrandSlug].slug) ? 0 : 1,
    byBrandSlug > -1 ? byBrandSlug : 999,
    CAT_WEIGHT[a.category] === undefined ? 9 : CAT_WEIGHT[a.category],
    a.ios_verified === true ? 0 : 1,
    a.name
  ];
};
const rankedApps = apps.slice().sort((a, b) => {
  const x = appRank(a), y = appRank(b);
  for (let i = 0; i < x.length; i++) { if (x[i] < y[i]) return -1; if (x[i] > y[i]) return 1; }
  return 0;
});

/* Stratified pick: a purely global ranking starved whole categories (dash cams
   ended up with zero translated apps). Reserve a floor per category, then fill
   the rest from the global order. */
const QUOTA = Number(arg("--quota", 4));
const picked = new Set();
const topApps = [];
const byCat = {};
for (const a of rankedApps) (byCat[a.category] = byCat[a.category] || []).push(a);
for (const cat of Object.keys(byCat)) {
  for (const a of byCat[cat].slice(0, QUOTA)) {
    if (topApps.length >= N_APPS) break;
    if (!picked.has(a.slug)) { picked.add(a.slug); topApps.push(a); }
  }
}
for (const a of rankedApps) {
  if (topApps.length >= N_APPS) break;
  if (!picked.has(a.slug)) { picked.add(a.slug); topApps.push(a); }
}
topApps.sort((a, b) => {
  const x = appRank(a), y = appRank(b);
  for (let i = 0; i < x.length; i++) { if (x[i] < y[i]) return -1; if (x[i] > y[i]) return 1; }
  return 0;
});

/* Cloud platforms, knowledge records and comparisons are also catalogue prose and
   were previously left in English. Export them alongside brands and apps. */
const CLOUDS = w.IOT_CLOUDS || [];
const K = w.IOT_KNOWLEDGE || {};
const COMPS = w.IOT_COMPARISONS || [];

const cell = (v) => { const s = v == null ? "" : String(v); return /[",\r\n]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s; };
const rows = [];
const HEAD = ["kind","slug","name","field","en","es","fr","status"];
for (const b of topBrands) {
  if (!b.notes || !String(b.notes).trim()) continue;
  rows.push(["brand", b.slug, b.name, "notes", b.notes, "", "", "todo"]);
}
for (const a of topApps) {
  if (!a.summary || !String(a.summary).trim()) continue;
  rows.push(["app", a.slug, a.name, "summary", a.summary, "", "", "todo"]);
}
for (const c of CLOUDS) {
  if (c.notes && String(c.notes).trim()) rows.push(["cloud", c.slug, c.name, "notes", c.notes, "", "", "todo"]);
}
for (const x of (K.protocols || [])) rows.push(["protocol", x.slug, x.name, "summary", x.summary, "", "", "todo"]);
for (const x of (K.standards || [])) rows.push(["standard", x.slug, x.name, "summary", x.summary, "", "", "todo"]);
for (const x of (K.concepts || [])) rows.push(["concept", x.slug, x.name, "summary", x.summary, "", "", "todo"]);
for (const x of COMPS) rows.push(["compare", x.slug, x.title, "summary", x.summary, "", "", "todo"]);
fs.writeFileSync(OUT, [HEAD.join(",")].concat(rows.map(r => r.map(cell).join(","))).join("\r\n") + "\r\n", "utf8");

console.log("brands ranked: " + brands.length + " -> exported " + topBrands.length);
console.log("apps ranked:   " + apps.length + " -> exported " + topApps.length);
console.log("worklist rows: " + rows.length + " -> " + path.relative(PROTO, OUT));
const p0 = topBrands.filter(b => b.priority === "P0").length;
console.log("brand mix: P0 " + p0 + ", P1 " + topBrands.filter(b => b.priority === "P1").length + ", P2 " + topBrands.filter(b => b.priority === "P2").length);
