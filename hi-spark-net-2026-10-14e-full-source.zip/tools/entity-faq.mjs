/**
 * FAQ generation for catalogue entity pages (apps, brands, protocols,
 * comparisons, clouds, categories, products).
 *
 * Every question is answered from a field that already exists on the record - no
 * invented claims. The result is published twice: as a visible Q&A block and as
 * FAQPage structured data, because answer engines cite question/answer pairs.
 *
 * tools/prerender_entities.mjs calls this for each entity, so the text is in the
 * static HTML and does not depend on JavaScript.
 */
const clean = (v) => String(v == null ? "" : v).replace(/<[^>]+>/g, " ").replace(/\s+/g, " ").trim();
const arr = (v) => (Array.isArray(v) ? v.filter((x) => clean(x)) : (clean(v) ? [clean(v)] : []));
const cap = (s) => String(s).charAt(0).toUpperCase() + String(s).slice(1);

export function entityFaqs(type, rec, W, ctx) {
  const out = [];
  const push = (q, a) => { const qq = clean(q), aa = clean(a); if (qq && aa && aa.length >= 3) out.push({ q: qq, a: aa }); };
  const site = (ctx && ctx.site) || "https://hi-spark.net";
  if (type === "app") {
    push("What is the " + rec.name + " app used for?", rec.summary);
    push("Which brand publishes " + rec.name + "?", rec.brand ? rec.brand + (rec.developer ? " (developer: " + rec.developer + ")" : "") + "." : "");
    push("Which protocols does " + rec.name + " support?", rec.protocols ? arr(rec.protocols).join(", ") + "." : "");
    push("Which platforms can run " + rec.name + "?", rec.platforms ? arr(rec.platforms).join(", ") + "." : "");
    const dl = [rec.android_label ? "Google Play" : (rec.android_url ? "Google Play" : ""), rec.ios_url ? "the App Store" : ""].filter(Boolean).join(" and ");
    if (dl) push("Where can I download " + rec.name + "?", "The official listing is available on " + dl + "; links are on this page. Verify you are installing the app published by " + (rec.brand || rec.developer || "the manufacturer") + ".");
    if (rec.ios_verified === true && rec.verified_at) push("Is the " + rec.name + " listing verified?", "Yes. The store listing was checked on " + rec.verified_at + ".");
  } else if (type === "brand") {
    push("What does " + rec.name + " make?", arr(rec.categories).length ? rec.name + " covers: " + arr(rec.categories).join(", ") + "." : (rec.notes || ""));
    push("Which app does " + rec.name + " use?", rec.app ? rec.app + "." : "");
    push("Which protocols does " + rec.name + " use?", arr(rec.protocols).join(", ") + ".");
    push("Where is " + rec.name + " based?", rec.hq ? "Headquarters or primary market: " + rec.hq + "." : "");
    push("What is the official " + rec.name + " website?", rec.url ? rec.url : "");
  } else if (type === "protocol") {
    push("What is " + rec.name + "?", rec.summary);
    push("What range does " + rec.name + " cover?", rec.range ? "Typical range: " + rec.range + "." : "");
    push("How much power does " + rec.name + " use?", rec.power ? "Power profile: " + rec.power + "." : "");
    push("What network topology does " + rec.name + " use?", rec.topology ? rec.topology + "." : "");
    push("What is " + rec.name + " used for?", rec.use ? rec.use + "." : "");
    push("Where can I read the official " + rec.name + " specification?", rec.source || "");
  } else if (type === "compare") {
    push("Which is better, " + rec.a + " or " + rec.b + "?", rec.verdict);
    push("What is the short summary of " + rec.title + "?", rec.summary);
    const bf = rec.bestFor || {};
    const keys = Object.keys(bf).filter((k) => clean(bf[k]));
    if (keys.length) push("Who should choose each option?", keys.map((k) => cap(k) + ": " + clean(bf[k])).join(" "));
    const s = [];
    if (typeof rec.scoreA === "number") s.push(rec.a + " scores " + rec.scoreA);
    if (typeof rec.scoreB === "number") s.push(rec.b + " scores " + rec.scoreB);
    if (typeof rec.winsA === "number") s.push(rec.a + " wins " + rec.winsA + " criteria, " + rec.b + " wins " + rec.winsB + ", " + rec.ties + " tie");
    if (s.length) push("How do the editorial scores compare?", s.join("; ") + ". Scores are editorial estimates, not a rating or a valuation.");
  } else if (type === "cloud") {
    push("What is " + rec.name + "?", [rec.notes, rec.type ? "Platform type: " + rec.type + "." : ""].filter(Boolean).join(" "));
    push("Which regions does " + rec.name + " cover?", rec.regions ? rec.regions + "." : "");
    push("Which protocols does " + rec.name + " support?", arr(rec.protocols).join(", ") + ".");
    push("How is " + rec.name + " priced?", rec.price ? rec.price + "." : "");
    push("Where is the official " + rec.name + " documentation?", rec.docs || "");
  } else if (type === "category") {
    const names = rec.names || {};
    const en = clean(names.en || rec.slug);
    push("What is included in the " + en + " category?", clean((rec.descriptions || {}).en || ""));
    if (arr(rec.brands).length || arr(rec.apps).length) push("How many brands and apps are catalogued in " + en + "?", arr(rec.brands).length + " brand entries and " + arr(rec.apps).length + " app entries on IoT Atlas.");
    push("Which protocols matter most in " + en + "?", arr(rec.protocols).join(", ") + ".");
  } else if (type === "model") {
    const nm = rec.brand + " " + rec.model;
    push("What is the " + nm + "?", rec.summary);
    push("Which app does the " + nm + " use?", rec.app || "");
    push("Which protocols does the " + nm + " support?", arr(rec.protocols).join(", ") + ".");
    push("How is the " + nm + " powered?", rec.power || "");
    push("Where is the official " + nm + " manual?", rec.manualUrl || rec.supportUrl || "");
    push("Is the " + nm + " still on sale?", rec.status || "");
  } else if (type === "compatibility") {
    push("Does " + rec.subject + " work with " + rec.target + "?", (rec.verdict ? rec.verdict + ". " : "") + (rec.summary || ""));
    push("What is needed for " + rec.subject + " and " + rec.target + " to work together?", arr(rec.requirements).join("; ") + ".");
    push("What are the limitations?", arr(rec.limitations).join("; ") + ".");
    push("How is it set up?", arr(rec.steps).join("; "));
  } else if (type === "certification") {
    push("What is " + rec.name + "?", rec.summary);
    push("What does " + rec.name + " mean for a product?", rec.meaning);
    push("Which products does " + rec.name + " apply to?", arr(rec.appliesTo).join("; ") + ".");
    push("What does " + (rec.code || rec.name) + " not cover?", arr(rec.doesNotCover).join("; ") + ".");
    push("What is needed to comply with " + rec.name + "?", arr(rec.checklist).join("; ") + ".");
  } else if (type === "troubleshooting") {
    push("Why does this happen: " + rec.title + "?", rec.symptom);
    push("What is the most likely cause?", arr(rec.likelyCauses).slice(0, 3).join("; ") + ".");
    push("What should I check first?", arr(rec.quickChecks).join("; ") + ".");
    push("How is it fixed?", arr(rec.steps).join("; "));
    push("When should the case be escalated?", rec.escalation);
  }
  // keep the block useful, not noisy
  const seen = new Set();
  return out.filter((f) => { const k = f.q.toLowerCase(); if (seen.has(k)) return false; seen.add(k); return true; }).slice(0, 6);
}

export function faqNode(faqs) {
  if (!faqs || !faqs.length) return null;
  return {
    "@type": "FAQPage",
    mainEntity: faqs.map((f) => ({ "@type": "Question", name: f.q, acceptedAnswer: { "@type": "Answer", text: f.a } }))
  };
}

export function faqI18nScript(localized) {
  const pairs = {};
  for (const lang of ["es", "fr"]) {
    const list = (localized && localized[lang]) || [];
    if (list.length) pairs[lang] = list.map((p) => [clean(p[0]), clean(p[1])]);
  }
  if (!Object.keys(pairs).length) return "";
  return '<script type="application/json" data-faq-i18n>' + JSON.stringify(pairs) + "<\/script>";
}

export function faqMarkup(faqs, heading) {
  if (!faqs || !faqs.length) return "";
  const esc = (v) => String(v == null ? "" : v).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
  return '<section class="section compact" id="entity-faq"><div class="container">' +
    '<h2 class="group-heading">' + esc(heading || "Frequently asked questions") + "</h2>" +
    '<div class="faq-list">' +
    faqs.map((f) => '<details class="faq-item" open><summary>' + esc(f.q) + "</summary><p>" + esc(f.a) + "</p></details>").join("") +
    "</div></div></section>";
}

/* ---------------------------------------------------------------------------
 * Localised question/answer text for the ES and FR versions of the FAQ block.
 *
 * Questions use translated templates; answers use the translated record fields
 * from the content store (assets/content-i18n-*.js) where one exists, and fall
 * back to the English value only when a field has no translation (protocols,
 * store names and other proper nouns stay as they are).
 * ------------------------------------------------------------------------- */
const QT = {
  es: {
    app_used: (n) => "¿Para qué sirve la app " + n + "?",
    app_brand: (n) => "¿Qué marca publica " + n + "?",
    app_protocols: (n) => "¿Qué protocolos admite " + n + "?",
    app_platforms: (n) => "¿En qué plataformas funciona " + n + "?",
    app_download: (n) => "¿Dónde puedo descargar " + n + "?",
    app_verified: (n) => "¿Está verificada la ficha de " + n + "?",
    brand_makes: (n) => "¿Qué fabrica " + n + "?",
    brand_app: (n) => "¿Qué app usa " + n + "?",
    brand_protocols: (n) => "¿Qué protocolos usa " + n + "?",
    brand_hq: (n) => "¿Dónde tiene su base " + n + "?",
    brand_site: (n) => "¿Cuál es la web oficial de " + n + "?",
    proto_what: (n) => "¿Qué es " + n + "?",
    proto_range: (n) => "¿Qué alcance cubre " + n + "?",
    proto_power: (n) => "¿Cuánta energía consume " + n + "?",
    proto_topo: (n) => "¿Qué topología de red usa " + n + "?",
    proto_use: (n) => "¿Para qué se usa " + n + "?",
    proto_source: (n) => "¿Dónde puedo leer la especificación oficial de " + n + "?",
    cmp_better: (a, b) => "¿Qué es mejor, " + a + " o " + b + "?",
    cmp_summary: (t) => "¿Cuál es el resumen de " + t + "?",
    cmp_who: () => "¿Qué opción conviene a cada perfil?",
    cmp_scores: () => "¿Cómo se comparan las puntuaciones editoriales?",
    cloud_what: (n) => "¿Qué es " + n + "?",
    cloud_regions: (n) => "¿Qué regiones cubre " + n + "?",
    cloud_protocols: (n) => "¿Qué protocolos admite " + n + "?",
    cloud_price: (n) => "¿Cómo se factura " + n + "?",
    cloud_docs: (n) => "¿Dónde está la documentación oficial de " + n + "?",
    cat_what: (n) => "¿Qué incluye la categoría " + n + "?",
    cat_counts: (n) => "¿Cuántas marcas y apps hay catalogadas en " + n + "?",
    cat_protocols: (n) => "¿Qué protocolos son los más relevantes en " + n + "?",
    prod_what: (n) => "¿Qué es " + n + "?",
    prod_protocols: (n) => "¿Qué protocolos usa " + n + "?",
    prod_score: (n) => "¿Cuál es la puntuación editorial de " + n + "?",
    mod_what: (n) => "¿Qué es " + n + "?",
    mod_app: (n) => "¿Qué aplicación usa " + n + "?",
    mod_protocols: (n) => "¿Qué protocolos admite " + n + "?",
    mod_power: (n) => "¿Cómo se alimenta " + n + "?",
    mod_manual: (n) => "¿Dónde está el manual oficial de " + n + "?",
    mod_status: (n) => "¿Sigue a la venta " + n + "?",
    ts_why: (n) => "¿Por qué ocurre: " + n + "?",
    ts_cause: () => "¿Cuál es la causa más probable?",
    ts_check: () => "¿Qué debo comprobar primero?",
    ts_fix: () => "¿Cómo se soluciona?",
    ts_escalate: () => "¿Cuándo hay que escalar el caso?",
    cm_works: (a, b) => "¿Funciona " + a + " con " + b + "?",
    cm_needs: () => "¿Qué se necesita para que funcionen juntos?",
    cm_limits: () => "¿Qué limitaciones hay?",
    cm_setup: () => "¿Cómo se configura?",
    ct_what: (n) => "¿Qué es " + n + "?",
    ct_means: (n) => "¿Qué significa " + n + " para un producto?",
    ct_applies: (n) => "¿A qué productos se aplica " + n + "?",
    ct_gaps: (n) => "¿Qué no cubre " + n + "?",
    ct_need: (n) => "¿Qué se necesita para cumplir con " + n + "?"
  },
  fr: {
    app_used: (n) => "À quoi sert l'application " + n + " ?",
    app_brand: (n) => "Quelle marque publie " + n + " ?",
    app_protocols: (n) => "Quels protocoles " + n + " prend-il en charge ?",
    app_platforms: (n) => "Sur quelles plateformes " + n + " fonctionne-t-il ?",
    app_download: (n) => "Où télécharger " + n + " ?",
    app_verified: (n) => "La fiche de " + n + " est-elle vérifiée ?",
    brand_makes: (n) => "Que fabrique " + n + " ?",
    brand_app: (n) => "Quelle application " + n + " utilise-t-il ?",
    brand_protocols: (n) => "Quels protocoles " + n + " utilise-t-il ?",
    brand_hq: (n) => "Où " + n + " est-il basé ?",
    brand_site: (n) => "Quel est le site officiel de " + n + " ?",
    proto_what: (n) => "Qu'est-ce que " + n + " ?",
    proto_range: (n) => "Quelle portée couvre " + n + " ?",
    proto_power: (n) => "Quelle consommation a " + n + " ?",
    proto_topo: (n) => "Quelle topologie réseau " + n + " utilise-t-il ?",
    proto_use: (n) => "À quoi sert " + n + " ?",
    proto_source: (n) => "Où lire la spécification officielle de " + n + " ?",
    cmp_better: (a, b) => "Quel est le meilleur, " + a + " ou " + b + " ?",
    cmp_summary: (t) => "Quel est le résumé de " + t + " ?",
    cmp_who: () => "Quelle option convient à quel profil ?",
    cmp_scores: () => "Comment les scores éditoriaux se comparent-ils ?",
    cloud_what: (n) => "Qu'est-ce que " + n + " ?",
    cloud_regions: (n) => "Quelles régions couvre " + n + " ?",
    cloud_protocols: (n) => "Quels protocoles " + n + " prend-il en charge ?",
    cloud_price: (n) => "Comment " + n + " est-il facturé ?",
    cloud_docs: (n) => "Où se trouve la documentation officielle de " + n + " ?",
    cat_what: (n) => "Que contient la catégorie " + n + " ?",
    cat_counts: (n) => "Combien de marques et d'applications sont répertoriées dans " + n + " ?",
    cat_protocols: (n) => "Quels protocoles comptent le plus dans " + n + " ?",
    prod_what: (n) => "Qu'est-ce que " + n + " ?",
    prod_protocols: (n) => "Quels protocoles " + n + " utilise-t-il ?",
    prod_score: (n) => "Quel est le score éditorial de " + n + " ?",
    mod_what: (n) => "Qu'est-ce que " + n + " ?",
    mod_app: (n) => "Quelle application " + n + " utilise-t-il ?",
    mod_protocols: (n) => "Quels protocoles " + n + " prend-il en charge ?",
    mod_power: (n) => "Comment " + n + " est-il alimenté ?",
    mod_manual: (n) => "Où se trouve le manuel officiel de " + n + " ?",
    mod_status: (n) => "Le " + n + " est-il toujours commercialisé ?",
    ts_why: (n) => "Pourquoi cela se produit-il : " + n + " ?",
    ts_cause: () => "Quelle est la cause la plus probable ?",
    ts_check: () => "Que vérifier en premier ?",
    ts_fix: () => "Comment le corriger ?",
    ts_escalate: () => "Quand faut-il escalader le cas ?",
    cm_works: (a, b) => "Est-ce que " + a + " fonctionne avec " + b + " ?",
    cm_needs: () => "Que faut-il pour qu'ils fonctionnent ensemble ?",
    cm_limits: () => "Quelles sont les limites ?",
    cm_setup: () => "Comment le configurer ?",
    ct_what: (n) => "Qu'est-ce que " + n + " ?",
    ct_means: (n) => "Que signifie " + n + " pour un produit ?",
    ct_applies: (n) => "À quels produits " + n + " s'applique-t-il ?",
    ct_gaps: (n) => "Que ne couvre pas " + n + " ?",
    ct_need: (n) => "Que faut-il pour être conforme à " + n + " ?"
  }
};
const SUFFIX = { es: " Consulta la fuente oficial enlazada en esta página antes de decidir.", fr: " Vérifiez la source officielle liée sur cette page avant de décider." };
const DL = { es: "La ficha oficial está en ", fr: "La fiche officielle se trouve sur " };
const DL2 = { es: ". Los enlaces están en esta página.", fr: ". Les liens figurent sur cette page." };
const SCORES = { es: "Las puntuaciones son estimaciones editoriales, no una valoración ni una tasación.", fr: "Les scores sont des estimations éditoriales, ni une note ni une évaluation financière." };

/** Returns { es: [[q,a],...], fr: [[q,a],...] } built from translated fields. */
export function entityFaqsLocalized(type, rec, store) {
  const out = { es: [], fr: [] };
  const tr = (lang, field, fallback) => {
    const bucket = { app: "apps", brand: "brands", cloud: "clouds", protocol: "protocols", compare: "comparisons", model: "model", troubleshooting: "troubleshooting", compatibility: "compatibility", certification: "certification" }[type];
    const e = bucket && store && store[bucket] && store[bucket][rec.slug];
    // the staged stores hold the prose string directly (e.g. {es: "...", fr: "..."})
    const flat = e && typeof e[lang] === "string" ? e[lang] : "";
    const nested = e && e[lang] && typeof e[lang] === "object" ? e[lang][field] : "";
    return clean(nested) || clean(flat) || clean(fallback);
  };
  const trList = (lang, field, fallback) => {
    const bucket = { model: "model", troubleshooting: "troubleshooting", compatibility: "compatibility", certification: "certification" }[type];
    const e = bucket && store && store[bucket] && store[bucket][rec.slug];
    const nested = e && e[lang] && typeof e[lang] === "object" ? e[lang][field] : "";
    const src = Array.isArray(nested) ? nested : (Array.isArray(fallback) ? fallback : []);
    return src.map(clean).filter(Boolean);
  };
  for (const lang of ["es", "fr"]) {
    const Q = QT[lang];
    const a = [];
    if (type === "app") {
      a.push([Q.app_used(rec.name), tr(lang, "summary", rec.summary)]);
      if (rec.brand) a.push([Q.app_brand(rec.name), rec.brand + (rec.developer ? " (" + rec.developer + ")" : "") + "."]);
      if (clean(rec.protocols)) a.push([Q.app_protocols(rec.name), clean(rec.protocols) + "."]);
      if (clean(rec.platforms)) a.push([Q.app_platforms(rec.name), clean(rec.platforms) + "."]);
      if (rec.ios_url || rec.android_url) a.push([Q.app_download(rec.name), DL[lang] + [rec.android_url ? "Google Play" : "", rec.ios_url ? "App Store" : ""].filter(Boolean).join(" y ") + DL2[lang]]);
      if (rec.ios_verified === true && rec.verified_at) a.push([Q.app_verified(rec.name), (lang === "es" ? "Sí. La ficha se revisó el " : "Oui. La fiche a été vérifiée le ") + rec.verified_at + "."]);
    } else if (type === "brand") {
      a.push([Q.brand_makes(rec.name), arr(rec.categories).length ? rec.name + (lang === "es" ? " cubre: " : " couvre : ") + arr(rec.categories).join(", ") + "." : tr(lang, "notes", rec.notes)]);
      if (rec.app) a.push([Q.brand_app(rec.name), rec.app + "."]);
      if (arr(rec.protocols).length) a.push([Q.brand_protocols(rec.name), arr(rec.protocols).join(", ") + "."]);
      a.push([Q.brand_hq(rec.name), rec.hq ? (lang === "es" ? "Sede o mercado principal: " : "Siège ou marché principal : ") + rec.hq + "." : ""]);
      a.push([Q.brand_site(rec.name), rec.url || ""]);
    } else if (type === "protocol") {
      a.push([Q.proto_what(rec.name), tr(lang, "summary", rec.summary)]);
      if (rec.range) a.push([Q.proto_range(rec.name), (lang === "es" ? "Alcance típico: " : "Portée typique : ") + rec.range + "."]);
      if (rec.power) a.push([Q.proto_power(rec.name), (lang === "es" ? "Perfil de consumo: " : "Profil de consommation : ") + rec.power + "."]);
      if (rec.topology) a.push([Q.proto_topo(rec.name), rec.topology + "."]);
      if (rec.use) a.push([Q.proto_use(rec.name), rec.use + "."]);
      if (rec.source) a.push([Q.proto_source(rec.name), rec.source]);
    } else if (type === "compare") {
      a.push([Q.cmp_better(rec.a, rec.b), tr(lang, "summary", rec.verdict)]);
      a.push([Q.cmp_summary(rec.title), tr(lang, "summary", rec.summary)]);
      const bf = rec.bestFor || {}, keys = Object.keys(bf).filter((k) => clean(bf[k]));
      if (keys.length) a.push([Q.cmp_who(), keys.map((k) => cap(k) + ": " + clean(bf[k])).join(" ")]);
      const s = [];
      if (typeof rec.scoreA === "number") s.push(rec.a + " " + rec.scoreA);
      if (typeof rec.scoreB === "number") s.push(rec.b + " " + rec.scoreB);
      if (s.length) a.push([Q.cmp_scores(), s.join(" · ") + ". " + SCORES[lang]]);
    } else if (type === "cloud") {
      a.push([Q.cloud_what(rec.name), [tr(lang, "notes", rec.notes), rec.type ? (lang === "es" ? "Tipo de plataforma: " : "Type de plateforme : ") + rec.type + "." : ""].filter(Boolean).join(" ")]);
      if (rec.regions) a.push([Q.cloud_regions(rec.name), rec.regions + "."]);
      if (arr(rec.protocols).length) a.push([Q.cloud_protocols(rec.name), arr(rec.protocols).join(", ") + "."]);
      if (rec.price) a.push([Q.cloud_price(rec.name), rec.price + "."]);
      if (rec.docs) a.push([Q.cloud_docs(rec.name), rec.docs]);
    } else if (type === "category") {
      const en = clean((rec.names || {}).en || rec.slug);
      a.push([Q.cat_what(en), clean((rec.descriptions || {})[lang] || (rec.descriptions || {}).en || "")]);
      a.push([Q.cat_counts(en), arr(rec.brands).length + " · " + arr(rec.apps).length]);
      if (arr(rec.protocols).length) a.push([Q.cat_protocols(en), arr(rec.protocols).join(", ") + "."]);
    } else if (type === "model") {
      const nm = rec.brand + " " + rec.model;
      a.push([Q.mod_what(nm), tr(lang, "summary", rec.summary)]);
      if (clean(rec.app)) a.push([Q.mod_app(nm), clean(rec.app) + "."]);
      if (arr(rec.protocols).length) a.push([Q.mod_protocols(nm), arr(rec.protocols).join(", ") + "."]);
      if (clean(rec.power)) a.push([Q.mod_power(nm), tr(lang, "power", rec.power) + "."]);
      if (clean(rec.manualUrl) || clean(rec.supportUrl)) a.push([Q.mod_manual(nm), clean(rec.manualUrl || rec.supportUrl)]);
      if (clean(rec.status)) a.push([Q.mod_status(nm), tr(lang, "status", rec.status) + "."]);
    } else if (type === "compatibility") {
      const subj = clean(rec.subject), tgt = clean(rec.target);
      a.push([Q.cm_works(subj, tgt), [tr(lang, "verdict", rec.verdict) ? tr(lang, "verdict", rec.verdict) + "." : "", tr(lang, "summary", rec.summary)].filter(Boolean).join(" ")]);
      const req = trList(lang, "requirements", rec.requirements);
      if (req.length) a.push([Q.cm_needs(), req.join("; ") + "."]);
      const lim = trList(lang, "limitations", rec.limitations);
      if (lim.length) a.push([Q.cm_limits(), lim.join("; ") + "."]);
      const stp = trList(lang, "steps", rec.steps);
      if (stp.length) a.push([Q.cm_setup(), stp.join("; ")]);
    } else if (type === "certification") {
      const nmc = tr(lang, "name", rec.name);
      a.push([Q.ct_what(nmc), tr(lang, "summary", rec.summary)]);
      if (clean(rec.meaning)) a.push([Q.ct_means(nmc), tr(lang, "meaning", rec.meaning)]);
      const app2 = trList(lang, "appliesTo", rec.appliesTo);
      if (app2.length) a.push([Q.ct_applies(nmc), app2.join("; ") + "."]);
      const gaps = trList(lang, "doesNotCover", rec.doesNotCover);
      if (gaps.length) a.push([Q.ct_gaps(clean(rec.code) || nmc), gaps.join("; ") + "."]);
      const ck = trList(lang, "checklist", rec.checklist);
      if (ck.length) a.push([Q.ct_need(nmc), ck.join("; ") + "."]);
    } else if (type === "troubleshooting") {
      a.push([Q.ts_why(tr(lang, "title", rec.title)), tr(lang, "symptom", rec.symptom)]);
      const causes = trList(lang, "likelyCauses", rec.likelyCauses).slice(0, 3);
      if (causes.length) a.push([Q.ts_cause(), causes.join("; ") + "."]);
      const checks = trList(lang, "quickChecks", rec.quickChecks);
      if (checks.length) a.push([Q.ts_check(), checks.join("; ") + "."]);
      const steps = trList(lang, "steps", rec.steps);
      if (steps.length) a.push([Q.ts_fix(), steps.join("; ")]);
      if (clean(rec.escalation)) a.push([Q.ts_escalate(), tr(lang, "escalation", rec.escalation)]);
    }
    out[lang] = a.filter((p) => clean(p[0]) && clean(p[1]).length >= 3);
  }
  return out;
}
