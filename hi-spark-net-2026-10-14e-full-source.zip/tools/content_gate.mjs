#!/usr/bin/env node
/**
 * Content quality gate - enforces content_quality_gate.yml.
 *
 *   node tools/audit_site.mjs --gate
 *
 * Runs the structural audit first, then checks the editorial contract:
 *   1. every "required" field in the gate is actually storable (exists as a CSV column)
 *   2. every requiredSchema type is present in JSON-LD on at least one page
 *   3. hreflang alternates are reciprocal
 *   4. every page that must carry a disclosure actually does
 * Exit code 1 when a blocking rule fails.
 */
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath, pathToFileURL } from "node:url";

const PROTO = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const GATE_CANDIDATES = [
  path.join(PROTO, "content_quality_gate.yml"),
  path.resolve(PROTO, "..", "content_quality_gate.yml")
];
const gatePath = GATE_CANDIDATES.find((p) => fs.existsSync(p));

if (!gatePath) {
  console.error("content_quality_gate.yml not found in the prototype root or its parent.");
  process.exit(1);
}

const yaml = fs.readFileSync(gatePath, "utf8");
const rel = (p) => path.relative(PROTO, p) || ".";
const pass = [], fail = [], skip = [];

// ---- minimal parser for this file's shape (2-4 space nesting, scalar + list) ----
function parse(y) {
  const root = {};
  let section = null, rule = null, listKey = null;
  for (const raw of y.split(/\r?\n/)) {
    if (!raw.trim() || raw.trim().startsWith("#")) continue;
    const indent = raw.length - raw.trimStart().length;
    const line = raw.trim();
    if (indent === 0 && /^[a-z_]+:\s*$/.test(line)) { section = line.slice(0, -1); root[section] = {}; rule = null; listKey = null; continue; }
    if (indent === 2 && line.endsWith(":") && !line.includes(" ")) { rule = line.slice(0, -1); root[section][rule] = {}; listKey = null; continue; }
    if (line.startsWith("- ")) { if (listKey) root[section][rule][listKey].push(line.slice(2).trim()); continue; }
    const m = line.match(/^([a-z_]+):\s*(.*)$/);
    if (m) {
      const [, k, v] = m;
      if (rule) {
        if (v === "") { listKey = k; root[section][rule][k] = []; }
        else { listKey = null; root[section][rule][k] = v; }
      } else if (section) { listKey = null; root[section][k] = v; }
      else { listKey = null; root[k] = v; }
    }
  }
  return root;
}
const G = parse(yaml);
const PAGE_RULES = G.page_rules || {};

// ---- 1. required fields must be storable in a template ----
const TPL = path.join(PROTO, "content-templates");
const cols = {};
if (fs.existsSync(TPL)) {
  for (const f of fs.readdirSync(TPL).filter((x) => x.endsWith(".csv"))) {
    const head = fs.readFileSync(path.join(TPL, f), "utf8").split(/\r?\n/)[0];
    cols[f] = head.split(",").map((c) => c.replace(/^"|"$/g, "").trim());
  }
}
// the gate vocabulary and the template column names differ in a few places; map them explicitly
const FIELD_ALIAS = {
  canonical_brand: "brand_slug",
  canonical_model: "model",
  category_ids: "category_slugs",
  official_product_url: "official_url",
  official_manual_url: "official_url",
  product_entity_id: "product_id",
  setup_or_troubleshooting_section: "setup_summary_en",
  official_docs: "docs_url",
  pricing_effective_date: "price_effective_at",
  data_provider_or_source: "source_provider"
};
const resolveField = (f) => FIELD_ALIAS[f] || f;
const allCols = new Set(Object.values(cols).flat());

for (const [rule, spec] of Object.entries(PAGE_RULES)) {
  const required = spec.required || [];
  if (!required.length) { skip.push([rule, "no required fields declared"]); continue; }
  const missing = required.filter((f) => !allCols.has(resolveField(f)));
  if (missing.length) fail.push([rule, "required field(s) not storable in any content template: " + missing.join(", ")]);
  else pass.push([rule, required.length + " required fields all present in the template schema"]);
}

// ---- 2. required schema types must appear in JSON-LD ----
const htmlFiles = fs.readdirSync(PROTO).filter((f) => f.endsWith(".html"));
const ldText = htmlFiles.map((f) => fs.readFileSync(path.join(PROTO, f), "utf8")).join("\n");
const needSchema = new Set(Object.values(G.required_schema || {}).flatMap(function(v){
  return String(v).replace(/^\[|\]$/g, "").split(",").map(function(s){return s.trim();}).filter(Boolean);
}));
const missingSchema = [...needSchema].filter((t) => !new RegExp('"@type"\\s*:\\s*"?' + t + '"').test(ldText));
if (missingSchema.length) fail.push(["required_schema", "schema types never emitted: " + missingSchema.join(", ")]);
else pass.push(["required_schema", needSchema.size + " schema types emitted"]);

// ---- 3. hreflang reciprocity ----
const REQUIRED_LOCALES = ["en", "es", "fr", "x-default"];
const alt = [];
for (const f of htmlFiles) {
  const txt = fs.readFileSync(path.join(PROTO, f), "utf8");
  const tags = [...txt.matchAll(/hreflang="([^"]+)"/g)].map((m) => m[1]);
  if (tags.length) alt.push([f, tags]);
}
if (!alt.length) {
  skip.push(["translation.hreflang", "no hreflang tags emitted yet (single-language prototype)"]);
} else {
  const incomplete = alt.filter(([, tags]) => REQUIRED_LOCALES.some((l) => !tags.includes(l)));
  if (incomplete.length) fail.push(["translation.hreflang", incomplete.length + " page(s) missing locales: " + incomplete.slice(0, 4).map((x) => x[0]).join(", ")]);
  else pass.push(["translation.hreflang", alt.length + " pages carry reciprocal en/es/fr + x-default alternates"]);
  const noCanonical = htmlFiles.filter((f) => !/rel="canonical"/.test(fs.readFileSync(path.join(PROTO, f), "utf8")));
  if (noCanonical.length) fail.push(["translation.canonical", noCanonical.length + " page(s) missing rel=canonical"]);
  else pass.push(["translation.canonical", htmlFiles.length + " pages declare a canonical URL"]);
}

// ---- 4. mandatory disclosures ----
const needsDisclosure = ["amazon_ranking", "review", "best_guide"];
const disclosureFiles = htmlFiles.filter((f) => /affiliate/i.test(fs.readFileSync(path.join(PROTO, f), "utf8")));
if (disclosureFiles.length) pass.push(["disclosure", "affiliate disclosure present on " + disclosureFiles.length + " page(s)"]);
else fail.push(["disclosure", "no page mentions the affiliate disclosure required by " + needsDisclosure.join(", ")]);

// ---- report ----
const line = "-".repeat(70);
console.log("\n" + line);
console.log("Content quality gate  (" + rel(gatePath) + ")");
console.log(line);
for (const [k, v] of pass) console.log("  PASS  " + k.padEnd(22) + v);
for (const [k, v] of skip) console.log("  SKIP  " + k.padEnd(22) + v);
for (const [k, v] of fail) console.log("  FAIL  " + k.padEnd(22) + v);
console.log(line);
console.log("Gate result: " + pass.length + " passed, " + skip.length + " skipped, " + fail.length + " failed.");
process.exit(fail.length ? 1 : 0);
