#!/usr/bin/env node
/**
 * Builds the market entry pages: one page per market answering "what does it take
 * to sell this kind of product there?".
 *
 *   node tools/build_market_pages.mjs
 *
 * Source of truth is assets/certification-data.js: each market page lists the
 * certification records whose `region` covers that market, so nothing here can
 * drift from the certification centre. Writes market/<slug>.html plus the
 * markets.html hub, and appends the URLs to sitemap-entities.xml.
 *
 * Language: static English plus an ES/FR payload (<script data-l10n>) that
 * assets/share-cta.js swaps at runtime, matching the rest of the site.
 */
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { VERSIONED } from "./asset-version.mjs";

const PROTO = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const SITE = process.env.SITE_URL || "https://hi-spark.net";
const TODAY = new Date().toISOString().slice(0, 10);

const certs = JSON.parse(fs.readFileSync(path.join(PROTO, "assets", "certification-data.js"), "utf8").slice(fs.readFileSync(path.join(PROTO, "assets", "certification-data.js"), "utf8").indexOf("["), fs.readFileSync(path.join(PROTO, "assets", "certification-data.js"), "utf8").lastIndexOf("]") + 1));
let core = {};
try { const t = fs.readFileSync(path.join(PROTO, "assets", "content-i18n-core.js"), "utf8"); core = JSON.parse(t.slice(t.indexOf("{"), t.lastIndexOf("}") + 1)); } catch (e) {}
const certI18n = (core.certification || {});

/* Market definition: name in three languages, a one-line lede, and the
   certification codes that govern it. Codes must exist in the centre. */
/* SERP titles get truncated around 60 characters. Keep the keyword-rich form
   when it fits, fall back to a shorter form, then to the bare phrase. */
function marketTitle(name) {
  const rich = "IoT certification requirements in " + name + " | IoT Atlas";
  if (rich.length <= 60) return rich;
  const mid = "IoT certification in " + name + " | IoT Atlas";
  if (mid.length <= 60) return mid;
  const bare = "IoT certification in " + name;
  return bare.length <= 60 ? bare : bare.slice(0, 57) + "…";
}

const MARKETS = [
  { slug: "united-states", en: "United States", es: "Estados Unidos", fr: "États-Unis",
    lede: "Radio approval, safety listing, children's data and state privacy rules all apply to connected products sold in the United States.",
    ledeEs: "La homologación radioeléctrica, el listado de seguridad, los datos de menores y las normas estatales de privacidad se aplican a los productos conectados vendidos en Estados Unidos.",
    ledeFr: "Homologation radio, homologation de sécurité, données des mineurs et règles étatiques de confidentialité s'appliquent aux produits connectés vendus aux États-Unis.",
    codes: ["FCC", "UL / ETL", "CSA", "Prop 65", "CCPA / CPRA", "COPPA", "Energy Star", "NIST 8259", "SOC 2", "US Cyber Trust Mark"] },
  { slug: "european-union", en: "European Union", es: "Unión Europea", fr: "Union européenne",
    lede: "CE marking is the entry ticket, and since August 2025 connected radio equipment must also meet the RED cybersecurity requirements.",
    ledeEs: "El marcado CE es la puerta de entrada y, desde agosto de 2025, los equipos radioeléctricos conectados también deben cumplir los requisitos de ciberseguridad de la RED.",
    ledeFr: "Le marquage CE est le droit d'entrée et, depuis août 2025, les équipements radio connectés doivent aussi satisfaire les exigences de cybersécurité de la RED.",
    codes: ["CE / RED", "EN 18031", "EMC", "RoHS", "REACH", "WEEE", "EU Battery", "GDPR", "EN 303 645"] },
  { slug: "united-kingdom", en: "United Kingdom", es: "Reino Unido", fr: "Royaume-Uni",
    lede: "Great Britain runs its own UKCA framework alongside continued CE recognition for most goods.",
    ledeEs: "Gran Bretaña aplica su propio marco UKCA, además del reconocimiento continuado del marcado CE para la mayoría de productos.",
    ledeFr: "La Grande-Bretagne applique son propre cadre UKCA, en plus de la reconnaissance continue du marquage CE pour la plupart des produits.",
    codes: ["UKCA", "WEEE", "RoHS", "EMC", "EN 303 645"] },
  { slug: "canada", en: "Canada", es: "Canadá", fr: "Canada",
    lede: "ISED certification plus a Canadian safety listing, usually combined with the United States in one certification project.",
    ledeEs: "Certificación ISED más un listado de seguridad canadiense, normalmente combinado con Estados Unidos en un solo proyecto.",
    ledeFr: "Certification ISED plus une homologation de sécurité canadienne, souvent combinée avec les États-Unis dans un même projet.",
    codes: ["ISED", "CSA", "UL / ETL", "ISED"] },
  { slug: "california", en: "California", es: "California", fr: "Californie",
    lede: "Beyond federal rules, California adds chemical warning duties and consumer privacy rights that reach device identifiers and app data.",
    ledeEs: "Además de las normas federales, California añade obligaciones de advertencia química y derechos de privacidad que alcanzan identificadores de dispositivo y datos de apps.",
    ledeFr: "Au-delà des règles fédérales, la Californie ajoute des obligations d'avertissement chimique et des droits de confidentialité qui touchent les identifiants d'appareil et les données d'application.",
    codes: ["Prop 65", "CCPA / CPRA", "FCC", "COPPA"] },
  { slug: "brazil", en: "Brazil", es: "Brasil", fr: "Brésil",
    lede: "Anatel homologation is required before a wireless product can be sold or connected in Brazil.",
    ledeEs: "La homologación de Anatel es obligatoria antes de vender o conectar un producto inalámbrico en Brasil.",
    ledeFr: "L'homologation Anatel est requise avant de vendre ou de connecter un produit sans fil au Brésil.",
    codes: ["Anatel"] },
  { slug: "mexico", en: "Mexico", es: "México", fr: "Mexique",
    lede: "IFT homologation covers radio and telecom products entering Mexico, filed through a local holder.",
    ledeEs: "La homologación del IFT cubre los productos de radio y telecomunicaciones que entran en México, presentada a través de un titular local.",
    ledeFr: "L'homologation IFT couvre les produits radio et télécoms entrant au Mexique, déposée via un titulaire local.",
    codes: ["IFT"] },
  { slug: "japan", en: "Japan", es: "Japón", fr: "Japon",
    lede: "Radio equipment needs MIC certification (the Giteki mark), with PSE touching the power supply of many connected devices.",
    ledeEs: "Los equipos de radio necesitan la certificación MIC (marca Giteki), y PSE afecta a la fuente de alimentación de muchos dispositivos conectados.",
    ledeFr: "Les équipements radio nécessitent la certification MIC (marque Giteki), PSE concernant l'alimentation de nombreux appareils connectés.",
    codes: ["MIC / TELEC"] },
  { slug: "south-korea", en: "South Korea", es: "Corea del Sur", fr: "Corée du Sud",
    lede: "KC certification combines radio conformity with safety and EMC approval for many categories.",
    ledeEs: "La certificación KC combina la conformidad radioeléctrica con la aprobación de seguridad y EMC en muchas categorías.",
    ledeFr: "La certification KC combine conformité radio et homologation sécurité et CEM dans de nombreuses catégories.",
    codes: ["KC"] },
  { slug: "taiwan", en: "Taiwan", es: "Taiwán", fr: "Taïwan",
    lede: "NCC type approval covers low-power radio equipment, with BSMI handling safety and EMC separately.",
    ledeEs: "La homologación NCC cubre los equipos de radio de baja potencia, mientras BSMI gestiona seguridad y EMC por separado.",
    ledeFr: "L'homologation NCC couvre les équipements radio à faible puissance, le BSMI traitant sécurité et CEM séparément.",
    codes: ["NCC"] },
  { slug: "australia-new-zealand", en: "Australia and New Zealand", es: "Australia y Nueva Zelanda", fr: "Australie et Nouvelle-Zélande",
    lede: "The RCM covers radio and, where the product is mains powered, electrical safety under the EESS.",
    ledeEs: "El RCM cubre la radio y, si el producto se alimenta de red, la seguridad eléctrica bajo el EESS.",
    ledeFr: "Le RCM couvre la radio et, pour les produits sur secteur, la sécurité électrique au titre de l'EESS.",
    codes: ["RCM"] },
  { slug: "india", en: "India", es: "India", fr: "Inde",
    lede: "BIS registration for listed electronics and WPC approval for the radio interface are usually both required.",
    ledeEs: "Normalmente se exigen tanto el registro BIS para la electrónica listada como la aprobación WPC para la interfaz radio.",
    ledeFr: "L'enregistrement BIS pour l'électronique listée et l'approbation WPC pour l'interface radio sont généralement exigés.",
    codes: ["BIS / WPC"] },
  { slug: "saudi-arabia", en: "Saudi Arabia", es: "Arabia Saudí", fr: "Arabie saoudite",
    lede: "SABER conformity for customs clearance plus CITC approval for radio and telecom products.",
    ledeEs: "Conformidad SABER para el despacho de aduanas más la aprobación de CITC para productos de radio y telecomunicaciones.",
    ledeFr: "Conformité SABER pour le dédouanement, plus l'approbation CITC pour les produits radio et télécoms.",
    codes: ["SASO"] },
  { slug: "eurasia", en: "Eurasian Economic Union", es: "Unión Económica Euroasiática", fr: "Union économique eurasienne",
    lede: "EAC conformity covers safety, EMC and radio requirements across the member states.",
    ledeEs: "La conformidad EAC cubre seguridad, EMC y requisitos de radio en todos los Estados miembros.",
    ledeFr: "La conformité EAC couvre la sécurité, la CEM et les exigences radio dans tous les États membres.",
    codes: ["EAC"] },
  { slug: "china", en: "China", es: "China", fr: "Chine",
    lede: "SRRC approval for the radio transmitter and CCC where the product sits in the compulsory certification catalogue.",
    ledeEs: "Aprobación SRRC para el transmisor de radio y CCC cuando el producto está en el catálogo de certificación obligatoria.",
    ledeFr: "Approbation SRRC pour l'émetteur radio et CCC lorsque le produit figure au catalogue de certification obligatoire.",
    codes: ["SRRC / CCC"] },
  { slug: "international-baselines", en: "International baselines", es: "Bases internacionales", fr: "Socles internationaux",
    lede: "Standards and security baselines that travel with the product design rather than a single market.",
    ledeEs: "Normas y bases de seguridad que acompañan al diseño del producto, no a un solo mercado.",
    ledeFr: "Normes et socles de sécurité qui accompagnent la conception du produit, plutôt qu'un marché unique.",
    codes: ["IEC 62368-1", "CB Scheme", "IP", "EN 303 645", "IEC 62443", "ISO 27001", "ISO 27701", "SOC 2", "NIST 8259"] },
  { slug: "wireless-interoperability", en: "Wireless and interoperability", es: "Radio e interoperabilidad", fr: "Radio et interopérabilité",
    lede: "Certification that decides whether a device works with the ecosystem a buyer already owns.",
    ledeEs: "Certificaciones que determinan si un dispositivo funciona con el ecosistema que el comprador ya tiene.",
    ledeFr: "Certifications qui déterminent si un appareil fonctionne avec l'écosystème que l'acheteur possède déjà.",
    codes: ["Wi-Fi CERTIFIED", "Bluetooth SIG", "Matter", "Thread", "Zigbee", "Qi"] },
  { slug: "battery-and-transport", en: "Batteries and transport", es: "Baterías y transporte", fr: "Batteries et transport",
    lede: "Lithium batteries add transport testing and, in the EU, a separate battery regulation.",
    ledeEs: "Las baterías de litio añaden ensayos de transporte y, en la UE, un reglamento específico de baterías.",
    ledeFr: "Les batteries lithium ajoutent des essais de transport et, dans l'UE, un règlement batteries spécifique.",
    codes: ["UN 38.3", "EU Battery"] }
];

const esc = (v) => String(v == null ? "" : v).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
const clean = (v) => String(v == null ? "" : v).replace(/\s+/g, " ").trim();
const certByCode = {};
for (const c of certs) certByCode[clean(c.code)] = c;

function marketCerts(m) {
  const seen = new Set(), out = [];
  for (const code of m.codes) { const c = certByCode[code]; if (c && !seen.has(c.slug)) { seen.add(c.slug); out.push(c); } }
  return out;
}
function faqsFor(m, list) {
  const out = [];
  const mandatory = list.filter((c) => /Mandatory|Required|Obligatoria|Obligatoire/i.test(clean(c.status)));
  out.push({ q: "Which certifications are mandatory to sell an IoT device in " + m.en + "?",
    a: (mandatory.length ? mandatory.map((c) => clean(c.code) + " (" + clean(c.name) + ")").join(", ") : list.map((c) => clean(c.code)).join(", ")) + ". Each record lists the issuing body, what it covers and what it does not cover." });
  out.push({ q: "Are voluntary marks needed as well?",
    a: list.filter((c) => /Voluntary|Conditional/i.test(clean(c.status))).map((c) => clean(c.code) + " - " + clean(c.name)).join("; ") || "No voluntary schemes are catalogued for this market yet." });
  out.push({ q: "Where can I read the official requirement?",
    a: "Every certification record links to the issuing body or the regulation text. Start from this page, open the record and follow its source links." });
  out.push({ q: "Does a certificate for a module cover the finished product?",
    a: "No. A module certificate covers the module; the finished device usually needs its own approval or a documented module grant reference. Confirm with the issuing body or your test laboratory." });
  return out;
}
function pageHtml(m) {
  const list = marketCerts(m);
  const faqs = faqsFor(m, list);
  const checklist = [];
  for (const c of list) for (const item of (c.checklist || [])) { const v = clean(item); if (v && !checklist.includes(v)) checklist.push(v); }
  const checklistTop = checklist.slice(0, 8);
  const canonical = SITE + "/market/" + m.slug + ".html";
  const title = marketTitle(m.en);
  const desc = ("Which certifications apply to connected products in " + m.en + ": " + list.map((c) => clean(c.code)).join(", ") + ". Requirements, issued-by and verification steps.").slice(0, 158);
  const ld = { "@context": "https://schema.org", "@graph": [
    { "@type": "CollectionPage", name: title, url: canonical, inLanguage: ["en", "es", "fr"] },
    { "@type": "FAQPage", mainEntity: faqs.map((f) => ({ "@type": "Question", name: f.q, acceptedAnswer: { "@type": "Answer", text: f.a } })) },
    { "@type": "BreadcrumbList", itemListElement: [
      { "@type": "ListItem", position: 1, name: "Home", item: SITE + "/" },
      { "@type": "ListItem", position: 2, name: "Markets", item: SITE + "/markets.html" },
      { "@type": "ListItem", position: 3, name: m.en, item: canonical } ] }
  ] };
  const l10n = { es: { title: "Requisitos de certificación IoT en " + m.es, lede: m.ledeEs, h_certs: "Certificaciones aplicables", h_check: "Qué preparar", h_faq: "Preguntas frecuentes", h_rel: "Otros mercados" },
    fr: { title: "Exigences de certification IoT en " + m.fr, lede: m.ledeFr, h_certs: "Certifications applicables", h_check: "À préparer", h_faq: "Questions fréquentes", h_rel: "Autres marchés" } };
  const scripts = fs.readFileSync(path.join(PROTO, "certification", "fcc.html"), "utf8").match(/<script src="\.\.\/assets\/[^"]+"><\/script>/g) || [];
  return [
    "<!doctype html><html lang=\"en\"><head><meta charset=\"utf-8\"><meta name=\"viewport\" content=\"width=device-width,initial-scale=1\">",
    "<title>" + esc(title) + "</title>",
    "<meta name=\"description\" content=\"" + esc(desc) + "\">",
    "<link rel=\"stylesheet\" href=\"../assets/styles.css" + VERSIONED + "\">",
    "<link rel=\"canonical\" href=\"" + canonical + "\">",
    ["en", "es", "fr"].map((l) => "<link rel=\"alternate\" hreflang=\"" + l + "\" href=\"" + canonical + (l === "en" ? "" : "?lang=" + l) + "\">").join(""),
    "<link rel=\"alternate\" hreflang=\"x-default\" href=\"" + canonical + "\">",
    "<meta name=\"robots\" content=\"index,follow,max-image-preview:large\">",
    "<link rel=\"icon\" href=\"../favicon.ico\" sizes=\"any\"><link rel=\"apple-touch-icon\" href=\"../apple-touch-icon.png\"><link rel=\"manifest\" href=\"../manifest.webmanifest\">",
    "<meta name=\"theme-color\" content=\"#0c7475\">",
    "<meta property=\"og:type\" content=\"article\"><meta property=\"og:site_name\" content=\"IoT Atlas\">",
    "<meta property=\"og:title\" content=\"" + esc(title) + "\"><meta property=\"og:description\" content=\"" + esc(desc) + "\"><meta property=\"og:url\" content=\"" + canonical + "\">",
    "<meta property=\"og:image\" content=\"" + SITE + "/assets/og-default.png\"><meta property=\"og:image:width\" content=\"1200\"><meta property=\"og:image:height\" content=\"630\"><meta property=\"og:image:alt\" content=\"" + esc(title) + "\">",
    "<meta property=\"og:locale\" content=\"en_US\"><meta property=\"og:locale:alternate\" content=\"es_ES\"><meta property=\"og:locale:alternate\" content=\"fr_FR\">",
    "<meta name=\"twitter:card\" content=\"summary_large_image\"><meta name=\"twitter:image\" content=\"" + SITE + "/assets/og-default.png\"><meta name=\"twitter:title\" content=\"" + esc(title) + "\"><meta name=\"twitter:description\" content=\"" + esc(desc) + "\">",
    "<script type=\"application/ld+json\" data-generated=\"structured-data\">" + JSON.stringify(ld) + "</script>",
    "</head><body data-page=\"market\">",
    "<a class=\"skip-link\" href=\"#main\">Skip to content</a><div id=\"site-header\"></div>",
    "<main id=\"main\"><div class=\"container breadcrumbs\"><a href=\"../index.html\">Home</a> / <a href=\"../markets.html\">Markets</a> / <span>" + esc(m.en) + "</span></div>",
    "<section class=\"page-hero\"><div class=\"container\">",
    "<span class=\"eyebrow\">Market entry</span>",
    "<h1 data-l10n-key=\"title\">IoT certification requirements in " + esc(m.en) + "</h1>",
    "<p class=\"lede\" data-l10n-key=\"lede\">" + esc(m.lede) + "</p>",
    "<p class=\"data-note\">" + list.length + " certification records apply · last reviewed " + TODAY + "</p>",
    "</div></section>",
    "<section class=\"share-bar\" id=\"share-bar\"></section>",
    "<section class=\"section compact\"><div class=\"container\">",
    "<h2 class=\"group-heading\" data-l10n-key=\"h_certs\">Certifications that apply</h2>",
    "<div class=\"card-grid\">" + list.map((c) => { const tr = (certI18n[c.slug] || {}); return "<a class=\"card expanded-card\" href=\"../certification/" + c.slug + ".html\"><span class=\"pill blue\">" + esc(c.code) + "</span><h3>" + esc(c.name) + "</h3><p>" + esc(clean(c.summary).slice(0, 150)) + "</p><span class=\"text-link\">Open the certification page →</span></a>"; }).join("") + "</div>",
    "</div></section>",
    "<section class=\"section compact\"><div class=\"container two-col\">",
    "<article class=\"content-card\"><h2 data-l10n-key=\"h_check\">What to prepare</h2><div>\u0000CHECK\u0000</div></article>",
    "<aside class=\"sticky-side\"><div class=\"side-card\"><h3>Sources</h3><ul class=\"source-list\">" + list.map((c) => "\u0000SRC" + c.slug + "\u0000").join("") + "</ul></div></aside>",
    "</div></section>",
    "<section class=\"section compact\"><div class=\"container\"><h2 class=\"group-heading\" data-l10n-key=\"h_faq\">Frequently asked questions</h2><div class=\"faq-list\">" + faqs.map((f) => "<details class=\"faq-item\" open><summary>" + esc(f.q) + "</summary><p>" + esc(f.a) + "</p></details>").join("") + "</div></div></section>",
    "<section class=\"section compact\"><div class=\"container\"><h2 class=\"group-heading\" data-l10n-key=\"h_rel\">Other markets</h2><div class=\"related-grid\">" + MARKETS.filter((x) => x.slug !== m.slug).slice(0, 4).map((x) => "<a class=\"related-card\" href=\"" + x.slug + ".html\"><span class=\"pill blue\">Market</span><strong>" + esc(x.en) + "</strong></a>").join("") + "</div></div></section>",
    "<section class=\"section compact\" id=\"share-cta\"></section>",
    "</main><div id=\"site-footer\"></div>",
    scripts.join(""),
    "<script type=\"application/json\" data-l10n>" + JSON.stringify(l10n) + "</script>",
    "</body></html>"
  ].join("\n");
}

/* Reuse the plain-HTML site nav that prerender_entities injects into the built
   pages, so the market pages written here are crawlable in the same way. */
function staticNavBlock() {
  let nav = "";
  for (const probe of ["certifications.html", "certification/fcc.html"]) {
    const p = path.join(PROTO, probe);
    if (!fs.existsSync(p)) continue;
    const m = fs.readFileSync(p, "utf8").match(/<nav class="static-index"[\s\S]*?<\/nav>/);
    if (m) { nav = m[0]; break; }
  }
  return nav;
}
const NAV = staticNavBlock();
const NAV_DEEP = NAV.replace(/href="([^"]+)"/g, (m, h) => /^(?:https?:|\.\.?\/)/.test(h) ? m : 'href="../' + h + '"');

fs.mkdirSync(path.join(PROTO, "market"), { recursive: true });
let written = 0;
const urls = [];
for (const m of MARKETS) {
  const list = marketCerts(m);
  let html = pageHtml(m);
  const checklist = [];
  for (const c of list) for (const it of (c.checklist || [])) { const v = clean(it); if (v && !checklist.includes(v)) checklist.push(v); }
  html = html.replace("\u0000CHECK\u0000", "<ul class=\"source-list\">" + checklist.slice(0, 8).map((x) => "<li>" + esc(x) + "</li>").join("") + "</ul>");
  for (const c of list) {
    const first = (c.sources || [])[0];
    html = html.replace("\u0000SRC" + c.slug + "\u0000", first ? "<li><a href=\"" + esc(first.url) + "\" target=\"_blank\" rel=\"noopener\">" + esc(first.label || c.code) + "</a></li>" : "");
  }
  if (NAV_DEEP) html = html.replace("</body>", NAV_DEEP + "</body>");
  fs.writeFileSync(path.join(PROTO, "market", m.slug + ".html"), html, "utf8");
  written++;
  urls.push({ loc: SITE + "/market/" + m.slug + ".html", lastmod: TODAY, title: marketTitle(m.en) });
}

/* hub */
const hubScripts = fs.readFileSync(path.join(PROTO, "certifications.html"), "utf8").match(/<script src="assets\/[^"]+"><\/script>/g) || [];
const hub = [
  "<!doctype html><html lang=\"en\"><head><meta charset=\"utf-8\"><meta name=\"viewport\" content=\"width=device-width,initial-scale=1\">",
  "<title>IoT certification requirements by market | IoT Atlas</title>",
  "<meta name=\"description\" content=\"What it takes to sell connected products in each market: certification schemes, what they cover, who issues them and what to verify.\">",
  "<link rel=\"stylesheet\" href=\"assets/styles.css" + VERSIONED + "\">",
  "<link rel=\"canonical\" href=\"" + SITE + "/markets.html\">",
  ["en", "es", "fr"].map((l) => "<link rel=\"alternate\" hreflang=\"" + l + "\" href=\"" + SITE + "/markets.html" + (l === "en" ? "" : "?lang=" + l) + "\">").join(""),
  "<link rel=\"alternate\" hreflang=\"x-default\" href=\"" + SITE + "/markets.html\">",
  "<meta name=\"robots\" content=\"index,follow,max-image-preview:large\">",
  "<link rel=\"icon\" href=\"favicon.ico\" sizes=\"any\"><link rel=\"apple-touch-icon\" href=\"apple-touch-icon.png\"><link rel=\"manifest\" href=\"manifest.webmanifest\">",
  "<meta property=\"og:type\" content=\"website\"><meta property=\"og:site_name\" content=\"IoT Atlas\">",
  "<meta property=\"og:title\" content=\"IoT certification requirements by market | IoT Atlas\">",
  "<meta property=\"og:description\" content=\"Certification schemes by market: what applies, what it covers, who issues it and what to verify.\">",
  "<meta property=\"og:image\" content=\"" + SITE + "/assets/og-default.png\"><meta property=\"og:image:width\" content=\"1200\"><meta property=\"og:image:height\" content=\"630\">",
  "<meta property=\"og:locale\" content=\"en_US\"><meta property=\"og:locale:alternate\" content=\"es_ES\"><meta property=\"og:locale:alternate\" content=\"fr_FR\">",
  "<meta name=\"twitter:card\" content=\"summary_large_image\"><meta name=\"twitter:image\" content=\"" + SITE + "/assets/og-default.png\">",
  "<meta name=\"theme-color\" content=\"#0c7475\">",
  "<script type=\"application/ld+json\" data-generated=\"structured-data\">" + JSON.stringify({ "@context": "https://schema.org", "@graph": [
    { "@type": "CollectionPage", name: "IoT certification requirements by market", url: SITE + "/markets.html" },
    { "@type": "ItemList", numberOfItems: MARKETS.length, itemListElement: MARKETS.map((m, i) => ({ "@type": "ListItem", position: i + 1, name: m.en, url: SITE + "/market/" + m.slug + ".html" })) } ] }) + "</script>",
  "</head><body data-page=\"markets\">",
  "<a class=\"skip-link\" href=\"#main\">Skip to content</a><div id=\"site-header\"></div>",
  "<main id=\"main\"><section class=\"page-hero\"><div class=\"container\">",
  "<span class=\"eyebrow\">Market entry</span><h1>Certification requirements by market</h1>",
  "<p class=\"lede\">Pick the market you sell into: each page lists the schemes that apply, what they cover, what to prepare and the official sources.</p>",
  "</div></section>",
  "<section class=\"share-bar\" id=\"share-bar\"></section>",
  "<section class=\"section compact\"><div class=\"container\"><div class=\"card-grid\">",
  MARKETS.map((m) => { const l = marketCerts(m); return "<a class=\"card expanded-card\" href=\"market/" + m.slug + ".html\"><span class=\"pill blue\">" + l.length + " schemes</span><h3>" + esc(m.en) + "</h3><p>" + esc(m.lede.slice(0, 130)) + "</p><span class=\"text-link\">Open the market guide →</span></a>"; }).join(""),
  "</div></div></section>",
  "<section class=\"section compact\" id=\"share-cta\"></section>",
  "</main><div id=\"site-footer\"></div>",
  hubScripts.join(""),
  "</body></html>"
].join("\n");
fs.writeFileSync(path.join(PROTO, "markets.html"), hub.replace("</body>", NAV + "</body>"), "utf8");

/* sitemap.xml (root pages): the hub is written after build_seo, so add it here */
const rootSmPath = path.join(PROTO, "sitemap.xml");
if (fs.existsSync(rootSmPath)) {
  let rs = fs.readFileSync(rootSmPath, "utf8");
  if (!rs.includes("/markets.html")) {
    const alt = ["en", "es", "fr"].map((l) => '    <xhtml:link rel="alternate" hreflang="' + l + '" href="' + SITE + '/markets.html' + (l === "en" ? "" : "?lang=" + l) + '"/>').join("\n")
      + '\n    <xhtml:link rel="alternate" hreflang="x-default" href="' + SITE + '/markets.html"/>';
    rs = rs.replace("</urlset>", "  <url>\n    <loc>" + SITE + "/markets.html</loc>\n    <lastmod>" + TODAY + "</lastmod>\n    <changefreq>weekly</changefreq>\n    <priority>0.7</priority>\n" + alt + "\n  </url>\n</urlset>");
    fs.writeFileSync(rootSmPath, rs, "utf8");
  }
}

/* sitemap-entities: replace any previous market entries */
const smPath = path.join(PROTO, "sitemap-entities.xml");
if (fs.existsSync(smPath)) {
  let sm = fs.readFileSync(smPath, "utf8");
  sm = sm.replace(/  <url>\s*<loc>[^<]*\/market\/[^<]*<\/loc>[\s\S]*?<\/url>\s*/g, "");
  const block = urls.map((u) => "  <url>\n    <loc>" + u.loc + "</loc>\n    <lastmod>" + u.lastmod + "</lastmod>\n  </url>\n").join("");
  sm = sm.replace("</urlset>", block + "</urlset>");
  fs.writeFileSync(smPath, sm, "utf8");
}
console.log("market pages written: " + written + " + markets.html; sitemap-entities updated");
