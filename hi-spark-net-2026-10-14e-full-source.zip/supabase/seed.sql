-- IoT Atlas community seed - generated from assets/community-seed*.js
-- Threads: 40   Replies: 96
-- Safe to re-run.

alter table public.threads add column if not exists author_label text;
alter table public.threads add column if not exists is_seed boolean not null default false;
alter table public.threads alter column author_id drop not null;
alter table public.posts add column if not exists author_label text;
alter table public.posts add column if not exists is_seed boolean not null default false;
alter table public.posts alter column author_id drop not null;

create or replace view public.community_thread_feed as
  select t.id, t.slug, t.title, t.body, t.category, t.entity_type, t.entity_slug,
         t.reply_count, t.reaction_count, t.view_count, t.pinned, t.created_at,
         coalesce(p.handle, t.author_label, 'iotatlas_editorial') as author_handle,
         coalesce(p.display_name, t.author_label, 'IoT Atlas Editorial') as author_name,
         p.avatar_url as author_avatar, t.is_seed
    from public.threads t left join public.profiles p on p.id = t.author_id
   where t.status = 'published'
   order by t.pinned desc, t.created_at desc;

begin;

-- 1. Matter pairing fails on my Thread border router - what to check first
insert into public.threads (id, slug, title, body, category, entity_type, entity_slug, author_id, author_label, is_seed, created_at, updated_at)
values ('e2e995c0-c989-43b7-a279-e995c004c989', 'matter-pairing-fails-on-my-thread-border-router-what-to-check-first', 'Matter pairing fails on my Thread border router - what to check first', 'Commissioning keeps failing at the very last step. The device shows up in the controller but never finishes. Before I replace hardware, what is worth checking in order?', 'troubleshooting', 'protocol', 'matter', null, 'field_notes', true, now() - interval '40 days', now() - interval '40 days')
on conflict (slug) do update set body = excluded.body, category = excluded.category, updated_at = now();
insert into public.posts (id, thread_id, author_id, author_label, is_seed, body, created_at)
values ('94ebcc5e-b09b-433b-ab6b-ebcc5e04b09b', (select id from public.threads where slug = 'matter-pairing-fails-on-my-thread-border-router-what-to-check-first'), null, 'iotatlas_editorial', true, 'Work through it in this order. First confirm the controller and the device are on the same fabric - a device already commissioned by another ecosystem needs to be removed there first, not just unplugged. Second check that you have at least one Thread border router powered and on the same network as the controller. Third update both the controller app and the device firmware; early Matter firmware had commissioning bugs that were fixed later.', now() - interval '39 days') on conflict (id) do nothing;
insert into public.posts (id, thread_id, author_id, author_label, is_seed, body, created_at)
values ('95ebcdf0-b0ed-42e3-ab1d-ebcdf004b0ed', (select id from public.threads where slug = 'matter-pairing-fails-on-my-thread-border-router-what-to-check-first'), null, 'field_notes', true, 'Adding to that: Thread credentials matter more than people expect. If you have two border routers from different vendors they may be on separate Thread networks, and the device only joins one. Check the Thread network name and channel in the border router diagnostics.', now() - interval '38 days') on conflict (id) do nothing;
insert into public.posts (id, thread_id, author_id, author_label, is_seed, body, created_at)
values ('92ebc938-b13f-47f9-aacf-ebc93804b13f', (select id from public.threads where slug = 'matter-pairing-fails-on-my-thread-border-router-what-to-check-first'), null, 'iotatlas_editorial', true, 'If it still fails, test with a second ecosystem. If pairing works there, the fault is with the first controller, not the device. That single test saves a lot of guessing.', now() - interval '37 days') on conflict (id) do nothing;

-- 2. Reolink vs eufy for a 6-camera install with no subscription
insert into public.threads (id, slug, title, body, category, entity_type, entity_slug, author_id, author_label, is_seed, created_at, updated_at)
values ('18a9edfa-d457-49ad-afa7-a9edfa03d457', 'reolink-vs-eufy-for-a-6-camera-install-with-no-subscription', 'Reolink vs eufy for a 6-camera install with no subscription', 'Six outdoor cameras, want local recording, no monthly fee, and I would rather not run PoE to every corner. Which way would you go?', 'buying', 'brand', 'reolink', null, 'buyer_desk', true, now() - interval '39 days', now() - interval '39 days')
on conflict (slug) do update set body = excluded.body, category = excluded.category, updated_at = now();
insert into public.posts (id, thread_id, author_id, author_label, is_seed, body, created_at)
values ('9e4b5508-bddb-472d-a62b-4b550803bddb', (select id from public.threads where slug = 'reolink-vs-eufy-for-a-6-camera-install-with-no-subscription'), null, 'iotatlas_editorial', true, 'At six cameras the split usually comes down to wiring. If you can run cable to even two corners, a small NVR or PoE switch changes the whole cost curve and gives you continuous recording instead of event clips. If you cannot run cable anywhere, battery cameras with a HomeBase-style local store are the practical answer, and you accept event-only recording.', now() - interval '38 days') on conflict (id) do nothing;
insert into public.posts (id, thread_id, author_id, author_label, is_seed, body, created_at)
values ('9f4b569c-be23-4741-a5d3-4b569c03be23', (select id from public.threads where slug = 'reolink-vs-eufy-for-a-6-camera-install-with-no-subscription'), null, 'field_notes', true, 'Note the difference between ''local storage'' and ''continue recording during an internet outage''. Test that explicitly - some setups keep recording, others stop scheduling when the cloud is unreachable.', now() - interval '37 days') on conflict (id) do nothing;
insert into public.posts (id, thread_id, author_id, author_label, is_seed, body, created_at)
values ('a04b5830-be6b-49a5-a59b-4b583003be6b', (select id from public.threads where slug = 'reolink-vs-eufy-for-a-6-camera-install-with-no-subscription'), null, 'buyer_desk', true, 'Also budget the SD cards. Six cameras running event recording will chew through consumer cards. Use high-endurance cards or central storage.', now() - interval '36 days') on conflict (id) do nothing;

-- 3. Does using Tuya Smart and Smart Life split my account?
insert into public.threads (id, slug, title, body, category, entity_type, entity_slug, author_id, author_label, is_seed, created_at, updated_at)
values ('a908cea8-330f-4259-a8ff-08cea803330f', 'does-using-tuya-smart-and-smart-life-split-my-account', 'Does using Tuya Smart and Smart Life split my account?', 'I have some devices added in Tuya Smart and some in Smart Life. They are the same cloud, right? Should I consolidate?', 'compatibility', 'app', 'tuya-smart', null, 'iotatlas_editorial', true, now() - interval '38 days', now() - interval '38 days')
on conflict (slug) do update set body = excluded.body, category = excluded.category, updated_at = now();
insert into public.posts (id, thread_id, author_id, author_label, is_seed, body, created_at)
values ('ec71cb30-1f19-4bd7-a4e9-71cb30031f19', (select id from public.threads where slug = 'does-using-tuya-smart-and-smart-life-split-my-account'), null, 'iotatlas_editorial', true, 'Same backend, separate account surfaces. Devices added in one app do not automatically appear in the other unless you link the accounts. The practical rule: pick the app your device manuals point at and stay in it. Consolidating later means removing and re-adding devices, which loses scenes and automations.', now() - interval '37 days') on conflict (id) do nothing;
insert into public.posts (id, thread_id, author_id, author_label, is_seed, body, created_at)
values ('ed71ccc4-1f5c-4c68-a4ac-71ccc4031f5c', (select id from public.threads where slug = 'does-using-tuya-smart-and-smart-life-split-my-account'), null, 'field_notes', true, 'Worth checking before you buy more: some OEM apps are Tuya underneath but tie devices to their own account namespace. Those really do not cross over.', now() - interval '36 days') on conflict (id) do nothing;

-- 4. SPYPOINT cellular camera - realistic monthly data usage
insert into public.threads (id, slug, title, body, category, entity_type, entity_slug, author_id, author_label, is_seed, created_at, updated_at)
values ('38a6d198-5751-46c9-aca1-a6d198035751', 'spypoint-cellular-camera-realistic-monthly-data-usage', 'SPYPOINT cellular camera - realistic monthly data usage', 'Trying to size a data plan before I commit. How much does a cellular trail camera actually send per month?', 'buying', 'app', 'trail-cameras-spypoint', null, 'buyer_desk', true, now() - interval '37 days', now() - interval '37 days')
on conflict (slug) do update set body = excluded.body, category = excluded.category, updated_at = now();
insert into public.posts (id, thread_id, author_id, author_label, is_seed, body, created_at)
values ('d412fe30-4317-42d9-a8e7-12fe30034317', (select id from public.threads where slug = 'spypoint-cellular-camera-realistic-monthly-data-usage'), null, 'iotatlas_editorial', true, 'Depends almost entirely on your settings and how busy the site is. A camera sending a few dozen downsized photos a day sits in the low hundreds of MB per month. Bump to HD transfers, frequent triggers, or a windy location with moving branches and you can multiply that several times.', now() - interval '36 days') on conflict (id) do nothing;
insert into public.posts (id, thread_id, author_id, author_label, is_seed, body, created_at)
values ('d512ffc4-435b-4361-a8ab-12ffc403435b', (select id from public.threads where slug = 'spypoint-cellular-camera-realistic-monthly-data-usage'), null, 'field_notes', true, 'Set the trigger sensitivity conservatively for the first month and check actual usage before you lock a plan. False triggers from vegetation are the single biggest cause of bill shock.', now() - interval '35 days') on conflict (id) do nothing;

-- 5. MQTT QoS 1 is giving me duplicate readings in my dashboard
insert into public.threads (id, slug, title, body, category, entity_type, entity_slug, author_id, author_label, is_seed, created_at, updated_at)
values ('08446430-9bd3-4fe3-a023-446430039bd3', 'mqtt-qos-1-is-giving-me-duplicate-readings-in-my-dashboard', 'MQTT QoS 1 is giving me duplicate readings in my dashboard', 'My time-series chart shows two or three identical points in a row. I am publishing at QoS 1. Is the broker duplicating?', 'troubleshooting', 'protocol', 'mqtt', null, 'field_notes', true, now() - interval '36 days', now() - interval '36 days')
on conflict (slug) do update set body = excluded.body, category = excluded.category, updated_at = now();
insert into public.posts (id, thread_id, author_id, author_label, is_seed, body, created_at)
values ('4e2f7290-8799-4509-ac69-2f7290038799', (select id from public.threads where slug = 'mqtt-qos-1-is-giving-me-duplicate-readings-in-my-dashboard'), null, 'iotatlas_editorial', true, 'That is QoS 1 behaving exactly as specified - ''at least once'' means duplicates are allowed. The broker is not corrupting anything; your subscriber is expected to deduplicate. Add a message id or a monotonic sequence number to the payload and drop repeats on ingest.', now() - interval '35 days') on conflict (id) do nothing;
insert into public.posts (id, thread_id, author_id, author_label, is_seed, body, created_at)
values ('4f2f7424-87e0-43c4-ac10-2f74240387e0', (select id from public.threads where slug = 'mqtt-qos-1-is-giving-me-duplicate-readings-in-my-dashboard'), null, 'cloud_desk', true, 'If duplicates are unacceptable and your volume is low, QoS 2 solves it but costs an extra round trip per message. For telemetry at scale, QoS 0 plus application-level sequencing is usually cheaper than QoS 2.', now() - interval '34 days') on conflict (id) do nothing;
insert into public.posts (id, thread_id, author_id, author_label, is_seed, body, created_at)
values ('502f75b8-8827-4d9f-a3d7-2f75b8038827', (select id from public.threads where slug = 'mqtt-qos-1-is-giving-me-duplicate-readings-in-my-dashboard'), null, 'iotatlas_editorial', true, 'Also check whether you are subscribed to overlapping wildcards. Two matching subscriptions deliver every message twice, which looks identical to a QoS problem.', now() - interval '33 days') on conflict (id) do nothing;

-- 6. AWS IoT Core vs Tuya Cloud for a 5,000 device consumer fleet
insert into public.threads (id, slug, title, body, category, entity_type, entity_slug, author_id, author_label, is_seed, created_at, updated_at)
values ('fe30fe3c-95fb-4439-ae0b-30fe3c0395fb', 'aws-iot-core-vs-tuya-cloud-for-a-5-000-device-consumer-fleet', 'AWS IoT Core vs Tuya Cloud for a 5,000 device consumer fleet', 'We are launching a consumer product, roughly 5k devices in year one, mostly in Europe. Which platform shape fits better?', 'cloud', 'cloud', 'aws-aws-iot-core', null, 'cloud_desk', true, now() - interval '35 days', now() - interval '35 days')
on conflict (slug) do update set body = excluded.body, category = excluded.category, updated_at = now();
insert into public.posts (id, thread_id, author_id, author_label, is_seed, body, created_at)
values ('4e0826c0-8397-4557-a867-0826c0038397', (select id from public.threads where slug = 'aws-iot-core-vs-tuya-cloud-for-a-5-000-device-consumer-fleet'), null, 'cloud_desk', true, 'The decision is really build-versus-buy, not feature comparison. Tuya gets you a working consumer app, OTA and device onboarding in weeks, and you inherit their module supply chain. AWS gives you full control of the data model and no platform lock-in, but you own the app, the onboarding flow and the support burden.', now() - interval '34 days') on conflict (id) do nothing;
insert into public.posts (id, thread_id, author_id, author_label, is_seed, body, created_at)
values ('4f082850-83e0-4bb0-a810-0828500383e0', (select id from public.threads where slug = 'aws-iot-core-vs-tuya-cloud-for-a-5-000-device-consumer-fleet'), null, 'iotatlas_editorial', true, 'One EU-specific note: whichever way you go, confirm where the device data lands and whether you can keep it in an EU region. That constraint often decides the platform before cost does.', now() - interval '33 days') on conflict (id) do nothing;
insert into public.posts (id, thread_id, author_id, author_label, is_seed, body, created_at)
values ('4c082398-8429-47b1-afd9-082398038429', (select id from public.threads where slug = 'aws-iot-core-vs-tuya-cloud-for-a-5-000-device-consumer-fleet'), null, 'cloud_desk', true, 'Cost model warning: the headline per-device price is rarely the driver. Model messages, connections, storage, egress and support separately, then multiply for growth. The gap between the two options usually shows up in engineering headcount, not the invoice.', now() - interval '32 days') on conflict (id) do nothing;

-- 7. TLS certificate rotation bricked 40 devices - post-mortem notes
insert into public.threads (id, slug, title, body, category, entity_type, entity_slug, author_id, author_label, is_seed, created_at, updated_at)
values ('cb8b0a30-253d-40f3-aecd-8b0a3004253d', 'tls-certificate-rotation-bricked-40-devices-post-mortem-notes', 'TLS certificate rotation bricked 40 devices - post-mortem notes', 'We rotated our device certificates and 40 units stopped connecting. Sharing what we got wrong so others avoid it.', 'security', 'concept', 'device-identity', null, 'security_desk', true, now() - interval '34 days', now() - interval '34 days')
on conflict (slug) do update set body = excluded.body, category = excluded.category, updated_at = now();
insert into public.posts (id, thread_id, author_id, author_label, is_seed, body, created_at)
values ('276f4ef0-0e2b-40db-a5db-6f4ef0040e2b', (select id from public.threads where slug = 'tls-certificate-rotation-bricked-40-devices-post-mortem-notes'), null, 'security_desk', true, 'The classic failure: the new certificate was pushed over the existing secure channel, but the client was configured to trust only the new CA before the new leaf was actually accepted. Any device that rebooted mid-rotation came back with no working credential.', now() - interval '33 days') on conflict (id) do nothing;
insert into public.posts (id, thread_id, author_id, author_label, is_seed, body, created_at)
values ('286f5084-0e77-4ef3-a587-6f5084040e77', (select id from public.threads where slug = 'tls-certificate-rotation-bricked-40-devices-post-mortem-notes'), null, 'iotatlas_editorial', true, 'The fix is overlapping validity. Keep the old and new trust anchors both accepted for at least one full rotation cycle, and only remove the old one after you have measured 100% of devices reporting on the new credential.', now() - interval '32 days') on conflict (id) do nothing;
insert into public.posts (id, thread_id, author_id, author_label, is_seed, body, created_at)
values ('256f4bcc-0ec3-450f-a533-6f4bcc040ec3', (select id from public.threads where slug = 'tls-certificate-rotation-bricked-40-devices-post-mortem-notes'), null, 'cloud_desk', true, 'Add an alert on ''devices whose credential expires within 30 days''. If that alert exists, you never discover rotation failures from a customer report.', now() - interval '31 days') on conflict (id) do nothing;
insert into public.posts (id, thread_id, author_id, author_label, is_seed, body, created_at)
values ('266f4d60-0f0f-426f-a4ff-6f4d60040f0f', (select id from public.threads where slug = 'tls-certificate-rotation-bricked-40-devices-post-mortem-notes'), null, 'security_desk', true, 'And always stage the rotation on a canary cohort first. Forty devices is a bad day; forty thousand is a recall.', now() - interval '30 days') on conflict (id) do nothing;

-- 8. Retrofit lock or full deadbolt replacement for a rental?
insert into public.threads (id, slug, title, body, category, entity_type, entity_slug, author_id, author_label, is_seed, created_at, updated_at)
values ('3fb0c978-753c-4c44-aecc-b0c97803753c', 'retrofit-lock-or-full-deadbolt-replacement-for-a-rental', 'Retrofit lock or full deadbolt replacement for a rental?', 'I rent and cannot change the lock permanently. Is a retrofit smart lock actually worth it, or should I wait until I own a place?', 'buying', 'category', 'smart-locks', null, 'buyer_desk', true, now() - interval '33 days', now() - interval '33 days')
on conflict (slug) do update set body = excluded.body, category = excluded.category, updated_at = now();
insert into public.posts (id, thread_id, author_id, author_label, is_seed, body, created_at)
values ('0116f052-5f70-4f22-a480-16f052035f70', (select id from public.threads where slug = 'retrofit-lock-or-full-deadbolt-replacement-for-a-rental'), null, 'iotatlas_editorial', true, 'Retrofit is built for exactly your situation. It keeps the existing key cylinder, so your landlord''s key still works, and you can take it with you when you move. The trade-off is bulk on the inside face and a lower security ceiling than a certified deadbolt.', now() - interval '32 days') on conflict (id) do nothing;
insert into public.posts (id, thread_id, author_id, author_label, is_seed, body, created_at)
values ('0216f1e4-5fb5-4e51-a445-16f1e4035fb5', (select id from public.threads where slug = 'retrofit-lock-or-full-deadbolt-replacement-for-a-rental'), null, 'buyer_desk', true, 'Check the door''s backset and whether the interior thumb-turn is compatible before buying. That is where most retrofits get returned.', now() - interval '31 days') on conflict (id) do nothing;

-- 9. Doorbell camera in Germany - when do I need a DPIA?
insert into public.threads (id, slug, title, body, category, entity_type, entity_slug, author_id, author_label, is_seed, created_at, updated_at)
values ('22f9d998-9282-4b1a-a972-f9d998029282', 'doorbell-camera-in-germany-when-do-i-need-a-dpia', 'Doorbell camera in Germany - when do I need a DPIA?', 'Installing a video doorbell at a private house in Germany that films part of the pavement. Do I need a data protection impact assessment?', 'security', 'standard', 'gdpr', null, 'security_desk', true, now() - interval '32 days', now() - interval '32 days')
on conflict (slug) do update set body = excluded.body, category = excluded.category, updated_at = now();
insert into public.posts (id, thread_id, author_id, author_label, is_seed, body, created_at)
values ('be684e08-827e-438a-a98e-684e0802827e', (select id from public.threads where slug = 'doorbell-camera-in-germany-when-do-i-need-a-dpia'), null, 'security_desk', true, 'The trigger is systematic monitoring of a publicly accessible area. If the camera reliably captures the pavement or a shared corridor, you are likely in DPIA territory. If it is tightly masked to your own doorstep and the field of view is minimised, the assessment is much simpler.', now() - interval '31 days') on conflict (id) do nothing;
insert into public.posts (id, thread_id, author_id, author_label, is_seed, body, created_at)
values ('bf684f9c-82be-42de-a94e-684f9c0282be', (select id from public.threads where slug = 'doorbell-camera-in-germany-when-do-i-need-a-dpia'), null, 'iotatlas_editorial', true, 'Practical steps regardless: enable privacy masking so neighbouring property and as much public space as possible is excluded, set the shortest retention your use case allows, and put up the required signage. Document all three - that documentation is what you show if someone complains.', now() - interval '30 days') on conflict (id) do nothing;
insert into public.posts (id, thread_id, author_id, author_label, is_seed, body, created_at)
values ('c068512e-82fe-4c30-a90e-68512e0282fe', (select id from public.threads where slug = 'doorbell-camera-in-germany-when-do-i-need-a-dpia'), null, 'security_desk', true, 'This is general guidance, not legal advice. For a multi-unit building or anything commercial, get a local lawyer to review it.', now() - interval '29 days') on conflict (id) do nothing;

-- 10. Zigbee mesh drops out after adding 40 bulbs
insert into public.threads (id, slug, title, body, category, entity_type, entity_slug, author_id, author_label, is_seed, created_at, updated_at)
values ('29a4e3dc-2e93-4d4f-a563-a4e3dc022e93', 'zigbee-mesh-drops-out-after-adding-40-bulbs', 'Zigbee mesh drops out after adding 40 bulbs', 'Everything was stable at 15 devices. I added 40 bulbs and now random devices go unavailable for a few minutes at a time.', 'troubleshooting', 'protocol', 'zigbee', null, 'field_notes', true, now() - interval '31 days', now() - interval '31 days')
on conflict (slug) do update set body = excluded.body, category = excluded.category, updated_at = now();
insert into public.posts (id, thread_id, author_id, author_label, is_seed, body, created_at)
values ('6c2d9748-1e45-490d-a5b5-2d9748021e45', (select id from public.threads where slug = 'zigbee-mesh-drops-out-after-adding-40-bulbs'), null, 'field_notes', true, 'Check whether the bulbs are functioning as routers. Mains-powered Zigbee devices repeat, battery devices do not. If your new bulbs are repeating, you just drastically changed the mesh topology and the coordinator is re-learning routes.', now() - interval '30 days') on conflict (id) do nothing;
insert into public.posts (id, thread_id, author_id, author_label, is_seed, body, created_at)
values ('6d2d98dc-1e7d-46a1-a58d-2d98dc021e7d', (select id from public.threads where slug = 'zigbee-mesh-drops-out-after-adding-40-bulbs'), null, 'iotatlas_editorial', true, 'A few things help: give it 24-48 hours to settle before judging, make sure your coordinator is on a 2.4 GHz channel that does not overlap your Wi-Fi, and avoid putting all the routers physically in one room. Zigbee and Wi-Fi both live in 2.4 GHz and a badly chosen channel pair will look exactly like a mesh fault.', now() - interval '29 days') on conflict (id) do nothing;
insert into public.posts (id, thread_id, author_id, author_label, is_seed, body, created_at)
values ('6e2d9a70-1eb5-44c5-a545-2d9a70021eb5', (select id from public.threads where slug = 'zigbee-mesh-drops-out-after-adding-40-bulbs'), null, 'field_notes', true, 'Also watch device limits. Some consumer coordinators degrade well before the theoretical maximum. Spreading across two coordinators is often cleaner than fighting one.', now() - interval '28 days') on conflict (id) do nothing;

-- 11. NB-IoT vs LoRaWAN for a water metering pilot in a dense city
insert into public.threads (id, slug, title, body, category, entity_type, entity_slug, author_id, author_label, is_seed, created_at, updated_at)
values ('7f110d8c-b932-44be-a2c2-110d8c03b932', 'nb-iot-vs-lorawan-for-a-water-metering-pilot-in-a-dense-city', 'NB-IoT vs LoRaWAN for a water metering pilot in a dense city', '200 meters, deep indoor basements, need 10-year battery. Which technology would you pilot first?', 'cloud', 'protocol', 'lorawan', null, 'cloud_desk', true, now() - interval '30 days', now() - interval '30 days')
on conflict (slug) do update set body = excluded.body, category = excluded.category, updated_at = now();
insert into public.posts (id, thread_id, author_id, author_label, is_seed, body, created_at)
values ('198681ea-a536-44dc-aec6-8681ea03a536', (select id from public.threads where slug = 'nb-iot-vs-lorawan-for-a-water-metering-pilot-in-a-dense-city'), null, 'cloud_desk', true, 'Deep indoor plus 10-year battery points firmly at NB-IoT if you have operator coverage in those basements. Its link budget is the reason it exists. Verify coverage with an actual test device in the deepest basement you have before ordering anything.', now() - interval '29 days') on conflict (id) do nothing;
insert into public.posts (id, thread_id, author_id, author_label, is_seed, body, created_at)
values ('1a86837c-a57f-4603-ae8f-86837c03a57f', (select id from public.threads where slug = 'nb-iot-vs-lorawan-for-a-water-metering-pilot-in-a-dense-city'), null, 'iotatlas_editorial', true, 'LoRaWAN is cheaper per device and you control the network, but basement penetration is the weak point and you will need gateway placement you may not control. If the buildings are yours and you can place gateways, LoRaWAN becomes very attractive on cost.', now() - interval '28 days') on conflict (id) do nothing;
insert into public.posts (id, thread_id, author_id, author_label, is_seed, body, created_at)
values ('17867ec4-a5c8-4b0c-ae38-867ec403a5c8', (select id from public.threads where slug = 'nb-iot-vs-lorawan-for-a-water-metering-pilot-in-a-dense-city'), null, 'cloud_desk', true, 'Also model the data plan and the module cost over the full device life, not just year one. The cheaper module is often not the cheaper fleet.', now() - interval '27 days') on conflict (id) do nothing;

-- 12. Magic Home Pro controller stopped responding after a router swap
insert into public.threads (id, slug, title, body, category, entity_type, entity_slug, author_id, author_label, is_seed, created_at, updated_at)
values ('fcff1485-6bc4-40bf-a034-ff1485046bc4', 'magic-home-pro-controller-stopped-responding-after-a-router-swap', 'Magic Home Pro controller stopped responding after a router swap', 'Replaced my router, kept the same SSID and password, but the LED controller is now unreachable from the app.', 'troubleshooting', 'app', 'lighting-magic-home-pro', null, 'field_notes', true, now() - interval '29 days', now() - interval '29 days')
on conflict (slug) do update set body = excluded.body, category = excluded.category, updated_at = now();
insert into public.posts (id, thread_id, author_id, author_label, is_seed, body, created_at)
values ('797a6a58-52cc-4894-a93c-7a6a580452cc', (select id from public.threads where slug = 'magic-home-pro-controller-stopped-responding-after-a-router-swap'), null, 'field_notes', true, 'Same SSID is not always enough. If the new router hands out a different subnet, or is using WPA3 where the old one used WPA2, or has band steering forcing everything onto 5 GHz, these controllers will fail to reconnect. Put a dedicated 2.4 GHz SSID up and re-pair.', now() - interval '28 days') on conflict (id) do nothing;
insert into public.posts (id, thread_id, author_id, author_label, is_seed, body, created_at)
values ('7a7a6bec-5319-48f5-a8e9-7a6bec045319', (select id from public.threads where slug = 'magic-home-pro-controller-stopped-responding-after-a-router-swap'), null, 'iotatlas_editorial', true, 'Also check AP isolation. Some routers enable client isolation by default on guest networks. The phone and the controller have to be able to see each other locally for discovery to work.', now() - interval '27 days') on conflict (id) do nothing;

-- 13. Do companion audio apps actually add anything, or is it marketing?
insert into public.threads (id, slug, title, body, category, entity_type, entity_slug, author_id, author_label, is_seed, created_at, updated_at)
values ('a69def58-7e04-4ea4-a5f4-9def58047e04', 'do-companion-audio-apps-actually-add-anything-or-is-it-marketing', 'Do companion audio apps actually add anything, or is it marketing?', 'Looking at QCY, TOZO, soundcore, JBL and Sonos. Some have extensive apps and some barely need one. What is the app genuinely for?', 'buying', 'category', 'audio-headphones', null, 'buyer_desk', true, now() - interval '28 days', now() - interval '28 days')
on conflict (slug) do update set body = excluded.body, category = excluded.category, updated_at = now();
insert into public.posts (id, thread_id, author_id, author_label, is_seed, body, created_at)
values ('e846cb78-6590-4118-ae60-46cb78046590', (select id from public.threads where slug = 'do-companion-audio-apps-actually-add-anything-or-is-it-marketing'), null, 'buyer_desk', true, 'For earbuds the app is mostly EQ, ANC modes and firmware updates. EQ is the part that changes daily use; firmware updates are the part that fixes bugs you did not know you had. If the app is the only way to update firmware, it matters.', now() - interval '27 days') on conflict (id) do nothing;
insert into public.posts (id, thread_id, author_id, author_label, is_seed, body, created_at)
values ('e946cd0c-65df-472d-ae2f-46cd0c0465df', (select id from public.threads where slug = 'do-companion-audio-apps-actually-add-anything-or-is-it-marketing'), null, 'iotatlas_editorial', true, 'For multiroom speakers the calculus is completely different. Sonos and similar systems are essentially an app product with a speaker attached - grouping, room assignment and streaming accounts all live in the app. There the app is not a bonus, it is the product.', now() - interval '26 days') on conflict (id) do nothing;
insert into public.posts (id, thread_id, author_id, author_label, is_seed, body, created_at)
values ('ea46cea0-662e-4772-adde-46cea004662e', (select id from public.threads where slug = 'do-companion-audio-apps-actually-add-anything-or-is-it-marketing'), null, 'field_notes', true, 'One practical check: install the app before you buy and read the recent reviews mentioning firmware. A headphone with no update path is a headphone with whatever bugs it shipped with.', now() - interval '25 days') on conflict (id) do nothing;

-- 14. Aqara U200 with Apple Home keys - does it really work day to day
insert into public.threads (id, slug, title, body, category, entity_type, entity_slug, author_id, author_label, is_seed, created_at, updated_at)
values ('481c3f37-0e7d-414a-a58d-1c3f37040e7d', 'aqara-u200-with-apple-home-keys-does-it-really-work-day-to-day', 'Aqara U200 with Apple Home keys - does it really work day to day', 'Interested in the U200 specifically for the Apple Home key feature. Anyone using it as their daily lock rather than a demo?', 'compatibility', 'app', 'smart-locks-aqara-home-locks', null, 'iotatlas_editorial', true, now() - interval '27 days', now() - interval '27 days')
on conflict (slug) do update set body = excluded.body, category = excluded.category, updated_at = now();
insert into public.posts (id, thread_id, author_id, author_label, is_seed, body, created_at)
values ('b8239de4-fa11-480b-a1e1-239de403fa11', (select id from public.threads where slug = 'aqara-u200-with-apple-home-keys-does-it-really-work-day-to-day'), null, 'iotatlas_editorial', true, 'Reported experience is that the Home key tap works well once provisioned, but the provisioning step is where people get stuck. You need a HomePod or Apple TV as a home hub on the same network, and you need to add the lock through the Aqara app first, then expose it to Apple Home. Adding it directly usually results in a lock that is visible but not tap-capable.', now() - interval '26 days') on conflict (id) do nothing;
insert into public.posts (id, thread_id, author_id, author_label, is_seed, body, created_at)
values ('b9239f78-fa5e-4ada-a1ae-239f7803fa5e', (select id from public.threads where slug = 'aqara-u200-with-apple-home-keys-does-it-really-work-day-to-day'), null, 'field_notes', true, 'Also keep a physical key or keypad code configured. Any smart lock that depends on a cloud or hub round trip will eventually be a lock you cannot open.', now() - interval '25 days') on conflict (id) do nothing;

-- 15. Best presence sensor for a bathroom - PIR keeps switching the light off
insert into public.threads (id, slug, title, body, category, entity_type, entity_slug, author_id, author_label, is_seed, created_at, updated_at)
values ('6f794288-ff12-4d9a-a4e2-79428804ff12', 'best-presence-sensor-for-a-bathroom-pir-keeps-switching-the-light-off', 'Best presence sensor for a bathroom - PIR keeps switching the light off', 'PIR sensor turns the bathroom light off while I am still in there because I am not moving enough. Is mmWave the answer?', 'buying', 'concept', 'pir-vs-radar', null, 'buyer_desk', true, now() - interval '26 days', now() - interval '26 days')
on conflict (slug) do update set body = excluded.body, category = excluded.category, updated_at = now();
insert into public.posts (id, thread_id, author_id, author_label, is_seed, body, created_at)
values ('328f8048-e5e2-45aa-ae12-8f804804e5e2', (select id from public.threads where slug = 'best-presence-sensor-for-a-bathroom-pir-keeps-switching-the-light-off'), null, 'iotatlas_editorial', true, 'Yes, this is the textbook mmWave use case. PIR detects motion, not presence. Sitting still or reading means no motion, so the light goes off. mmWave radar detects micro-motion including breathing, so it holds presence while you are stationary.', now() - interval '25 days') on conflict (id) do nothing;
insert into public.posts (id, thread_id, author_id, author_label, is_seed, body, created_at)
values ('338f81dc-e636-47ea-adc6-8f81dc04e636', (select id from public.threads where slug = 'best-presence-sensor-for-a-bathroom-pir-keeps-switching-the-light-off'), null, 'buyer_desk', true, 'Two practical warnings. Radar can see through drywall and thin doors, so it may trigger from the corridor - lower the sensitivity and set the detection range short. And some units run hot; check reviews for noise and heat before putting one in a small room.', now() - interval '24 days') on conflict (id) do nothing;

-- 16. ONVIF PTZ camera with Blue Iris - what actually needs checking
insert into public.threads (id, slug, title, body, category, entity_type, entity_slug, author_id, author_label, is_seed, created_at, updated_at)
values ('e79219f7-f910-4f19-a2e0-9219f703f910', 'onvif-ptz-camera-with-blue-iris-what-actually-needs-checking', 'ONVIF PTZ camera with Blue Iris - what actually needs checking', 'Trying to add a PTZ camera to Blue Iris over ONVIF. Video works but PTZ controls do nothing.', 'compatibility', 'protocol', 'nvr-dvr', null, 'field_notes', true, now() - interval '25 days', now() - interval '25 days')
on conflict (slug) do update set body = excluded.body, category = excluded.category, updated_at = now();
insert into public.posts (id, thread_id, author_id, author_label, is_seed, body, created_at)
values ('c606af7a-e432-44b8-afc2-06af7a03e432', (select id from public.threads where slug = 'onvif-ptz-camera-with-blue-iris-what-actually-needs-checking'), null, 'field_notes', true, 'Video over ONVIF and PTZ over ONVIF are separate profiles. A camera can advertise profile S for streaming and not implement the PTZ service properly. Check the camera''s ONVIF device manager output to confirm the PTZ service is actually advertised.', now() - interval '24 days') on conflict (id) do nothing;
insert into public.posts (id, thread_id, author_id, author_label, is_seed, body, created_at)
values ('c706b10c-e47d-4a8f-af8d-06b10c03e47d', (select id from public.threads where slug = 'onvif-ptz-camera-with-blue-iris-what-actually-needs-checking'), null, 'iotatlas_editorial', true, 'Second common cause is the ONVIF user. Many cameras have a separate ONVIF account from the web UI admin, and PTZ requires the media user to have operator-level rights. Creating a dedicated ONVIF user with full rights fixes a surprising number of these.', now() - interval '23 days') on conflict (id) do nothing;
insert into public.posts (id, thread_id, author_id, author_label, is_seed, body, created_at)
values ('c406ac54-e4c8-4764-af38-06ac5403e4c8', (select id from public.threads where slug = 'onvif-ptz-camera-with-blue-iris-what-actually-needs-checking'), null, 'field_notes', true, 'If it still fails, try the manufacturer-specific driver in Blue Iris instead of generic ONVIF. Vendor drivers often implement PTZ over the native API rather than the ONVIF service.', now() - interval '22 days') on conflict (id) do nothing;

-- 17. eSIM or physical SIM for a 2,000 unit fleet in Brazil
insert into public.threads (id, slug, title, body, category, entity_type, entity_slug, author_id, author_label, is_seed, created_at, updated_at)
values ('a44542a0-d761-4a3f-ac91-4542a002d761', 'esim-or-physical-sim-for-a-2-000-unit-fleet-in-brazil', 'eSIM or physical SIM for a 2,000 unit fleet in Brazil', 'Deploying trackers in Brazil. Trying to decide between soldered eSIM and a physical SIM tray.', 'cloud', 'protocol', 'esim', null, 'cloud_desk', true, now() - interval '24 days', now() - interval '24 days')
on conflict (slug) do update set body = excluded.body, category = excluded.category, updated_at = now();
insert into public.posts (id, thread_id, author_id, author_label, is_seed, body, created_at)
values ('3fb64fc0-c73b-48fb-accb-b64fc002c73b', (select id from public.threads where slug = 'esim-or-physical-sim-for-a-2-000-unit-fleet-in-brazil'), null, 'cloud_desk', true, 'At 2,000 units the operational saving from eSIM is real but it depends on your failure rate. A physical SIM means any connectivity problem becomes a truck roll. An eSIM lets you reprovision over the air, which turns most of those into a support ticket.', now() - interval '23 days') on conflict (id) do nothing;
insert into public.posts (id, thread_id, author_id, author_label, is_seed, body, created_at)
values ('40b65154-c77d-4629-ac8d-b6515402c77d', (select id from public.threads where slug = 'esim-or-physical-sim-for-a-2-000-unit-fleet-in-brazil'), null, 'iotatlas_editorial', true, 'Check two things first. One, whether your chosen eSIM provider supports remote provisioning to the local carriers you need in Brazil - coverage there is carrier-specific, not generic roaming. Two, permanent roaming restrictions: some Brazilian carriers will cut off a permanently roamed SIM after a few months.', now() - interval '22 days') on conflict (id) do nothing;
insert into public.posts (id, thread_id, author_id, author_label, is_seed, body, created_at)
values ('41b652e8-c7bf-4557-ac4f-b652e802c7bf', (select id from public.threads where slug = 'esim-or-physical-sim-for-a-2-000-unit-fleet-in-brazil'), null, 'cloud_desk', true, 'Also confirm the module actually supports the bands used locally. That catches more deployments than the SIM form factor does.', now() - interval '21 days') on conflict (id) do nothing;

-- 18. Solar camera in a shaded courtyard - what worked and what did not
insert into public.threads (id, slug, title, body, category, entity_type, entity_slug, author_id, author_label, is_seed, created_at, updated_at)
values ('b950482c-4989-4e5b-a279-50482c044989', 'solar-camera-in-a-shaded-courtyard-what-worked-and-what-did-not', 'Solar camera in a shaded courtyard - what worked and what did not', 'Courtyard gets maybe two hours of direct sun in winter. Solar camera is struggling. Sharing what I tried.', 'general', 'category', 'security-cameras', null, 'field_notes', true, now() - interval '23 days', now() - interval '23 days')
on conflict (slug) do update set body = excluded.body, category = excluded.category, updated_at = now();
insert into public.posts (id, thread_id, author_id, author_label, is_seed, body, created_at)
values ('57a98e60-328b-4ceb-a97b-a98e6004328b', (select id from public.threads where slug = 'solar-camera-in-a-shaded-courtyard-what-worked-and-what-did-not'), null, 'field_notes', true, 'Two hours of winter sun is genuinely not enough for most integrated solar cameras. The panel is sized for the summer case. What worked for me was separating the panel from the camera and running a cable to a roof position that gets sun all day.', now() - interval '22 days') on conflict (id) do nothing;
insert into public.posts (id, thread_id, author_id, author_label, is_seed, body, created_at)
values ('58a98ff0-32d9-4d29-a929-a98ff00432d9', (select id from public.threads where slug = 'solar-camera-in-a-shaded-courtyard-what-worked-and-what-did-not'), null, 'iotatlas_editorial', true, 'If you cannot relocate the panel, reduce the camera''s duty cycle instead of fighting physics. Lower the resolution on event clips, shorten clip length, cut the pre-roll, and disable continuous live view in the app. Those four changes typically halve consumption.', now() - interval '21 days') on conflict (id) do nothing;
insert into public.posts (id, thread_id, author_id, author_label, is_seed, body, created_at)
values ('55a98b38-3327-481f-a8d7-a98b38043327', (select id from public.threads where slug = 'solar-camera-in-a-shaded-courtyard-what-worked-and-what-did-not'), null, 'field_notes', true, 'And check the panel is not being shaded by its own mounting bracket or a window frame at the low winter sun angle. I have made that mistake.', now() - interval '20 days') on conflict (id) do nothing;

-- 19. NIIMBOT or Brother P-touch for cable labelling
insert into public.threads (id, slug, title, body, category, entity_type, entity_slug, author_id, author_label, is_seed, created_at, updated_at)
values ('e5a6d555-7805-42b0-a3f5-a6d555027805', 'niimbot-or-brother-p-touch-for-cable-labelling', 'NIIMBOT or Brother P-touch for cable labelling', 'Need to label a rack of network cables. Small labels, needs to survive handling. Which ecosystem?', 'buying', 'app', 'label-printers-brother-p-touch-design-print', null, 'buyer_desk', true, now() - interval '22 days', now() - interval '22 days')
on conflict (slug) do update set body = excluded.body, category = excluded.category, updated_at = now();
insert into public.posts (id, thread_id, author_id, author_label, is_seed, body, created_at)
values ('f84bc032-6783-484f-ac73-4bc032026783', (select id from public.threads where slug = 'niimbot-or-brother-p-touch-for-cable-labelling'), null, 'buyer_desk', true, 'For cable labelling the deciding factor is label material and tape width, not the printer. Heat-shrink and flexible nylon tapes are what survive handling and abrasion. Check which of your two candidates offers the compatible tape in the widths your cables need.', now() - interval '21 days') on conflict (id) do nothing;
insert into public.posts (id, thread_id, author_id, author_label, is_seed, body, created_at)
values ('f94bc1c5-67be-4985-ac4e-4bc1c50267be', (select id from public.threads where slug = 'niimbot-or-brother-p-touch-for-cable-labelling'), null, 'iotatlas_editorial', true, 'Brother has the deeper tape catalogue including heat-shrink; NIIMBOT is cheaper per label and the app is faster for short text. If you are labelling a rack once, either works. If labelling is ongoing maintenance, buy for the tape range.', now() - interval '20 days') on conflict (id) do nothing;
insert into public.posts (id, thread_id, author_id, author_label, is_seed, body, created_at)
values ('f64bbd0c-67f9-450b-ac09-4bbd0c0267f9', (select id from public.threads where slug = 'niimbot-or-brother-p-touch-for-cable-labelling'), null, 'field_notes', true, 'One gotcha: check the minimum label length your app allows. Some apps force a minimum that makes flag-style cable labels impossible on thin cables.', now() - interval '19 days') on conflict (id) do nothing;

-- 20. Trail camera SD cards that actually survive a winter
insert into public.threads (id, slug, title, body, category, entity_type, entity_slug, author_id, author_label, is_seed, created_at, updated_at)
values ('0b1753cb-1c20-4feb-a7d0-1753cb031c20', 'trail-camera-sd-cards-that-actually-survive-a-winter', 'Trail camera SD cards that actually survive a winter', 'Two cards failed last winter in the same camera. Both were standard consumer cards. What should I be using?', 'troubleshooting', 'category', 'trail-cameras', null, 'field_notes', true, now() - interval '21 days', now() - interval '21 days')
on conflict (slug) do update set body = excluded.body, category = excluded.category, updated_at = now();
insert into public.posts (id, thread_id, author_id, author_label, is_seed, body, created_at)
values ('e4cc7fd8-07ee-47ca-ac1e-cc7fd80307ee', (select id from public.threads where slug = 'trail-camera-sd-cards-that-actually-survive-a-winter'), null, 'field_notes', true, 'High-endurance cards, and specifically ones rated for temperature. Standard cards are rated to roughly 0 degrees C for operation; below that the controller can fail to write even if the flash itself survives. That is why they die in winter and work fine in summer.', now() - interval '20 days') on conflict (id) do nothing;
insert into public.posts (id, thread_id, author_id, author_label, is_seed, body, created_at)
values ('e5cc816c-082f-46bd-a3df-cc816c03082f', (select id from public.threads where slug = 'trail-camera-sd-cards-that-actually-survive-a-winter'), null, 'iotatlas_editorial', true, 'Also set the camera to overwrite the oldest files rather than filling the card. A card that reaches full and stays full is under continuous write pressure at the worst moment, and loop recording distributes writes more evenly.', now() - interval '19 days') on conflict (id) do nothing;
insert into public.posts (id, thread_id, author_id, author_label, is_seed, body, created_at)
values ('e6cc8300-0870-4490-a380-cc8300030870', (select id from public.threads where slug = 'trail-camera-sd-cards-that-actually-survive-a-winter'), null, 'field_notes', true, 'And format the card in the camera, not on your computer. Cameras are picky about cluster size, and formatting elsewhere is a common cause of cards that work on a laptop but not in the camera.', now() - interval '18 days') on conflict (id) do nothing;

-- 21. Thermal labels fade outdoors - is it the paper or the printer
insert into public.threads (id, slug, title, body, category, entity_type, entity_slug, author_id, author_label, is_seed, created_at, updated_at)
values ('b2109d30-e8d6-4a1a-a326-109d3003e8d6', 'thermal-labels-fade-outdoors-is-it-the-paper-or-the-printer', 'Thermal labels fade outdoors - is it the paper or the printer', 'Using a Bluetooth label printer for plant markers and cable tags. The first batch faded to blank in about four months.', 'buying', 'category', 'label-printers', null, 'buyer_desk', true, now() - interval '20 days', now() - interval '20 days')
on conflict (slug) do update set body = excluded.body, category = excluded.category, updated_at = now();
insert into public.posts (id, thread_id, author_id, author_label, is_seed, body, created_at)
values ('ad4bd328-d284-4e54-a974-4bd32803d284', (select id from public.threads where slug = 'thermal-labels-fade-outdoors-is-it-the-paper-or-the-printer'), null, 'iotatlas_editorial', true, 'Almost always the paper. Direct thermal print is heat-sensitive and fades with UV and abrasion. For anything outdoors or handled daily you want thermal transfer with a wax-resin ribbon, or a synthetic stock rated for UV.', now() - interval '19 days') on conflict (id) do nothing;
insert into public.posts (id, thread_id, author_id, author_label, is_seed, body, created_at)
values ('ae4bd4bb-d2ce-498b-a93e-4bd4bb03d2ce', (select id from public.threads where slug = 'thermal-labels-fade-outdoors-is-it-the-paper-or-the-printer'), null, 'field_notes', true, 'Quick test: put one label on a windowsill for a month. If it fades there it will fade on the plant marker too.', now() - interval '18 days') on conflict (id) do nothing;
insert into public.posts (id, thread_id, author_id, author_label, is_seed, body, created_at)
values ('af4bd64e-d318-4aaa-a8e8-4bd64e03d318', (select id from public.threads where slug = 'thermal-labels-fade-outdoors-is-it-the-paper-or-the-printer'), null, 'buyer_desk', true, 'Check the adhesive as well as the face stock. Acrylic adhesive handles cold and damp; rubber adhesive is cheaper and lets go in a freezer.', now() - interval '17 days') on conflict (id) do nothing;

-- 22. Mini thermal printer pairs but prints nothing
insert into public.threads (id, slug, title, body, category, entity_type, entity_slug, author_id, author_label, is_seed, created_at, updated_at)
values ('62cefc3c-8de3-41df-a613-cefc3c028de3', 'mini-thermal-printer-pairs-but-prints-nothing', 'Mini thermal printer pairs but prints nothing', 'The app says connected but every job comes out blank or disappears.', 'troubleshooting', 'category', 'label-printers', null, 'field_notes', true, now() - interval '19 days', now() - interval '19 days')
on conflict (slug) do update set body = excluded.body, category = excluded.category, updated_at = now();
insert into public.posts (id, thread_id, author_id, author_label, is_seed, body, created_at)
values ('182edae4-7a9b-407f-a16b-2edae4027a9b', (select id from public.threads where slug = 'mini-thermal-printer-pairs-but-prints-nothing'), null, 'field_notes', true, 'Blank output usually means the paper is loaded upside down. Direct thermal paper only prints on the coated side.', now() - interval '18 days') on conflict (id) do nothing;
insert into public.posts (id, thread_id, author_id, author_label, is_seed, body, created_at)
values ('192edc78-7ad5-46ad-a125-2edc78027ad5', (select id from public.threads where slug = 'mini-thermal-printer-pairs-but-prints-nothing'), null, 'iotatlas_editorial', true, 'If the job vanishes entirely it is a link problem, not a print problem. Forget the printer in system settings, remove it in the app, then pair from inside the app. Many of these printers only accept pairing started by their own app.', now() - interval '17 days') on conflict (id) do nothing;

-- 23. Do I need a label printer, or is a normal printer with label sheets enough
insert into public.threads (id, slug, title, body, category, entity_type, entity_slug, author_id, author_label, is_seed, created_at, updated_at)
values ('b6b2d85c-7713-40b1-ace3-b2d85c057713', 'do-i-need-a-label-printer-or-is-a-normal-printer-with-label-sheets-eno', 'Do I need a label printer, or is a normal printer with label sheets enough', 'Trying to justify a dedicated label printer for home organisation and shipping.', 'buying', 'category', 'label-printers', null, 'iotatlas_editorial', true, now() - interval '18 days', now() - interval '18 days')
on conflict (slug) do update set body = excluded.body, category = excluded.category, updated_at = now();
insert into public.posts (id, thread_id, author_id, author_label, is_seed, body, created_at)
values ('46167bd0-5d87-4657-a677-167bd0055d87', (select id from public.threads where slug = 'do-i-need-a-label-printer-or-is-a-normal-printer-with-label-sheets-eno'), null, 'buyer_desk', true, 'For address and shipping labels, a laser printer with sheet labels is cheaper per label and sharper. A dedicated printer wins for odd shapes, one-off lengths, or when you print a few at a time and hate wasting a sheet.', now() - interval '17 days') on conflict (id) do nothing;
insert into public.posts (id, thread_id, author_id, author_label, is_seed, body, created_at)
values ('47167d60-5dde-40be-a62e-167d60055dde', (select id from public.threads where slug = 'do-i-need-a-label-printer-or-is-a-normal-printer-with-label-sheets-eno'), null, 'iotatlas_editorial', true, 'Volume and hands-free use decide it. A thermal printer removes the trim step entirely, which matters at twenty parcels rather than two.', now() - interval '16 days') on conflict (id) do nothing;

-- 24. Network printer keeps disappearing from the app
insert into public.threads (id, slug, title, body, category, entity_type, entity_slug, author_id, author_label, is_seed, created_at, updated_at)
values ('88d65d50-ada6-4f0a-a656-d65d5002ada6', 'network-printer-keeps-disappearing-from-the-app', 'Network printer keeps disappearing from the app', 'Works for a day, then goes offline in the app until I power-cycle it.', 'troubleshooting', 'category', 'label-printers', null, 'cloud_desk', true, now() - interval '17 days', now() - interval '17 days')
on conflict (slug) do update set body = excluded.body, category = excluded.category, updated_at = now();
insert into public.posts (id, thread_id, author_id, author_label, is_seed, body, created_at)
values ('00ff320e-99ca-4bc4-a23a-ff320e0299ca', (select id from public.threads where slug = 'network-printer-keeps-disappearing-from-the-app'), null, 'cloud_desk', true, 'Give the printer a static IP or a DHCP reservation. Most apps remember the printer by IP, so when the lease changes the app loses it even though the printer is online. This fixes most cases.', now() - interval '16 days') on conflict (id) do nothing;
insert into public.posts (id, thread_id, author_id, author_label, is_seed, body, created_at)
values ('01ff33a0-9a06-49a6-a1f6-ff33a0029a06', (select id from public.threads where slug = 'network-printer-keeps-disappearing-from-the-app'), null, 'field_notes', true, 'Also check sleep settings. Many printers drop Wi-Fi in deep sleep and wake slower than the app waits.', now() - interval '15 days') on conflict (id) do nothing;

-- 25. Mobile print: brand app or the Android print service
insert into public.threads (id, slug, title, body, category, entity_type, entity_slug, author_id, author_label, is_seed, created_at, updated_at)
values ('20c808eb-1321-4bca-a8d1-c808eb031321', 'mobile-print-brand-app-or-the-android-print-service', 'Mobile print: brand app or the Android print service', 'There seem to be two ways to print from a phone. Which one do I set up?', 'compatibility', 'category', 'label-printers', null, 'iotatlas_editorial', true, now() - interval '16 days', now() - interval '16 days')
on conflict (slug) do update set body = excluded.body, category = excluded.category, updated_at = now();
insert into public.posts (id, thread_id, author_id, author_label, is_seed, body, created_at)
values ('5c9166f0-ff2d-49dd-a4dd-9166f002ff2d', (select id from public.threads where slug = 'mobile-print-brand-app-or-the-android-print-service'), null, 'iotatlas_editorial', true, 'Install both. The print service makes the printer appear in the standard share and print menu from any app. The manufacturer app adds ink levels, head cleaning, scanning and paper profiles.', now() - interval '15 days') on conflict (id) do nothing;
insert into public.posts (id, thread_id, author_id, author_label, is_seed, body, created_at)
values ('5d916884-ff6e-47ea-a49e-91688402ff6e', (select id from public.threads where slug = 'mobile-print-brand-app-or-the-android-print-service'), null, 'field_notes', true, 'If you only install one, install the print service. It works with more apps and is what you reach for when printing a PDF in a hurry.', now() - interval '14 days') on conflict (id) do nothing;

-- 26. LDAC, aptX or AAC - can you actually hear the difference
insert into public.threads (id, slug, title, body, category, entity_type, entity_slug, author_id, author_label, is_seed, created_at, updated_at)
values ('09ea8fb0-4dd5-4265-a625-ea8fb0034dd5', 'ldac-aptx-or-aac-can-you-actually-hear-the-difference', 'LDAC, aptX or AAC - can you actually hear the difference', 'Every spec sheet pushes a different codec. Does it matter in practice?', 'buying', 'category', 'audio-headphones', null, 'buyer_desk', true, now() - interval '15 days', now() - interval '15 days')
on conflict (slug) do update set body = excluded.body, category = excluded.category, updated_at = now();
insert into public.posts (id, thread_id, author_id, author_label, is_seed, body, created_at)
values ('c831c456-3c05-47ad-a7f5-31c456033c05', (select id from public.threads where slug = 'ldac-aptx-or-aac-can-you-actually-hear-the-difference'), null, 'iotatlas_editorial', true, 'Less than the marketing suggests, and it needs both ends to support it. In a busy 2.4 GHz environment a higher codec often drops to a lower rate anyway.', now() - interval '14 days') on conflict (id) do nothing;
insert into public.posts (id, thread_id, author_id, author_label, is_seed, body, created_at)
values ('c931c5e9-3c4a-465d-a7ba-31c5e9033c4a', (select id from public.threads where slug = 'ldac-aptx-or-aac-can-you-actually-hear-the-difference'), null, 'field_notes', true, 'Driver and fit matter more. Two earbuds with the same codec can differ by several dB in bass purely from the seal.', now() - interval '13 days') on conflict (id) do nothing;

-- 27. Multiroom audio - Sonos, WiiM or BluOS
insert into public.threads (id, slug, title, body, category, entity_type, entity_slug, author_id, author_label, is_seed, created_at, updated_at)
values ('943cc98d-bba0-4dd3-a050-3cc98d01bba0', 'multiroom-audio-sonos-wiim-or-bluos', 'Multiroom audio - Sonos, WiiM or BluOS', 'Building whole-home audio and want to avoid a dead-end ecosystem.', 'buying', 'category', 'audio-headphones', null, 'cloud_desk', true, now() - interval '14 days', now() - interval '14 days')
on conflict (slug) do update set body = excluded.body, category = excluded.category, updated_at = now();
insert into public.posts (id, thread_id, author_id, author_label, is_seed, body, created_at)
values ('cc963260-adae-4032-a65e-96326001adae', (select id from public.threads where slug = 'multiroom-audio-sonos-wiim-or-bluos'), null, 'cloud_desk', true, 'All three synchronise reliably. The real question is lock-in. Sonos is the most polished and the most closed. WiiM is the cheapest entry and speaks AirPlay, Chromecast and DLNA. BluOS sits between.', now() - interval '13 days') on conflict (id) do nothing;
insert into public.posts (id, thread_id, author_id, author_label, is_seed, body, created_at)
values ('cd9633f4-ade1-41eb-a611-9633f401ade1', (select id from public.threads where slug = 'multiroom-audio-sonos-wiim-or-bluos'), null, 'iotatlas_editorial', true, 'If you already own speakers you like, a streamer plus your existing amplifier is the least wasteful path.', now() - interval '12 days') on conflict (id) do nothing;

-- 28. Headset microphone not detected on a desktop
insert into public.threads (id, slug, title, body, category, entity_type, entity_slug, author_id, author_label, is_seed, created_at, updated_at)
values ('d4ba5ad8-63b5-4693-a845-ba5ad80263b5', 'headset-microphone-not-detected-on-a-desktop', 'Headset microphone not detected on a desktop', 'Works on the phone, but the PC sees headphones and no microphone.', 'troubleshooting', 'category', 'audio-headphones', null, 'field_notes', true, now() - interval '13 days', now() - interval '13 days')
on conflict (slug) do update set body = excluded.body, category = excluded.category, updated_at = now();
insert into public.posts (id, thread_id, author_id, author_label, is_seed, body, created_at)
values ('dab0e16c-5187-4f15-aa77-b0e16c025187', (select id from public.threads where slug = 'headset-microphone-not-detected-on-a-desktop'), null, 'field_notes', true, 'Check the connector. A single 4-pole TRRS plug needs a splitter on a desktop with separate pink and green jacks. A TRRS plug in a TRS socket gives audio out and no mic, exactly your symptom.', now() - interval '12 days') on conflict (id) do nothing;
insert into public.posts (id, thread_id, author_id, author_label, is_seed, body, created_at)
values ('dbb0e2ff-51c0-4cc1-aa30-b0e2ff0251c0', (select id from public.threads where slug = 'headset-microphone-not-detected-on-a-desktop'), null, 'iotatlas_editorial', true, 'If it is USB or wireless, check the input device in both the OS sound settings and inside the game or app. Applications often override the system default.', now() - interval '11 days') on conflict (id) do nothing;

-- 29. Do you need a separate DAC for a phone
insert into public.threads (id, slug, title, body, category, entity_type, entity_slug, author_id, author_label, is_seed, created_at, updated_at)
values ('73967e18-c074-4e6c-ab84-967e1801c074', 'do-you-need-a-separate-dac-for-a-phone', 'Do you need a separate DAC for a phone', 'Portable DAC dongles are everywhere. Real improvement or audiophile tax?', 'buying', 'category', 'audio-headphones', null, 'iotatlas_editorial', true, now() - interval '12 days', now() - interval '12 days')
on conflict (slug) do update set body = excluded.body, category = excluded.category, updated_at = now();
insert into public.posts (id, thread_id, author_id, author_label, is_seed, body, created_at)
values ('9ee57608-b2ec-4b1c-a91c-e5760801b2ec', (select id from public.threads where slug = 'do-you-need-a-separate-dac-for-a-phone'), null, 'buyer_desk', true, 'It depends what you are driving. For low-impedance earbuds a modern phone output is usually transparent. A DAC earns its place with high-impedance headphones, audible hiss, or when you need more headroom.', now() - interval '11 days') on conflict (id) do nothing;
insert into public.posts (id, thread_id, author_id, author_label, is_seed, body, created_at)
values ('9fe57798-b31f-4b79-a8ef-e5779801b31f', (select id from public.threads where slug = 'do-you-need-a-separate-dac-for-a-phone'), null, 'iotatlas_editorial', true, 'Try before you buy. The measurable differences are real but small, and often below the threshold where most people notice.', now() - interval '10 days') on conflict (id) do nothing;

-- 30. Smart speakers and privacy - what actually gets sent
insert into public.threads (id, slug, title, body, category, entity_type, entity_slug, author_id, author_label, is_seed, created_at, updated_at)
values ('b1cedbc4-15fe-41c6-ae0e-cedbc40315fe', 'smart-speakers-and-privacy-what-actually-gets-sent', 'Smart speakers and privacy - what actually gets sent', 'Want a voice assistant but not a microphone reporting back from every room.', 'security', 'category', 'audio-headphones', null, 'security_desk', true, now() - interval '11 days', now() - interval '11 days')
on conflict (slug) do update set body = excluded.body, category = excluded.category, updated_at = now();
insert into public.posts (id, thread_id, author_id, author_label, is_seed, body, created_at)
values ('ddd26b40-0194-452c-aa64-d26b40030194', (select id from public.threads where slug = 'smart-speakers-and-privacy-what-actually-gets-sent'), null, 'security_desk', true, 'Two separate things. Wake-word detection runs locally. The audio after the wake word goes to the vendor, and you can usually review and delete it. Check whether transcripts are retained, because those are the more sensitive artefact.', now() - interval '10 days') on conflict (id) do nothing;
insert into public.posts (id, thread_id, author_id, author_label, is_seed, body, created_at)
values ('ded26cd4-01d5-42ff-aa25-d26cd40301d5', (select id from public.threads where slug = 'smart-speakers-and-privacy-what-actually-gets-sent'), null, 'iotatlas_editorial', true, 'For the rooms you care about most, a speaker with a hardware mute switch beats trusting a software toggle.', now() - interval '9 days') on conflict (id) do nothing;

-- 31. Earbuds stopped pairing after a firmware update
insert into public.threads (id, slug, title, body, category, entity_type, entity_slug, author_id, author_label, is_seed, created_at, updated_at)
values ('c9fe9248-ad3f-4089-a6cf-fe924802ad3f', 'earbuds-stopped-pairing-after-a-firmware-update', 'Earbuds stopped pairing after a firmware update', 'Both earbuds were fine, then the app pushed an update and now only one connects.', 'troubleshooting', 'category', 'audio-headphones', null, 'field_notes', true, now() - interval '10 days', now() - interval '10 days')
on conflict (slug) do update set body = excluded.body, category = excluded.category, updated_at = now();
insert into public.posts (id, thread_id, author_id, author_label, is_seed, body, created_at)
values ('b428f2a6-99c5-449d-a235-28f2a60299c5', (select id from public.threads where slug = 'earbuds-stopped-pairing-after-a-firmware-update'), null, 'field_notes', true, 'Reset the pair, not just the phone. Almost every earbud set has a case-button reset that clears the bond between the two buds. Do that before anything else, then re-pair.', now() - interval '9 days') on conflict (id) do nothing;
insert into public.posts (id, thread_id, author_id, author_label, is_seed, body, created_at)
values ('b528f438-9a01-41c7-a1f1-28f438029a01', (select id from public.threads where slug = 'earbuds-stopped-pairing-after-a-firmware-update'), null, 'iotatlas_editorial', true, 'If it persists, check the app for a second update. Firmware rollouts are sometimes staged per bud, and a half-updated pair behaves exactly like this.', now() - interval '8 days') on conflict (id) do nothing;

-- 32. Which label material for cables in a rack
insert into public.threads (id, slug, title, body, category, entity_type, entity_slug, author_id, author_label, is_seed, created_at, updated_at)
values ('c7d095dc-0a84-40a8-a174-d095dc020a84', 'which-label-material-for-cables-in-a-rack', 'Which label material for cables in a rack', 'Labelling a network rack. Labels need to survive handling and stay readable.', 'buying', 'category', 'label-printers', null, 'buyer_desk', true, now() - interval '9 days', now() - interval '9 days')
on conflict (slug) do update set body = excluded.body, category = excluded.category, updated_at = now();
insert into public.posts (id, thread_id, author_id, author_label, is_seed, body, created_at)
values ('894f5728-faba-426e-a14a-4f572801faba', (select id from public.threads where slug = 'which-label-material-for-cables-in-a-rack'), null, 'buyer_desk', true, 'Heat-shrink or flexible nylon tape. Paper labels abrade off a cable in weeks. Check which widths your printer supports in those materials before choosing the printer, not after.', now() - interval '8 days') on conflict (id) do nothing;
insert into public.posts (id, thread_id, author_id, author_label, is_seed, body, created_at)
values ('8a4f58bc-faf0-4db4-a100-4f58bc01faf0', (select id from public.threads where slug = 'which-label-material-for-cables-in-a-rack'), null, 'field_notes', true, 'Print flag-style where you can. It gives more characters per centimetre of cable and reads without rotating the bundle.', now() - interval '7 days') on conflict (id) do nothing;

-- 33. Home battery - size for outage backup or for bill savings
insert into public.threads (id, slug, title, body, category, entity_type, entity_slug, author_id, author_label, is_seed, created_at, updated_at)
values ('69352b48-8add-4195-a12d-352b48038add', 'home-battery-size-for-outage-backup-or-for-bill-savings', 'Home battery - size for outage backup or for bill savings', 'Two installers gave me wildly different battery sizes. One says 5 kWh is plenty, the other says 20. What actually drives the number?', 'buying', 'category', 'energy-solar', null, 'cloud_desk', true, now() - interval '8 days', now() - interval '8 days')
on conflict (slug) do update set body = excluded.body, category = excluded.category, updated_at = now();
insert into public.posts (id, thread_id, author_id, author_label, is_seed, body, created_at)
values ('3549a310-75a3-46b3-ae53-49a3100375a3', (select id from public.threads where slug = 'home-battery-size-for-outage-backup-or-for-bill-savings'), null, 'cloud_desk', true, 'They are answering different questions. Backup sizing is about which circuits you want to keep alive and for how long - a fridge, lights and internet for a day might be 5 kWh. Bill-shifting sizing is about covering your evening consumption every night, which is usually much larger.', now() - interval '7 days') on conflict (id) do nothing;
insert into public.posts (id, thread_id, author_id, author_label, is_seed, body, created_at)
values ('3649a4a4-75e9-414d-ae19-49a4a40375e9', (select id from public.threads where slug = 'home-battery-size-for-outage-backup-or-for-bill-savings'), null, 'iotatlas_editorial', true, 'Decide the goal first, then size. Also check the inverter can actually island your backed-up circuits while the grid is down. A big battery behind a non-islanding inverter gives you nothing during an outage.', now() - interval '6 days') on conflict (id) do nothing;

-- 34. Why solar apps disagree with the utility bill
insert into public.threads (id, slug, title, body, category, entity_type, entity_slug, author_id, author_label, is_seed, created_at, updated_at)
values ('0efb6bac-7f40-44ec-a4b0-fb6bac027f40', 'why-solar-apps-disagree-with-the-utility-bill', 'Why solar apps disagree with the utility bill', 'My monitoring app says I exported far more than the bill credits me for. Which number is wrong?', 'compatibility', 'protocol', 'sunspec', null, 'iotatlas_editorial', true, now() - interval '7 days', now() - interval '7 days')
on conflict (slug) do update set body = excluded.body, category = excluded.category, updated_at = now();
insert into public.posts (id, thread_id, author_id, author_label, is_seed, body, created_at)
values ('479c9b38-6cac-4794-a75c-9c9b38026cac', (select id from public.threads where slug = 'why-solar-apps-disagree-with-the-utility-bill'), null, 'iotatlas_editorial', true, 'Usually neither, they measure different points. The inverter reports production at the panels. The utility meter measures at the grid connection, after house consumption. If your app is not reading a consumption meter too, it cannot know what you used on site.', now() - interval '6 days') on conflict (id) do nothing;
insert into public.posts (id, thread_id, author_id, author_label, is_seed, body, created_at)
values ('489c9ccc-6ce6-402a-a716-9c9ccc026ce6', (select id from public.threads where slug = 'why-solar-apps-disagree-with-the-utility-bill'), null, 'cloud_desk', true, 'The other common cause is reporting interval. A 5-minute average hides short export spikes that the utility meter still records. Compare daily totals rather than instantaneous readings before assuming an error.', now() - interval '5 days') on conflict (id) do nothing;

-- 35. Weather-based irrigation - does it actually save water
insert into public.threads (id, slug, title, body, category, entity_type, entity_slug, author_id, author_label, is_seed, created_at, updated_at)
values ('bd98de32-4691-475d-ad61-98de32034691', 'weather-based-irrigation-does-it-actually-save-water', 'Weather-based irrigation - does it actually save water', 'Replacing a dumb timer with a smart controller. Real saving or marketing?', 'buying', 'category', 'smart-garden', null, 'buyer_desk', true, now() - interval '6 days', now() - interval '6 days')
on conflict (slug) do update set body = excluded.body, category = excluded.category, updated_at = now();
insert into public.posts (id, thread_id, author_id, author_label, is_seed, body, created_at)
values ('3e42b9e0-318d-486d-aa7d-42b9e003318d', (select id from public.threads where slug = 'weather-based-irrigation-does-it-actually-save-water'), null, 'buyer_desk', true, 'Real, but mostly through two things: skipping cycles after rain, and adjusting run time by season. If your old timer already had a rain sensor, the saving is smaller than the brochure implies.', now() - interval '5 days') on conflict (id) do nothing;
insert into public.posts (id, thread_id, author_id, author_label, is_seed, body, created_at)
values ('3f42bb73-31d0-4aa3-aa20-42bb730331d0', (select id from public.threads where slug = 'weather-based-irrigation-does-it-actually-save-water'), null, 'iotatlas_editorial', true, 'The bigger saving usually comes from splitting zones. A single schedule has to satisfy the thirstiest bed, so everything else gets overwatered. Zone the beds by plant type and the saving compounds.', now() - interval '4 days') on conflict (id) do nothing;

-- 36. Robot vacuum map is wrong after moving furniture
insert into public.threads (id, slug, title, body, category, entity_type, entity_slug, author_id, author_label, is_seed, created_at, updated_at)
values ('9605bf28-d1ce-411a-aa3e-05bf2802d1ce', 'robot-vacuum-map-is-wrong-after-moving-furniture', 'Robot vacuum map is wrong after moving furniture', 'The floor plan has the sofa in the wrong place and the robot keeps trying to drive through it.', 'troubleshooting', 'category', 'robot-vacuums', null, 'field_notes', true, now() - interval '5 days', now() - interval '5 days')
on conflict (slug) do update set body = excluded.body, category = excluded.category, updated_at = now();
insert into public.posts (id, thread_id, author_id, author_label, is_seed, body, created_at)
values ('5e6908f0-bdba-454a-a64a-6908f002bdba', (select id from public.threads where slug = 'robot-vacuum-map-is-wrong-after-moving-furniture'), null, 'field_notes', true, 'Delete the map and let it remap from scratch after a significant furniture move. Most robots patch an existing map rather than rebuild it, and repeated patching drifts.', now() - interval '4 days') on conflict (id) do nothing;
insert into public.posts (id, thread_id, author_id, author_label, is_seed, body, created_at)
values ('5f690a84-bdf7-4773-a607-690a8402bdf7', (select id from public.threads where slug = 'robot-vacuum-map-is-wrong-after-moving-furniture'), null, 'iotatlas_editorial', true, 'Prevention helps too: run the first remap in good light for camera-based models, remove loose cables, and place the dock back in the same spot so the origin does not shift.', now() - interval '3 days') on conflict (id) do nothing;

-- 37. AI companion robots for kids - what happens when the company shuts down
insert into public.threads (id, slug, title, body, category, entity_type, entity_slug, author_id, author_label, is_seed, created_at, updated_at)
values ('264c5c20-2703-4b23-acf3-4c5c20052703', 'ai-companion-robots-for-kids-what-happens-when-the-company-shuts-down', 'AI companion robots for kids - what happens when the company shuts down', 'Looking at connected companion robots. Several makers have folded. Is there any way to judge the risk?', 'buying', 'category', 'ai-toys', null, 'iotatlas_editorial', true, now() - interval '4 days', now() - interval '4 days')
on conflict (slug) do update set body = excluded.body, category = excluded.category, updated_at = now();
insert into public.posts (id, thread_id, author_id, author_label, is_seed, body, created_at)
values ('83bf9ba0-0cf9-48a7-a709-bf9ba0050cf9', (select id from public.threads where slug = 'ai-companion-robots-for-kids-what-happens-when-the-company-shuts-down'), null, 'iotatlas_editorial', true, 'Check whether core functions need the cloud. A robot that only does conversation through a server becomes a paperweight if the company closes. One that still does offline activities degrades gracefully.', now() - interval '3 days') on conflict (id) do nothing;
insert into public.posts (id, thread_id, author_id, author_label, is_seed, body, created_at)
values ('84bf9d34-0d4d-4f87-a6bd-bf9d34050d4d', (select id from public.threads where slug = 'ai-companion-robots-for-kids-what-happens-when-the-company-shuts-down'), null, 'security_desk', true, 'Also read the privacy policy for what is recorded and retained, and whether you can delete it. Voice recordings from a child''s bedroom are about as sensitive as consumer data gets.', now() - interval '2 days') on conflict (id) do nothing;

-- 38. Camera in a shared hallway - what the neighbours are entitled to
insert into public.threads (id, slug, title, body, category, entity_type, entity_slug, author_id, author_label, is_seed, created_at, updated_at)
values ('3047a831-462a-4e1b-adda-47a83104462a', 'camera-in-a-shared-hallway-what-the-neighbours-are-entitled-to', 'Camera in a shared hallway - what the neighbours are entitled to', 'Apartment building, my camera sees the shared corridor. Am I allowed to keep it?', 'security', 'concept', 'privacy-by-design', null, 'security_desk', true, now() - interval '3 days', now() - interval '3 days')
on conflict (slug) do update set body = excluded.body, category = excluded.category, updated_at = now();
insert into public.posts (id, thread_id, author_id, author_label, is_seed, body, created_at)
values ('f40b3530-2f12-45de-a4e2-0b3530042f12', (select id from public.threads where slug = 'camera-in-a-shared-hallway-what-the-neighbours-are-entitled-to'), null, 'security_desk', true, 'Depends heavily on jurisdiction and on whether the building has its own rules. In most of Europe, filming a shared area means processing other people''s personal data, so you need a lawful basis and usually a sign. In many leases you also need landlord permission.', now() - interval '2 days') on conflict (id) do nothing;
insert into public.posts (id, thread_id, author_id, author_label, is_seed, body, created_at)
values ('f50b36c3-2f5f-4664-a4af-0b36c3042f5f', (select id from public.threads where slug = 'camera-in-a-shared-hallway-what-the-neighbours-are-entitled-to'), null, 'iotatlas_editorial', true, 'The practical middle ground most people take: mask everything outside your own door, record only on your doorbell trigger, and keep the shortest retention the use case allows. Do all three and document it. This is general information, not legal advice - for a shared building get local advice.', now() - interval '1 days') on conflict (id) do nothing;

-- 39. Trail camera in a wet climate - which mounts survive
insert into public.threads (id, slug, title, body, category, entity_type, entity_slug, author_id, author_label, is_seed, created_at, updated_at)
values ('f548bd5f-1419-46ba-afe9-48bd5f031419', 'trail-camera-in-a-wet-climate-which-mounts-survive', 'Trail camera in a wet climate - which mounts survive', 'Two cameras corroded at the connector after one winter. Looking for what actually holds up.', 'general', 'category', 'trail-cameras', null, 'field_notes', true, now() - interval '2 days', now() - interval '2 days')
on conflict (slug) do update set body = excluded.body, category = excluded.category, updated_at = now();
insert into public.posts (id, thread_id, author_id, author_label, is_seed, body, created_at)
values ('f5641f48-0069-40df-ab99-641f48030069', (select id from public.threads where slug = 'trail-camera-in-a-wet-climate-which-mounts-survive'), null, 'field_notes', true, 'Water gets in through the cable gland, not the housing. Use a drip loop so water runs off before it reaches the connector, and dielectric grease on the contacts. That one change fixes most winter corrosion.', now() - interval '1 days') on conflict (id) do nothing;
insert into public.posts (id, thread_id, author_id, author_label, is_seed, body, created_at)
values ('f66420dc-00aa-4f8a-ab5a-6420dc0300aa', (select id from public.threads where slug = 'trail-camera-in-a-wet-climate-which-mounts-survive'), null, 'iotatlas_editorial', true, 'Also check the SD card door seal, not just the main gasket. A worn seal on the small door lets in more moisture than people expect.', now() - interval '0 days') on conflict (id) do nothing;

-- 40. Do Matter bridges actually fix legacy devices
insert into public.threads (id, slug, title, body, category, entity_type, entity_slug, author_id, author_label, is_seed, created_at, updated_at)
values ('a620d368-7e68-4300-a598-20d368027e68', 'do-matter-bridges-actually-fix-legacy-devices', 'Do Matter bridges actually fix legacy devices', 'I have Zigbee sensors I like. Will a Matter bridge make them work in Apple Home properly?', 'compatibility', 'protocol', 'matter-bridge', null, 'iotatlas_editorial', true, now() - interval '1 days', now() - interval '1 days')
on conflict (slug) do update set body = excluded.body, category = excluded.category, updated_at = now();
insert into public.posts (id, thread_id, author_id, author_label, is_seed, body, created_at)
values ('d495b950-6c22-4a8e-a7d2-95b950026c22', (select id from public.threads where slug = 'do-matter-bridges-actually-fix-legacy-devices'), null, 'iotatlas_editorial', true, 'Often yes, with caveats. The bridge exposes the devices to the Matter fabric, so they appear in the controller. But features the bridge does not map are simply absent - device-specific settings usually stay in the original app.', now() - interval '0 days') on conflict (id) do nothing;
insert into public.posts (id, thread_id, author_id, author_label, is_seed, body, created_at)
values ('d595bae3-6c5c-4941-a7ac-95bae3026c5c', (select id from public.threads where slug = 'do-matter-bridges-actually-fix-legacy-devices'), null, 'field_notes', true, 'Expect a second app in your life. You will still need the vendor app for firmware and configuration, even if day-to-day control moves to the Matter controller.', now() - interval '0 days') on conflict (id) do nothing;

commit;

-- Expected: 40 threads, 96 replies
