-- =====================================================================
-- IoT Atlas - community schema (Supabase / PostgreSQL)
-- Run in the Supabase SQL editor. Idempotent: safe to re-run.
-- =====================================================================

create extension if not exists "pgcrypto";

-- ---------------------------------------------------------------- enums
do $$ begin
  create type community_role as enum ('member','contributor','moderator','admin');
exception when duplicate_object then null; end $$;

do $$ begin
  create type content_status as enum ('draft','published','flagged','removed');
exception when duplicate_object then null; end $$;

do $$ begin
  create type reaction_kind as enum ('upvote','helpful','like');
exception when duplicate_object then null; end $$;

-- ------------------------------------------------------------- profiles
create table if not exists public.profiles (
  id            uuid primary key references auth.users(id) on delete cascade,
  handle        text unique not null check (handle ~ '^[a-z0-9_]{3,24}$'),
  display_name  text not null default '',
  avatar_url    text,
  bio           text default '',
  country       text,
  role          community_role not null default 'member',
  reputation    integer not null default 0,
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now()
);

-- --------------------------------------------------------------- threads
create table if not exists public.threads (
  id            uuid primary key default gen_random_uuid(),
  slug          text unique not null,
  title         text not null check (char_length(title) between 8 and 160),
  body          text not null check (char_length(body) between 10 and 8000),
  category      text not null default 'general',
  entity_type   text,                       -- brand | product | app | protocol | cloud | category
  entity_slug   text,                       -- links a thread to a catalogue record
  author_id     uuid references public.profiles(id) on delete set null,
  author_label  text,                        -- used by editorial seed threads that have no auth user
  is_seed       boolean not null default false,
  status        content_status not null default 'published',
  pinned        boolean not null default false,
  locked        boolean not null default false,
  view_count    integer not null default 0,
  reply_count   integer not null default 0,
  reaction_count integer not null default 0,
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now()
);
create index if not exists threads_entity_idx  on public.threads (entity_type, entity_slug);
create index if not exists threads_recent_idx  on public.threads (created_at desc);
create index if not exists threads_category_idx on public.threads (category);

-- ----------------------------------------------------------------- posts
create table if not exists public.posts (
  id          uuid primary key default gen_random_uuid(),
  thread_id   uuid not null references public.threads(id) on delete cascade,
  author_id   uuid references public.profiles(id) on delete set null,
  author_label text,                         -- editorial seed replies
  is_seed     boolean not null default false,
  parent_id   uuid references public.posts(id) on delete cascade,
  body        text not null check (char_length(body) between 2 and 8000),
  status      content_status not null default 'published',
  reaction_count integer not null default 0,
  is_answer   boolean not null default false,
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now()
);
create index if not exists posts_thread_idx on public.posts (thread_id, created_at);

-- ------------------------------------------------------------- reactions
create table if not exists public.reactions (
  id          uuid primary key default gen_random_uuid(),
  user_id     uuid not null references public.profiles(id) on delete cascade,
  target_type text not null check (target_type in ('thread','post','review')),
  target_id   uuid not null,
  kind        reaction_kind not null default 'helpful',
  created_at  timestamptz not null default now(),
  unique (user_id, target_type, target_id, kind)
);
create index if not exists reactions_target_idx on public.reactions (target_type, target_id);

-- --------------------------------------------------------------- reviews
create table if not exists public.reviews (
  id                  uuid primary key default gen_random_uuid(),
  user_id             uuid not null references public.profiles(id) on delete cascade,
  entity_type         text not null check (entity_type in ('brand','product','app','cloud')),
  entity_slug         text not null,
  rating              numeric(2,1) not null check (rating >= 1 and rating <= 5),
  title               text not null check (char_length(title) between 4 and 140),
  body                text not null check (char_length(body) between 20 and 8000),
  pros                text default '',
  cons                text default '',
  ownership_months    integer check (ownership_months between 0 and 240),
  verified_owner      boolean not null default false,
  status              content_status not null default 'published',
  helpful_count       integer not null default 0,
  created_at          timestamptz not null default now(),
  updated_at          timestamptz not null default now(),
  unique (user_id, entity_type, entity_slug)
);
create index if not exists reviews_entity_idx on public.reviews (entity_type, entity_slug);

-- ------------------------------------------------------------- bookmarks
create table if not exists public.bookmarks (
  id          uuid primary key default gen_random_uuid(),
  user_id     uuid not null references public.profiles(id) on delete cascade,
  entity_type text not null,
  entity_slug text not null,
  created_at  timestamptz not null default now(),
  unique (user_id, entity_type, entity_slug)
);

-- --------------------------------------------------------------- reports
create table if not exists public.reports (
  id           uuid primary key default gen_random_uuid(),
  reporter_id  uuid not null references public.profiles(id) on delete cascade,
  target_type  text not null,
  target_id    uuid not null,
  reason       text not null check (char_length(reason) between 4 and 500),
  status       text not null default 'open',
  created_at   timestamptz not null default now()
);

-- =====================================================================
-- Triggers
-- =====================================================================

-- auto-create a profile when a user signs up
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public as $$
declare base_handle text;
begin
  base_handle := lower(regexp_replace(coalesce(new.raw_user_meta_data->>'handle', split_part(new.email,'@',1), 'user'), '[^a-z0-9_]', '', 'g'));
  if char_length(base_handle) < 3 then base_handle := 'user' || substr(new.id::text,1,6); end if;
  insert into public.profiles (id, handle, display_name)
  values (new.id, left(base_handle,18) || '_' || substr(new.id::text,1,4), coalesce(new.raw_user_meta_data->>'display_name',''))
  on conflict (id) do nothing;
  return new;
end $$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
  for each row execute function public.handle_new_user();

-- keep reply_count in sync
create or replace function public.sync_thread_reply_count()
returns trigger language plpgsql as $$
begin
  update public.threads t
     set reply_count = (select count(*) from public.posts p where p.thread_id = coalesce(new.thread_id, old.thread_id) and p.status = 'published')
   where t.id = coalesce(new.thread_id, old.thread_id);
  return null;
end $$;

drop trigger if exists posts_sync_reply_count on public.posts;
create trigger posts_sync_reply_count after insert or update or delete on public.posts
  for each row execute function public.sync_thread_reply_count();

-- keep reaction_count in sync
create or replace function public.sync_reaction_count()
returns trigger language plpgsql as $$
declare tgt uuid; ttype text;
begin
  tgt   := coalesce(new.target_id, old.target_id);
  ttype := coalesce(new.target_type, old.target_type);
  if ttype = 'thread' then
    update public.threads set reaction_count = (select count(*) from public.reactions r where r.target_type='thread' and r.target_id=tgt) where id = tgt;
  elsif ttype = 'post' then
    update public.posts set reaction_count = (select count(*) from public.reactions r where r.target_type='post' and r.target_id=tgt) where id = tgt;
  elsif ttype = 'review' then
    update public.reviews set helpful_count = (select count(*) from public.reactions r where r.target_type='review' and r.target_id=tgt) where id = tgt;
  end if;
  return null;
end $$;

drop trigger if exists reactions_sync_count on public.reactions;
create trigger reactions_sync_count after insert or delete on public.reactions
  for each row execute function public.sync_reaction_count();

-- updated_at maintenance
create or replace function public.touch_updated_at()
returns trigger language plpgsql as $$ begin new.updated_at := now(); return new; end $$;

do $$
declare t text;
begin
  foreach t in array array['profiles','threads','posts','reviews'] loop
    execute format('drop trigger if exists %I_touch on public.%I', t, t);
    execute format('create trigger %I_touch before update on public.%I for each row execute function public.touch_updated_at()', t, t);
  end loop;
end $$;

-- =====================================================================
-- Row Level Security
-- =====================================================================
alter table public.profiles  enable row level security;
alter table public.threads   enable row level security;
alter table public.posts     enable row level security;
alter table public.reactions enable row level security;
alter table public.reviews   enable row level security;
alter table public.bookmarks enable row level security;
alter table public.reports   enable row level security;

-- profiles: readable by all, writable by owner
drop policy if exists profiles_read on public.profiles;
create policy profiles_read on public.profiles for select using (true);
drop policy if exists profiles_insert_self on public.profiles;
create policy profiles_insert_self on public.profiles for insert with check (auth.uid() = id);
drop policy if exists profiles_update_self on public.profiles;
create policy profiles_update_self on public.profiles for update using (auth.uid() = id) with check (auth.uid() = id);

-- threads
drop policy if exists threads_read on public.threads;
create policy threads_read on public.threads for select using (status = 'published' or author_id = auth.uid());
drop policy if exists threads_insert on public.threads;
create policy threads_insert on public.threads for insert with check (auth.uid() = author_id);
drop policy if exists threads_update on public.threads;
create policy threads_update on public.threads for update using (auth.uid() = author_id) with check (auth.uid() = author_id);
drop policy if exists threads_delete on public.threads;
create policy threads_delete on public.threads for delete using (auth.uid() = author_id);

-- posts
drop policy if exists posts_read on public.posts;
create policy posts_read on public.posts for select using (status = 'published' or author_id = auth.uid());
drop policy if exists posts_insert on public.posts;
create policy posts_insert on public.posts for insert with check (auth.uid() = author_id);
drop policy if exists posts_update on public.posts;
create policy posts_update on public.posts for update using (auth.uid() = author_id) with check (auth.uid() = author_id);
drop policy if exists posts_delete on public.posts;
create policy posts_delete on public.posts for delete using (auth.uid() = author_id);

-- reactions
drop policy if exists reactions_read on public.reactions;
create policy reactions_read on public.reactions for select using (true);
drop policy if exists reactions_insert on public.reactions;
create policy reactions_insert on public.reactions for insert with check (auth.uid() = user_id);
drop policy if exists reactions_delete on public.reactions;
create policy reactions_delete on public.reactions for delete using (auth.uid() = user_id);

-- reviews
drop policy if exists reviews_read on public.reviews;
create policy reviews_read on public.reviews for select using (status = 'published' or user_id = auth.uid());
drop policy if exists reviews_insert on public.reviews;
create policy reviews_insert on public.reviews for insert with check (auth.uid() = user_id);
drop policy if exists reviews_update on public.reviews;
create policy reviews_update on public.reviews for update using (auth.uid() = user_id) with check (auth.uid() = user_id);
drop policy if exists reviews_delete on public.reviews;
create policy reviews_delete on public.reviews for delete using (auth.uid() = user_id);

-- bookmarks: private
drop policy if exists bookmarks_own on public.bookmarks;
create policy bookmarks_own on public.bookmarks for all using (auth.uid() = user_id) with check (auth.uid() = user_id);

-- reports: insert by anyone signed in, read own
drop policy if exists reports_insert on public.reports;
create policy reports_insert on public.reports for insert with check (auth.uid() = reporter_id);
drop policy if exists reports_read_own on public.reports;
create policy reports_read_own on public.reports for select using (auth.uid() = reporter_id);


-- ------------------------------------------------------------ subscribers
create table if not exists public.subscribers (
  id          uuid primary key default gen_random_uuid(),
  email       text not null unique check (position('@' in email) > 1),
  locale      text default 'en' check (locale in ('en','es','fr')),
  source      text default 'homepage',
  confirmed   boolean not null default false,
  created_at  timestamptz not null default now()
);
alter table public.subscribers enable row level security;
drop policy if exists subscribers_insert on public.subscribers;
create policy subscribers_insert on public.subscribers for insert with check (true);
drop policy if exists subscribers_read on public.subscribers;
create policy subscribers_read on public.subscribers for select using (false);

-- =====================================================================
-- Public read views (safe aggregates for the static site)
-- =====================================================================
create or replace view public.community_thread_feed as
  select t.id, t.slug, t.title, t.body, t.category, t.entity_type, t.entity_slug,
         t.reply_count, t.reaction_count, t.view_count, t.pinned, t.created_at,
         coalesce(p.handle, t.author_label, 'iotatlas_editorial') as author_handle,
         coalesce(p.display_name, t.author_label, 'IoT Atlas Editorial') as author_name,
         p.avatar_url as author_avatar, t.is_seed
    from public.threads t left join public.profiles p on p.id = t.author_id
   where t.status = 'published'
   order by t.pinned desc, t.created_at desc;

create or replace view public.community_review_feed as
  select r.id, r.entity_type, r.entity_slug, r.rating, r.title, r.body, r.pros, r.cons,
         r.ownership_months, r.verified_owner, r.helpful_count, r.created_at,
         p.handle as author_handle, p.display_name as author_name
    from public.reviews r join public.profiles p on p.id = r.user_id
   where r.status = 'published'
   order by r.helpful_count desc, r.created_at desc;

grant select on public.community_thread_feed to anon, authenticated;
grant select on public.community_review_feed to anon, authenticated;

-- =====================================================================
-- Seed: a welcome thread (author is the first admin you create)
-- =====================================================================
-- After you create your own account, run:
--   insert into public.threads (slug,title,body,category,author_id)
--   select 'welcome-to-the-iot-atlas-community',
--          'Welcome to the IoT Atlas community',
--          'Introduce yourself, ask compatibility questions and share field experience.',
--          'general', id from public.profiles order by created_at limit 1;
