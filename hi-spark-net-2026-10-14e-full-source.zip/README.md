# IoT Atlas — Visual Prototype & Content Framework

This folder is the first review build for the English, Spanish and French IoT platform. It is intentionally a static prototype: the goal is to validate information architecture, page density, data fields and responsive layout before building the production Astro application.

## Open the prototype

Start a local HTTP server from the project directory and open `http://localhost:8765/index.html`.

```powershell
python -m http.server 8765 --bind 127.0.0.1 --directory outputs/iot-site-prototype
```

## Pages included

- `index.html` — homepage, category map, brand strip, decision cards, cloud comparison and Amazon preview.
- `categories.html` / `category.html` / `category-detail.html` — category directory and detail template.
- `products.html` / `product.html` — product directory and product knowledge page.
- `brand.html` / `brand-detail.html` — searchable directory of 247 non-cloud brands plus dynamic brand profiles.
- `brand-insights.html` — AI brand value leaderboard with 10 scoring dimensions.
- `amazon-brands.html` — 123 Amazon-focused IoT brands grouped by category.
- `apps.html` / `app-detail.html` — IoT App Download Center with 437 apps and category/subcategory filters.
- `cloud.html` / `cloud-detail.html` — 29 cloud, IoT and connectivity platforms plus the world coverage map.
- `compare.html` / `compare-detail.html` — 49 structured comparisons scored across 245 decision factors.
- `amazon-best-sellers.html` — 83 ranked products across 20 IoT categories with leaderboards and AI signals.
- `knowledge.html` / `protocol-detail.html` — 166 validated knowledge records with a completeness contract.
- `ai-signals.html` — methodology for AI Buy Confidence, Compatibility Probability, Data Reliability and BSR Momentum.
- `search.html` — global search across brands, products, categories, cloud platforms, protocols, apps, concepts and guides.
- `manual.html`, `styleguide.html`, `logo-gallery.html` — supporting templates.
- Legal pages: `legal.html`, `privacy.html`, `terms.html`, `cookies.html`, `affiliate-disclosure.html`, `ai-disclosure.html`, `editorial-policy.html`, `corrections-policy.html`.

## Key features

### Comparison hub
49 comparisons across 10 families (Brand, Device, Protocol, Connectivity, Cloud, App, Storage, AI, Pricing, Privacy). Every factor is scored 0-100 for both sides, so the detail page shows weighted scores, win/tie/loss counts, per-factor score bars and "choose A if / choose B if" panels.

### Amazon Best Sellers
83 products across 20 IoT categories and 8 marketplaces, with working marketplace and category filters, a search box, per-category leaderboards and AI probability signals. All ASINs, ranks, ratings and prices are placeholder data — production requires the Amazon Product Advertising API or another licensed source.

### Cloud world map
A self-contained SVG world map plotting 29 platforms and 34 hyperscaler region hubs with connection arcs, filterable by platform type and clickable through to each provider guide. No external map library or network call.

### Content completeness
Every knowledge record is validated against a required-field contract before publish. Records missing a required field fail the build instead of shipping incomplete. The contract and live counts are shown on `knowledge.html`.

## Three-language behavior

Use the EN / ES / FR switch in the header. The prototype changes interface labels, category names, descriptions, guides and core page text. Portuguese and German are intentionally absent from the launch prototype.

## Fillable content templates

The `content-templates/` folder contains CSV templates and sample rows: `categories.csv`, `brands.csv`, `products.csv`, `product-specs.csv`, `cloud-services.csv`, `comparisons.csv`, `manuals.csv`, `amazon-rankings.csv`, `page-copy.csv`, `translations.csv`, `brand-scores.csv`, `knowledge-base.csv`, and the app exports `app-download-links.csv`, `camera-apps.csv`, `wearable-apps.csv`, `health-apps.csv`.

The first row of each CSV is the field contract. The second row is a sample. Blank rows are for filling or importing into a CMS/database.

## App Download Center coverage

437 apps split into category and subcategory so visitors can filter instead of scrolling one long list.

- Smart Home (12), Security (108), Lighting (9), Electrical (4), Wearables (131), Health (141), Tracking (5), Robot Vacuums (7), Smart Garden (4), AI Toys & Education (6), Health & Home (3), Drones (7).
- Health subcategories: Scale (33), Pulse Oximeter (25), Glucose (14), Blood Pressure (11), Hearing (10), Thermometer (9), ECG (8), Respiratory (8), Health (7), Baby (6), Women's Health (6), Sleep (4). Examples: RENPHO Health, OKOK, PICOOC, FITINDEX, Withings, Qardio, Wellue / ViHealth, Masimo, OMRON connect, Dexcom, Abbott LibreLink, Kardia, Kinsa.
- Wearables subcategories: Ring, Watch, Bracelet, Accessory, Sleep, Health, Sport, Outdoor, Patch, Baby, Shirt.
- Health and medical listings carry a "not medical advice" note. Every store link is flagged `store-linked` (verified direct listing) or `store-search` (official store search fallback) so unverified links can be replaced before production.

## Tools

- `tools/audit_site.mjs` — global pre-delivery audit: language-leak scan, broken-reference check, markup balance, duplicate slugs, required-field checks, URL validation and completeness-manifest cross-check. Exits non-zero on blocking errors.
- `tools/export_app_csvs.mjs` — regenerates the four app CSV exports from the deduped app directory.
- `tools/build_directory_data.py` — rebuilds brand and cloud directories from the framework CSVs.
- `tools/build_brand_scores.mjs` — regenerates the brand scorecards.
- `tools/fetch_company_icons.mjs` — refreshes Simple Icons company SVGs.

Run the audit before every delivery:

```powershell
node outputs/iot-site-prototype/tools/audit_site.mjs
```

## Company icons

Company SVGs live in `assets/logos/`. Icons available in Simple Icons are downloaded under CC0-1.0. The remaining companies use original monogram SVG fallbacks. Trademarks remain with their owners. See `assets/logos/NOTICE.md`.

## Important prototype labels

- Product images are visual placeholders, not official assets.
- Amazon ASINs, rankings, prices and ratings are placeholders.
- Product specifications are illustrative until checked against official sources.
- Comparison scores are editorial prototype values, not measured benchmarks.
- The world map is a stylised equirectangular projection with a coarse land mask; it is illustrative and not to scale.
- Manuals should link to official manufacturer PDFs unless redistribution rights are confirmed.
- Health and medical listings are not medical advice.
- Legal pages require jurisdiction-specific legal review before production.
- The brand name "IoT Atlas" is a working placeholder until the real name and trademark check are complete.

## Production port

The static blocks map directly to the planned Astro templates. See the main blueprint for the entity and database model.

## Release gate (CI)

The site cannot be published while the audit fails.

```powershell
npm run audit          # structural audit + content quality gate
npm run audit:site     # structure only (links, duplicates, language, markup)
npm run gate           # editorial contract only (content_quality_gate.yml)
npm run build:schema   # re-prerender JSON-LD after adding pages
```

`.github/workflows/quality.yml` runs the same two commands on every push and pull request. Make this folder the repository root (or copy `.github/` and `tools/` into your repo root) so the workflow resolves.

The gate checks:

- every `required` field declared in `content_quality_gate.yml` is actually storable in a content template
- every schema type in `required_schema` is emitted as static JSON-LD
- hreflang alternates are reciprocal once locales are split
- required disclosures (affiliate) are present

## Category hubs

`category-detail.html` is an aggregation page, not a product filter. For each category it pulls live records from brands, apps, ranked products, protocols, comparisons, guides and cloud platforms, and hides sections with no content. 23 categories are defined in `assets/category-hub.js`; add a category there and it appears in the directory with real counts immediately.

## App Download Center coverage

541 apps with category and subcategory filters that work for every category (not just wearables and health).

- Smart Home (12), Security (108), Smart Locks (18), Access Control (14), Lighting (9), Electrical (4), Audio & Headphones (22), Wearables (131), Health (144), Trail Cameras (11), Projectors (14), Label Printers (11), Tracking (5), Robot Vacuums (7), Smart Garden (4), AI Toys & Education (6), Health & Home (3), Drones (18).
- Subcategory filters are derived at load time by `assets/app-directory-normalize.js` where the source data has no segment, so selecting a subcategory never hides the whole category.
